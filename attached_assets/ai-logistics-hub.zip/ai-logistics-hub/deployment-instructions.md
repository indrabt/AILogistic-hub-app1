# AI-Powered Smart Logistics Hub - Deployment Instructions

This document provides detailed instructions for deploying the AI-Powered Smart Logistics Hub platform to production environments.

## Deployment Options

The AI-Powered Smart Logistics Hub supports multiple deployment options to suit different organizational needs:

1. **Cloudflare Pages Deployment** (Recommended)
2. **Docker Deployment**
3. **Traditional Server Deployment**

## Prerequisites

Before deploying, ensure you have:

- Completed all development and testing
- Access to the required infrastructure
- Necessary API keys and credentials
- Database backup strategy in place
- SSL certificates for secure connections

## Option 1: Cloudflare Pages Deployment

### Prerequisites

- Cloudflare account with Pages access
- Wrangler CLI installed (`npm install -g wrangler`)
- D1 database configured in Cloudflare

### Step 1: Prepare the Application

1. Ensure all environment variables are configured in `wrangler.toml`:

```toml
name = "logistics-hub-app"
compatibility_date = "2025-03-16"

[build]
command = "npm run build"
output_directory = ".next"

[site]
bucket = ".next"

[env.production]
workers_dev = false
route = "app.logistics-hub.example.com/*"

[[d1_databases]]
binding = "DB"
database_name = "logistics_hub_production"
database_id = "your-d1-database-id"

[vars]
NODE_ENV = "production"
AUTH_TRUST_HOST = "true"
```

2. Update the database connection in your application:

```typescript
// src/lib/db.ts
import { getCloudflareContext } from '@opennextjs/cloudflare';

export const LogisticsDB = {
  // Database methods...
}
```

### Step 2: Deploy to Cloudflare Pages

1. Authenticate with Cloudflare:

```bash
wrangler login
```

2. Deploy the application:

```bash
wrangler pages deploy .
```

3. Apply database migrations:

```bash
wrangler d1 migrations apply DB
```

### Step 3: Configure Custom Domain

1. In the Cloudflare Dashboard, navigate to Pages > Your Project
2. Go to "Custom domains"
3. Add your domain (e.g., `app.logistics-hub.example.com`)
4. Follow the DNS configuration instructions

### Step 4: Verify Deployment

1. Visit your application URL
2. Verify all features are working correctly
3. Check that API endpoints are accessible
4. Confirm database connections are functioning

## Option 2: Docker Deployment

### Prerequisites

- Docker and Docker Compose installed
- Access to a container registry (optional)
- Database server (PostgreSQL recommended)

### Step 1: Create Docker Configuration

1. Create a `Dockerfile` in the project root:

```dockerfile
FROM node:20-alpine AS base

# Install dependencies only when needed
FROM base AS deps
WORKDIR /app
COPY package.json package-lock.json ./
RUN npm ci

# Rebuild the source code only when needed
FROM base AS builder
WORKDIR /app
COPY --from=deps /app/node_modules ./node_modules
COPY . .
RUN npm run build

# Production image, copy all the files and run next
FROM base AS runner
WORKDIR /app

ENV NODE_ENV production

RUN addgroup --system --gid 1001 nodejs
RUN adduser --system --uid 1001 nextjs

COPY --from=builder /app/public ./public
COPY --from=builder --chown=nextjs:nodejs /app/.next/standalone ./
COPY --from=builder --chown=nextjs:nodejs /app/.next/static ./.next/static

USER nextjs

EXPOSE 3000

ENV PORT 3000

CMD ["node", "server.js"]
```

2. Create a `docker-compose.yml` file:

```yaml
version: '3'

services:
  app:
    build: .
    ports:
      - "3000:3000"
    environment:
      - DATABASE_URL=postgresql://username:password@db:5432/logistics_hub
      - AUTH_SECRET=your_auth_secret_key
      - NODE_ENV=production
    depends_on:
      - db
    restart: always

  db:
    image: postgres:14
    volumes:
      - postgres_data:/var/lib/postgresql/data
    environment:
      - POSTGRES_PASSWORD=password
      - POSTGRES_USER=username
      - POSTGRES_DB=logistics_hub
    ports:
      - "5432:5432"
    restart: always

volumes:
  postgres_data:
```

### Step 2: Build and Deploy

1. Build the Docker image:

```bash
docker-compose build
```

2. Start the services:

```bash
docker-compose up -d
```

3. Initialize the database:

```bash
docker-compose exec app npx prisma migrate deploy
```

### Step 3: Configure Reverse Proxy (Optional)

For production environments, configure Nginx as a reverse proxy:

1. Install Nginx:

```bash
apt-get update
apt-get install -y nginx
```

2. Create Nginx configuration:

```nginx
server {
    listen 80;
    server_name app.logistics-hub.example.com;

    location / {
        proxy_pass http://localhost:3000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host $host;
        proxy_cache_bypass $http_upgrade;
    }
}
```

3. Enable the configuration:

```bash
ln -s /etc/nginx/sites-available/logistics-hub /etc/nginx/sites-enabled/
nginx -t
systemctl restart nginx
```

### Step 4: Set Up SSL with Let's Encrypt

1. Install Certbot:

```bash
apt-get install -y certbot python3-certbot-nginx
```

2. Obtain SSL certificate:

```bash
certbot --nginx -d app.logistics-hub.example.com
```

3. Configure auto-renewal:

```bash
systemctl status certbot.timer
```

## Option 3: Traditional Server Deployment

### Prerequisites

- Ubuntu 20.04 LTS or higher
- Node.js 20.x installed
- PostgreSQL 14 or higher
- Nginx web server

### Step 1: Prepare the Server

1. Update the system:

```bash
sudo apt update
sudo apt upgrade -y
```

2. Install Node.js:

```bash
curl -fsSL https://deb.nodesource.com/setup_20.x | sudo -E bash -
sudo apt-get install -y nodejs
```

3. Install PostgreSQL:

```bash
sudo apt install -y postgresql postgresql-contrib
```

4. Create a database:

```bash
sudo -u postgres psql
CREATE DATABASE logistics_hub;
CREATE USER logistics_user WITH ENCRYPTED PASSWORD 'your_password';
GRANT ALL PRIVILEGES ON DATABASE logistics_hub TO logistics_user;
\q
```

### Step 2: Deploy the Application

1. Clone the repository:

```bash
git clone https://github.com/your-organization/ai-logistics-hub.git
cd ai-logistics-hub/logistics-hub-app
```

2. Install dependencies:

```bash
npm ci
```

3. Create a `.env.local` file:

```
DATABASE_URL=postgresql://logistics_user:your_password@localhost:5432/logistics_hub
AUTH_SECRET=your_auth_secret_key
NODE_ENV=production
```

4. Build the application:

```bash
npm run build
```

5. Set up PM2 for process management:

```bash
sudo npm install -g pm2
pm2 start npm --name "logistics-hub" -- start
pm2 startup
pm2 save
```

### Step 3: Configure Nginx

1. Install Nginx:

```bash
sudo apt install -y nginx
```

2. Create Nginx configuration:

```bash
sudo nano /etc/nginx/sites-available/logistics-hub
```

3. Add the following configuration:

```nginx
server {
    listen 80;
    server_name app.logistics-hub.example.com;

    location / {
        proxy_pass http://localhost:3000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host $host;
        proxy_cache_bypass $http_upgrade;
    }
}
```

4. Enable the site:

```bash
sudo ln -s /etc/nginx/sites-available/logistics-hub /etc/nginx/sites-enabled/
sudo nginx -t
sudo systemctl restart nginx
```

### Step 4: Set Up SSL with Let's Encrypt

1. Install Certbot:

```bash
sudo apt install -y certbot python3-certbot-nginx
```

2. Obtain SSL certificate:

```bash
sudo certbot --nginx -d app.logistics-hub.example.com
```

3. Configure auto-renewal:

```bash
sudo systemctl status certbot.timer
```

## Continuous Deployment Setup

### GitHub Actions

1. Create a `.github/workflows/deploy.yml` file:

```yaml
name: Deploy

on:
  push:
    branches: [ main ]

jobs:
  deploy:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v3
      
      - name: Setup Node.js
        uses: actions/setup-node@v3
        with:
          node-version: '20'
          
      - name: Install dependencies
        run: npm ci
        
      - name: Build
        run: npm run build
        
      - name: Deploy to Cloudflare Pages
        uses: cloudflare/wrangler-action@v3
        with:
          apiToken: ${{ secrets.CF_API_TOKEN }}
          accountId: ${{ secrets.CF_ACCOUNT_ID }}
          command: pages deploy .
```

2. Add the required secrets to your GitHub repository:
   - `CF_API_TOKEN`: Your Cloudflare API token
   - `CF_ACCOUNT_ID`: Your Cloudflare account ID

## Monitoring and Maintenance

### Setting Up Monitoring

1. Configure application logging:
   - Use a service like Datadog, New Relic, or Cloudflare Analytics
   - Set up error alerting via email or Slack

2. Database monitoring:
   - Set up regular backups
   - Monitor database performance
   - Configure alerts for high resource usage

### Regular Maintenance Tasks

1. Database maintenance:
   - Run regular vacuum operations on PostgreSQL
   - Monitor and optimize slow queries
   - Regularly backup the database

2. Application updates:
   - Implement a blue-green deployment strategy
   - Schedule regular security updates
   - Monitor dependency vulnerabilities

## Rollback Procedures

In case of deployment issues:

### Cloudflare Pages Rollback

1. In the Cloudflare Dashboard, navigate to Pages > Your Project > Deployments
2. Find the previous working deployment
3. Click "Rollback to this deployment"

### Docker Rollback

1. Pull the previous image version:

```bash
docker-compose pull app:previous-tag
```

2. Update the docker-compose.yml file to use the previous version
3. Restart the services:

```bash
docker-compose up -d
```

### Traditional Server Rollback

1. Navigate to your application directory
2. Pull the previous version:

```bash
git checkout previous-tag
```

3. Rebuild and restart:

```bash
npm ci
npm run build
pm2 restart logistics-hub
```

## Security Considerations

1. **API Keys and Secrets**:
   - Never commit secrets to the repository
   - Use environment variables for all sensitive information
   - Rotate API keys regularly

2. **Database Security**:
   - Use strong passwords
   - Limit database access to necessary IP addresses
   - Regularly audit database access

3. **Network Security**:
   - Configure firewalls to restrict access
   - Use HTTPS for all connections
   - Implement rate limiting for API endpoints

## Troubleshooting Common Issues

### Application Not Starting

1. Check the application logs:

```bash
pm2 logs logistics-hub
```

2. Verify environment variables are set correctly
3. Ensure the database is accessible

### Database Connection Issues

1. Check the database connection string
2. Verify the database server is running
3. Check network connectivity between the application and database

### SSL Certificate Issues

1. Verify the certificate is not expired:

```bash
certbot certificates
```

2. Renew the certificate if needed:

```bash
certbot renew
```

## Contact and Support

For deployment assistance, contact:
- Email: devops@example.com
- Support Portal: https://support.logistics-hub.example.com
- Emergency Hotline: +61 2 1234 5678
