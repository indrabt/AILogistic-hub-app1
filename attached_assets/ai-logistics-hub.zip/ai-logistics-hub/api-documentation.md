# AI-Powered Smart Logistics Hub - API Documentation

## Overview

The AI-Powered Smart Logistics Hub provides a comprehensive RESTful API that allows developers to integrate with the platform's features and functionality. This documentation outlines the available endpoints, request/response formats, and authentication requirements.

## Base URL

All API endpoints are relative to the base URL:

```
https://api.logistics-hub.example.com/v1
```

## Authentication

### API Keys

All requests must include an API key in the header:

```
Authorization: Bearer YOUR_API_KEY
```

To obtain an API key:
1. Log in to the AI-Powered Smart Logistics Hub
2. Navigate to Settings > API Access
3. Click "Generate New API Key"
4. Set permissions and expiration for the key
5. Copy the generated key (note: it will only be shown once)

### Rate Limiting

API requests are subject to rate limiting:
- 100 requests per minute for standard tier
- 500 requests per minute for premium tier
- 1000 requests per minute for enterprise tier

Rate limit headers are included in all responses:
```
X-RateLimit-Limit: 100
X-RateLimit-Remaining: 95
X-RateLimit-Reset: 1616789400
```

## Common Response Codes

| Code | Description |
|------|-------------|
| 200  | Success |
| 201  | Created |
| 400  | Bad Request |
| 401  | Unauthorized |
| 403  | Forbidden |
| 404  | Not Found |
| 429  | Too Many Requests |
| 500  | Internal Server Error |

## Endpoints

### Authentication

#### POST /auth/login

Authenticates a user and returns a JWT token.

**Request:**
```json
{
  "email": "user@example.com",
  "password": "securepassword"
}
```

**Response:**
```json
{
  "success": true,
  "token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...",
  "user": {
    "id": 123,
    "name": "John Smith",
    "email": "user@example.com",
    "role": "Admin"
  }
}
```

### Routes

#### GET /routes

Returns a list of routes.

**Query Parameters:**
- `company_id` (optional): Filter by company ID
- `status` (optional): Filter by status (active, completed, cancelled)
- `page` (optional): Page number for pagination (default: 1)
- `limit` (optional): Number of results per page (default: 20)

**Response:**
```json
{
  "success": true,
  "data": [
    {
      "id": 1,
      "company_id": 1,
      "name": "Parramatta to Penrith",
      "start_location": "Parramatta",
      "end_location": "Penrith",
      "distance": 24.5,
      "status": "active",
      "created_at": "2025-03-15T10:30:00Z",
      "updated_at": "2025-03-16T08:15:00Z"
    },
    {
      "id": 2,
      "company_id": 1,
      "name": "Blacktown to Windsor",
      "start_location": "Blacktown",
      "end_location": "Windsor",
      "distance": 18.3,
      "status": "completed",
      "created_at": "2025-03-14T09:45:00Z",
      "updated_at": "2025-03-14T14:20:00Z"
    }
  ],
  "pagination": {
    "total": 42,
    "page": 1,
    "limit": 20,
    "pages": 3
  }
}
```

#### GET /routes/{id}

Returns details for a specific route.

**Response:**
```json
{
  "success": true,
  "data": {
    "id": 1,
    "company_id": 1,
    "name": "Parramatta to Penrith",
    "start_location": "Parramatta",
    "end_location": "Penrith",
    "distance": 24.5,
    "status": "active",
    "optimized_route_json": {
      "start": {
        "coordinates": {
          "lat": -33.8150,
          "lon": 151.0011
        }
      },
      "end": {
        "coordinates": {
          "lat": -33.7506,
          "lon": 150.6942
        }
      },
      "waypoints": [
        {
          "location": "Westmead Hospital",
          "coordinates": {
            "lat": -33.8018,
            "lon": 150.9892
          },
          "priority": "high"
        },
        {
          "location": "Blacktown Shopping Centre",
          "coordinates": {
            "lat": -33.7668,
            "lon": 150.9054
          },
          "priority": "medium"
        }
      ]
    },
    "created_at": "2025-03-15T10:30:00Z",
    "updated_at": "2025-03-16T08:15:00Z"
  }
}
```

#### POST /routes

Creates a new route.

**Request:**
```json
{
  "company_id": 1,
  "name": "Sydney CBD to Liverpool",
  "start_location": "Sydney CBD",
  "end_location": "Liverpool",
  "waypoints": [
    {
      "location": "Strathfield",
      "priority": "medium"
    },
    {
      "location": "Bankstown",
      "priority": "high"
    }
  ]
}
```

**Response:**
```json
{
  "success": true,
  "data": {
    "id": 3,
    "company_id": 1,
    "name": "Sydney CBD to Liverpool",
    "start_location": "Sydney CBD",
    "end_location": "Liverpool",
    "distance": 31.8,
    "status": "active",
    "optimized_route_json": {
      "start": {
        "coordinates": {
          "lat": -33.8688,
          "lon": 151.2093
        }
      },
      "end": {
        "coordinates": {
          "lat": -33.9200,
          "lon": 150.9239
        }
      },
      "waypoints": [
        {
          "location": "Bankstown",
          "coordinates": {
            "lat": -33.9171,
            "lon": 151.0344
          },
          "priority": "high"
        },
        {
          "location": "Strathfield",
          "coordinates": {
            "lat": -33.8736,
            "lon": 151.0934
          },
          "priority": "medium"
        }
      ]
    },
    "created_at": "2025-03-16T14:30:00Z",
    "updated_at": "2025-03-16T14:30:00Z"
  }
}
```

#### PUT /routes/{id}

Updates an existing route.

**Request:**
```json
{
  "name": "Sydney CBD to Liverpool (Express)",
  "waypoints": [
    {
      "location": "Bankstown",
      "priority": "high"
    }
  ]
}
```

**Response:**
```json
{
  "success": true,
  "data": {
    "id": 3,
    "company_id": 1,
    "name": "Sydney CBD to Liverpool (Express)",
    "start_location": "Sydney CBD",
    "end_location": "Liverpool",
    "distance": 28.5,
    "status": "active",
    "optimized_route_json": {
      "start": {
        "coordinates": {
          "lat": -33.8688,
          "lon": 151.2093
        }
      },
      "end": {
        "coordinates": {
          "lat": -33.9200,
          "lon": 150.9239
        }
      },
      "waypoints": [
        {
          "location": "Bankstown",
          "coordinates": {
            "lat": -33.9171,
            "lon": 151.0344
          },
          "priority": "high"
        }
      ]
    },
    "created_at": "2025-03-16T14:30:00Z",
    "updated_at": "2025-03-16T15:45:00Z"
  }
}
```

#### DELETE /routes/{id}

Deletes a route.

**Response:**
```json
{
  "success": true,
  "message": "Route deleted successfully"
}
```

### Inventory

#### GET /inventory

Returns a list of inventory items.

**Query Parameters:**
- `company_id` (optional): Filter by company ID
- `status` (optional): Filter by status (in_stock, low_stock, out_of_stock)
- `page` (optional): Page number for pagination (default: 1)
- `limit` (optional): Number of results per page (default: 20)

**Response:**
```json
{
  "success": true,
  "data": [
    {
      "id": 1,
      "company_id": 1,
      "product_id": 123,
      "name": "Product A",
      "current_stock": 200,
      "reorder_point": 50,
      "lead_time": 5,
      "status": "in_stock",
      "location": "Warehouse Sydney",
      "created_at": "2025-01-15T10:30:00Z",
      "updated_at": "2025-03-16T08:15:00Z"
    },
    {
      "id": 2,
      "company_id": 1,
      "product_id": 456,
      "name": "Product B",
      "current_stock": 30,
      "reorder_point": 40,
      "lead_time": 7,
      "status": "low_stock",
      "location": "Warehouse Parramatta",
      "created_at": "2025-01-15T10:30:00Z",
      "updated_at": "2025-03-16T08:15:00Z"
    }
  ],
  "pagination": {
    "total": 150,
    "page": 1,
    "limit": 20,
    "pages": 8
  }
}
```

### AI Services

#### POST /ai/route-optimization

Optimizes a route using AI.

**Request:**
```json
{
  "start_location": "Parramatta",
  "end_location": "Penrith",
  "waypoints": [
    {
      "location": "Westmead Hospital",
      "priority": "high"
    },
    {
      "location": "Blacktown Shopping Centre",
      "priority": "medium"
    }
  ],
  "optimization_criteria": {
    "prioritize_time": 0.7,
    "prioritize_fuel": 0.3
  }
}
```

**Response:**
```json
{
  "success": true,
  "data": {
    "distance": 33.3,
    "duration": 45,
    "fuel_consumption": 3.2,
    "carbon_emissions": 7.5,
    "optimized_waypoints": [
      {
        "location": "Westmead Hospital",
        "priority": "high"
      },
      {
        "location": "Blacktown Shopping Centre",
        "priority": "medium"
      }
    ],
    "optimized_route_json": {
      "start": {
        "coordinates": {
          "lat": -33.8150,
          "lon": 151.0011
        }
      },
      "end": {
        "coordinates": {
          "lat": -33.7506,
          "lon": 150.6942
        }
      },
      "waypoints": [
        {
          "location": "Westmead Hospital",
          "coordinates": {
            "lat": -33.8018,
            "lon": 150.9892
          }
        },
        {
          "location": "Blacktown Shopping Centre",
          "coordinates": {
            "lat": -33.7668,
            "lon": 150.9054
          }
        }
      ]
    }
  }
}
```

#### POST /ai/demand-forecast

Generates a demand forecast for a product.

**Request:**
```json
{
  "company_id": 1,
  "product_id": 123,
  "start_date": "2025-03-01",
  "end_date": "2025-03-31"
}
```

**Response:**
```json
{
  "success": true,
  "data": {
    "product_id": 123,
    "predictions": [
      {
        "date": "2025-03-01",
        "quantity": 120,
        "confidence": 0.92
      },
      {
        "date": "2025-03-02",
        "quantity": 115,
        "confidence": 0.90
      },
      // Additional dates...
      {
        "date": "2025-03-31",
        "quantity": 135,
        "confidence": 0.85
      }
    ],
    "total_predicted_demand": 3850,
    "average_daily_demand": 124.2,
    "trend": "increasing",
    "seasonality_factors": {
      "day_of_week": {
        "monday": 1.1,
        "tuesday": 1.0,
        "wednesday": 0.9,
        "thursday": 1.0,
        "friday": 1.2,
        "saturday": 1.3,
        "sunday": 0.8
      }
    }
  }
}
```

#### POST /ai/flood-risk

Assesses flood risk for a location.

**Request:**
```json
{
  "location": "Penrith",
  "date": "2025-03-20",
  "weather_data": {
    "rainfall": 75,
    "river_level": 2.8,
    "soil_moisture": 85
  }
}
```

**Response:**
```json
{
  "success": true,
  "data": {
    "location": "Penrith",
    "date": "2025-03-20",
    "flood_risk": 0.65,
    "risk_level": "medium",
    "is_flood_prone_area": true,
    "weather_factors": {
      "rainfall": {
        "value": 75,
        "contribution": "high"
      },
      "river_level": {
        "value": 2.8,
        "contribution": "medium"
      },
      "soil_moisture": {
        "value": 85,
        "contribution": "high"
      }
    },
    "recommendations": [
      "Consider alternative routes that avoid low-lying areas near the Nepean River",
      "Schedule deliveries earlier in the day before potential afternoon storms",
      "Prepare contingency plans for possible road closures in the area"
    ]
  }
}
```

### Analytics

#### GET /analytics/delivery-performance

Returns delivery performance analytics.

**Query Parameters:**
- `company_id` (required): Company ID
- `start_date` (optional): Start date for analysis (default: 30 days ago)
- `end_date` (optional): End date for analysis (default: today)
- `group_by` (optional): Grouping period (day, week, month) (default: day)

**Response:**
```json
{
  "success": true,
  "data": {
    "summary": {
      "total_deliveries": 1250,
      "on_time_deliveries": 1125,
      "delayed_deliveries": 125,
      "on_time_percentage": 90,
      "average_delay_time": 25
    },
    "trend": [
      {
        "period": "2025-02-15",
        "total_deliveries": 40,
        "on_time_percentage": 87.5
      },
      {
        "period": "2025-02-16",
        "total_deliveries": 38,
        "on_time_percentage": 89.5
      },
      // Additional periods...
      {
        "period": "2025-03-16",
        "total_deliveries": 45,
        "on_time_percentage": 93.3
      }
    ],
    "by_route": [
      {
        "route_id": 1,
        "route_name": "Parramatta to Penrith",
        "total_deliveries": 120,
        "on_time_percentage": 92.5
      },
      {
        "route_id": 2,
        "route_name": "Blacktown to Windsor",
        "total_deliveries": 95,
        "on_time_percentage": 88.4
      }
    ]
  }
}
```

## Webhooks

The API supports webhooks for real-time event notifications. To configure webhooks:

1. Navigate to Settings > Webhooks in the platform
2. Click "Add Webhook"
3. Enter the destination URL
4. Select events to subscribe to
5. Set the secret key for signature verification

### Events

| Event | Description |
|-------|-------------|
| `route.created` | A new route is created |
| `route.updated` | A route is updated |
| `route.deleted` | A route is deleted |
| `delivery.started` | A delivery has started |
| `delivery.completed` | A delivery has been completed |
| `delivery.delayed` | A delivery has been delayed |
| `inventory.low` | Inventory has reached low stock level |
| `inventory.reordered` | Inventory has been automatically reordered |
| `security.alert` | A security alert has been triggered |

### Webhook Payload

```json
{
  "event": "delivery.completed",
  "timestamp": "2025-03-16T15:30:00Z",
  "data": {
    "delivery_id": 456,
    "route_id": 1,
    "status": "completed",
    "completion_time": "2025-03-16T15:28:45Z",
    "driver_id": 789
  }
}
```

### Signature Verification

Each webhook request includes an `X-Signature` header that should be verified:

```
X-Signature: sha256=5257a869e7bdf3ecf7f367434997ceb94b3a6204a9af1d908556c1a317c30644
```

To verify the signature:
1. Get the request body as raw string
2. Create an HMAC using SHA-256 and your webhook secret
3. Compare the generated signature with the one in the header

## Error Handling

All API errors follow a consistent format:

```json
{
  "success": false,
  "error": {
    "code": "invalid_request",
    "message": "The request was invalid",
    "details": [
      "The 'start_date' must be before 'end_date'"
    ]
  }
}
```

## SDK Libraries

We provide official SDK libraries for easy integration:

- [JavaScript/TypeScript](https://github.com/example/logistics-hub-js)
- [Python](https://github.com/example/logistics-hub-python)
- [Java](https://github.com/example/logistics-hub-java)
- [C#](https://github.com/example/logistics-hub-csharp)

## API Versioning

The API uses versioning in the URL path (e.g., `/v1/routes`). When breaking changes are introduced, a new version will be released. We maintain backward compatibility for at least 12 months after a new version is released.

## Support

For API support, please contact:
- Email: api-support@example.com
- Developer Portal: https://developers.logistics-hub.example.com
