# AI-Powered Smart Logistics Hub - Installation Guide

This guide provides step-by-step instructions for installing and setting up the AI-Powered Smart Logistics Hub platform.

## System Requirements

### Hardware Requirements
- **CPU**: 4+ cores recommended
- **RAM**: 8GB minimum, 16GB recommended
- **Storage**: 20GB minimum free space
- **Network**: Broadband internet connection

### Software Requirements
- **Operating System**: Ubuntu 20.04+, Windows 10/11, or macOS 12+
- **Node.js**: v20.18.0 or higher
- **npm**: v10.2.0 or higher
- **Git**: v2.30.0 or higher

## Installation Steps

### 1. Clone the Repository

```bash
git clone https://github.com/your-organization/ai-logistics-hub.git
cd ai-logistics-hub
```

### 2. Install Dependencies

```bash
cd logistics-hub-app
npm install
```

### 3. Configure Environment Variables

Create a `.env.local` file in the `logistics-hub-app` directory with the following variables:

```
# Database Configuration
DATABASE_URL=your_database_connection_string

# Authentication
AUTH_SECRET=your_auth_secret_key
AUTH_TRUST_HOST=true

# API Keys (if applicable)
MAPS_API_KEY=your_maps_api_key
WEATHER_API_KEY=your_weather_api_key

# Deployment Environment
NODE_ENV=production
```

### 4. Initialize the Database

```bash
npx wrangler d1 execute DB --local --file=migrations/0001_initial.sql
```

### 5. Build the Application

```bash
npm run build
```

### 6. Start the Application

For development:
```bash
npm run dev
```

For production:
```bash
npm start
```

## Deployment Options

### Option 1: Local Deployment

Follow the installation steps above to deploy the application locally.

### Option 2: Cloudflare Pages Deployment

1. Install Wrangler CLI:
```bash
npm install -g wrangler
```

2. Authenticate with Cloudflare:
```bash
wrangler login
```

3. Deploy the application:
```bash
wrangler pages deploy .
```

### Option 3: Docker Deployment

1. Build the Docker image:
```bash
docker build -t ai-logistics-hub .
```

2. Run the Docker container:
```bash
docker run -p 3000:3000 -d ai-logistics-hub
```

## Troubleshooting

### Common Issues

1. **Database Connection Errors**
   - Verify your database connection string in the `.env.local` file
   - Ensure the database server is running and accessible

2. **Build Failures**
   - Clear the `.next` directory: `rm -rf .next`
   - Delete `node_modules` and reinstall: `rm -rf node_modules && npm install`

3. **API Key Issues**
   - Verify all API keys are correctly set in the `.env.local` file
   - Check API key permissions and quotas

### Getting Help

If you encounter any issues during installation, please:
1. Check the logs for error messages
2. Refer to the [FAQ section](https://example.com/faq) in the documentation
3. Contact support at support@example.com

## Next Steps

After successful installation:
1. Access the application at http://localhost:3000
2. Log in with the default admin credentials (username: admin@example.com, password: Admin123!)
3. Change the default password immediately
4. Follow the [User Manual](./user-manual.md) to configure the system for your organization
