-- Migration number: 0001 	 2025-03-16
DROP TABLE IF EXISTS users;
DROP TABLE IF EXISTS companies;
DROP TABLE IF EXISTS routes;
DROP TABLE IF EXISTS vehicles;
DROP TABLE IF EXISTS inventory;
DROP TABLE IF EXISTS deliveries;
DROP TABLE IF EXISTS weather_data;
DROP TABLE IF EXISTS risk_assessments;
DROP TABLE IF EXISTS sustainability_metrics;
DROP TABLE IF EXISTS security_logs;
DROP TABLE IF EXISTS access_logs;

-- Companies table
CREATE TABLE IF NOT EXISTS companies (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL,
  address TEXT,
  city TEXT,
  postal_code TEXT,
  contact_person TEXT,
  contact_email TEXT,
  contact_phone TEXT,
  subscription_tier TEXT NOT NULL DEFAULT 'basic',
  subscription_start_date DATETIME,
  subscription_end_date DATETIME,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
);

-- Users table
CREATE TABLE IF NOT EXISTS users (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  company_id INTEGER,
  email TEXT UNIQUE NOT NULL,
  password_hash TEXT NOT NULL,
  first_name TEXT,
  last_name TEXT,
  role TEXT NOT NULL DEFAULT 'user',
  last_login DATETIME,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (company_id) REFERENCES companies(id) ON DELETE CASCADE
);

-- Vehicles table
CREATE TABLE IF NOT EXISTS vehicles (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  company_id INTEGER NOT NULL,
  name TEXT NOT NULL,
  type TEXT NOT NULL,
  capacity REAL,
  fuel_type TEXT,
  fuel_efficiency REAL,
  status TEXT DEFAULT 'available',
  last_maintenance_date DATETIME,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (company_id) REFERENCES companies(id) ON DELETE CASCADE
);

-- Inventory table
CREATE TABLE IF NOT EXISTS inventory (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  company_id INTEGER NOT NULL,
  item_name TEXT NOT NULL,
  item_sku TEXT,
  quantity INTEGER NOT NULL DEFAULT 0,
  unit TEXT,
  warehouse_location TEXT,
  reorder_level INTEGER,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (company_id) REFERENCES companies(id) ON DELETE CASCADE
);

-- Routes table
CREATE TABLE IF NOT EXISTS routes (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  company_id INTEGER NOT NULL,
  name TEXT NOT NULL,
  start_location TEXT NOT NULL,
  end_location TEXT NOT NULL,
  distance REAL,
  estimated_duration INTEGER, -- in minutes
  optimized_route_json TEXT, -- JSON string of waypoints
  status TEXT DEFAULT 'planned',
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (company_id) REFERENCES companies(id) ON DELETE CASCADE
);

-- Deliveries table
CREATE TABLE IF NOT EXISTS deliveries (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  company_id INTEGER NOT NULL,
  route_id INTEGER,
  vehicle_id INTEGER,
  driver_id INTEGER,
  scheduled_date DATETIME,
  actual_start_time DATETIME,
  actual_end_time DATETIME,
  status TEXT DEFAULT 'scheduled',
  fuel_used REAL,
  carbon_footprint REAL,
  notes TEXT,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (company_id) REFERENCES companies(id) ON DELETE CASCADE,
  FOREIGN KEY (route_id) REFERENCES routes(id) ON DELETE SET NULL,
  FOREIGN KEY (vehicle_id) REFERENCES vehicles(id) ON DELETE SET NULL,
  FOREIGN KEY (driver_id) REFERENCES users(id) ON DELETE SET NULL
);

-- Weather data table
CREATE TABLE IF NOT EXISTS weather_data (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  location TEXT NOT NULL,
  timestamp DATETIME NOT NULL,
  temperature REAL,
  precipitation REAL,
  wind_speed REAL,
  weather_condition TEXT,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
);

-- Risk assessments table
CREATE TABLE IF NOT EXISTS risk_assessments (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  route_id INTEGER,
  risk_level TEXT NOT NULL,
  risk_factors TEXT,
  recommendations TEXT,
  assessed_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (route_id) REFERENCES routes(id) ON DELETE CASCADE
);

-- Sustainability metrics table
CREATE TABLE IF NOT EXISTS sustainability_metrics (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  company_id INTEGER NOT NULL,
  date DATE NOT NULL,
  total_distance REAL DEFAULT 0,
  total_fuel_used REAL DEFAULT 0,
  carbon_emissions REAL DEFAULT 0,
  energy_efficiency_score REAL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (company_id) REFERENCES companies(id) ON DELETE CASCADE
);

-- Security logs table
CREATE TABLE IF NOT EXISTS security_logs (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER,
  action TEXT NOT NULL,
  ip_address TEXT,
  details TEXT,
  severity TEXT DEFAULT 'info',
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE SET NULL
);

-- Access logs table
CREATE TABLE IF NOT EXISTS access_logs (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER,
  ip_address TEXT,
  path TEXT,
  method TEXT,
  status_code INTEGER,
  accessed_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE SET NULL
);

-- Initial data
INSERT INTO companies (name, city, subscription_tier) VALUES 
  ('Western Sydney Logistics', 'Parramatta', 'premium'),
  ('Penrith Delivery Services', 'Penrith', 'standard'),
  ('Badgerys Creek Warehousing', 'Badgerys Creek', 'basic');

INSERT INTO users (company_id, email, password_hash, first_name, last_name, role) VALUES 
  (1, 'admin@wslogistics.com', 'hashed_password_placeholder', 'Admin', 'User', 'admin'),
  (1, 'manager@wslogistics.com', 'hashed_password_placeholder', 'Manager', 'User', 'manager'),
  (2, 'admin@penrithdelivery.com', 'hashed_password_placeholder', 'Admin', 'User', 'admin');

-- Create indexes
CREATE INDEX idx_users_company_id ON users(company_id);
CREATE INDEX idx_users_email ON users(email);
CREATE INDEX idx_vehicles_company_id ON vehicles(company_id);
CREATE INDEX idx_inventory_company_id ON inventory(company_id);
CREATE INDEX idx_routes_company_id ON routes(company_id);
CREATE INDEX idx_deliveries_company_id ON deliveries(company_id);
CREATE INDEX idx_deliveries_route_id ON deliveries(route_id);
CREATE INDEX idx_deliveries_vehicle_id ON deliveries(vehicle_id);
CREATE INDEX idx_deliveries_driver_id ON deliveries(driver_id);
CREATE INDEX idx_weather_data_location ON weather_data(location);
CREATE INDEX idx_weather_data_timestamp ON weather_data(timestamp);
CREATE INDEX idx_risk_assessments_route_id ON risk_assessments(route_id);
CREATE INDEX idx_sustainability_metrics_company_id ON sustainability_metrics(company_id);
CREATE INDEX idx_security_logs_user_id ON security_logs(user_id);
CREATE INDEX idx_access_logs_user_id ON access_logs(user_id);
