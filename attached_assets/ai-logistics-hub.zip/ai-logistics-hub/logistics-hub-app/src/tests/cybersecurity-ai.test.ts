import { describe, it, expect, vi } from 'vitest'
import { detectSuspiciousLogin, detectDataAccessAnomalies, detectAPIAbuse } from '@/lib/ai/cybersecurity-ai'

// Mock data
const mockUserId = 123
const mockLoginData = {
  timestamp: '2025-03-16T10:30:00',
  ipAddress: '192.168.1.105',
  userAgent: 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
  success: true
}
const mockAccessData = {
  timestamp: '2025-03-16T11:45:00',
  resource: '/api/inventory',
  action: 'read',
  recordCount: 50
}
const mockAPIData = {
  endpoint: '/api/routes',
  method: 'GET',
  ipAddress: '192.168.1.105',
  timestamp: '2025-03-16T14:20:00',
  requestCount: 25,
  timeWindow: 5 // minutes
}

// Mock the database functions
vi.mock('@/lib/db', () => ({
  LogisticsDB: {
    getUserById: vi.fn((userId) => {
      return {
        id: userId,
        email: 'user@example.com',
        name: 'Test User',
        role: 'Admin'
      }
    }),
    logSecurityEvent: vi.fn(() => Promise.resolve({ id: 1 })),
    logAccess: vi.fn(() => Promise.resolve({ id: 1 }))
  }
}))

// Mock next/headers
vi.mock('next/headers', () => ({
  headers: () => ({
    get: (name) => name === 'x-forwarded-for' ? '192.168.1.105' : null
  })
}))

// Mock Cloudflare context
vi.mock('@opennextjs/cloudflare', () => ({
  getCloudflareContext: vi.fn(() => {
    return {
      env: {
        DB: {
          prepare: vi.fn(() => ({
            bind: vi.fn(() => ({
              all: vi.fn(() => ({ 
                results: [
                  {
                    id: 1,
                    user_id: 123,
                    action: 'login',
                    ip_address: '192.168.1.105',
                    details: 'Successful login for user user@example.com',
                    created_at: '2025-03-16T09:30:00'
                  },
                  {
                    id: 2,
                    user_id: 123,
                    action: 'login',
                    ip_address: '192.168.1.105',
                    details: 'Successful login for user user@example.com',
                    created_at: '2025-03-15T14:45:00'
                  }
                ] 
              })),
              run: vi.fn(() => Promise.resolve())
            }))
          })
        }
      }
    }
  })
}))

describe('Cybersecurity AI', () => {
  describe('Suspicious Login Detection', () => {
    it('should analyze login attempts and detect suspicious patterns', async () => {
      const result = await detectSuspiciousLogin(mockUserId, mockLoginData)
      
      // Check that the result has the expected properties
      expect(result).toHaveProperty('success')
      expect(result).toHaveProperty('userId')
      expect(result).toHaveProperty('email')
      expect(result).toHaveProperty('timestamp')
      expect(result).toHaveProperty('riskLevel')
      expect(result).toHaveProperty('riskFactors')
      expect(result).toHaveProperty('isUnusualLocation')
      expect(result).toHaveProperty('isOutsideBusinessHours')
      
      // Check that the detection was successful
      expect(result.success).toBe(true)
      expect(result.userId).toBe(mockUserId)
      
      // Risk level should be one of: low, medium, high
      expect(['low', 'medium', 'high']).toContain(result.riskLevel)
      
      // Risk factors should be an array
      expect(Array.isArray(result.riskFactors)).toBe(true)
    })
    
    it('should detect failed login attempts as suspicious', async () => {
      const failedLoginData = {
        ...mockLoginData,
        success: false,
        failureReason: 'Invalid password'
      }
      
      const result = await detectSuspiciousLogin(mockUserId, failedLoginData)
      
      // Check that the detection was successful
      expect(result.success).toBe(true)
      
      // Risk level should be higher for failed logins
      expect(result.riskLevel).not.toBe('low')
    })
    
    it('should handle errors gracefully', async () => {
      // Mock a failure in the user retrieval
      vi.mocked(LogisticsDB.getUserById).mockRejectedValueOnce(new Error('Database error'))
      
      const result = await detectSuspiciousLogin(mockUserId, mockLoginData)
      
      // Check that we got an error result
      expect(result.success).toBe(false)
      expect(result).toHaveProperty('message')
      expect(result.message).toBe('Failed to detect suspicious login')
    })
  })
  
  describe('Data Access Anomaly Detection', () => {
    it('should detect anomalous data access patterns', async () => {
      const result = await detectDataAccessAnomalies(mockUserId, mockAccessData)
      
      // Check that the result has the expected properties
      expect(result).toHaveProperty('success')
      expect(result).toHaveProperty('userId')
      expect(result).toHaveProperty('email')
      expect(result).toHaveProperty('resource')
      expect(result).toHaveProperty('action')
      expect(result).toHaveProperty('timestamp')
      expect(result).toHaveProperty('isAnomalous')
      expect(result).toHaveProperty('riskLevel')
      expect(result).toHaveProperty('riskFactors')
      
      // Check that the detection was successful
      expect(result.success).toBe(true)
      expect(result.userId).toBe(mockUserId)
      
      // Risk level should be one of: low, medium, high
      expect(['low', 'medium', 'high']).toContain(result.riskLevel)
    })
    
    it('should detect mass deletions as high risk', async () => {
      const massDeleteData = {
        ...mockAccessData,
        action: 'delete',
        recordCount: 100
      }
      
      const result = await detectDataAccessAnomalies(mockUserId, massDeleteData)
      
      // Check that the detection was successful
      expect(result.success).toBe(true)
      
      // Risk level should be high for mass deletions
      expect(result.riskLevel).toBe('high')
      expect(result.riskFactors.some(factor => factor.includes('Mass deletion'))).toBe(true)
    })
  })
  
  describe('API Abuse Detection', () => {
    it('should detect API abuse patterns', async () => {
      const result = await detectAPIAbuse(mockAPIData)
      
      // Check that the result has the expected properties
      expect(result).toHaveProperty('success')
      expect(result).toHaveProperty('endpoint')
      expect(result).toHaveProperty('method')
      expect(result).toHaveProperty('ipAddress')
      expect(result).toHaveProperty('timestamp')
      expect(result).toHaveProperty('requestCount')
      expect(result).toHaveProperty('rateLimit')
      expect(result).toHaveProperty('isAbusive')
      expect(result).toHaveProperty('riskLevel')
      expect(result).toHaveProperty('riskFactors')
      expect(result).toHaveProperty('recommendedAction')
      
      // Check that the detection was successful
      expect(result.success).toBe(true)
      
      // Risk level should be one of: low, medium, high
      expect(['low', 'medium', 'high']).toContain(result.riskLevel)
    })
    
    it('should detect excessive API requests as abusive', async () => {
      const excessiveAPIData = {
        ...mockAPIData,
        requestCount: 200 // Much higher than rate limit
      }
      
      const result = await detectAPIAbuse(excessiveAPIData)
      
      // Check that the detection was successful
      expect(result.success).toBe(true)
      
      // Should be detected as abusive
      expect(result.isAbusive).toBe(true)
      
      // Risk level should be high for excessive requests
      expect(result.riskLevel).toBe('high')
      
      // Should recommend blocking
      expect(result.recommendedAction).toContain('Block IP')
    })
  })
})
