import { describe, it, expect, vi } from 'vitest'
import { calculateOptimalRoute } from '@/lib/route-optimizer'

// Mock data
const mockOrigin = 'Parramatta Distribution Center'
const mockDestination = 'Penrith Retail Hub'
const mockWaypoints = [
  { location: 'Westmead Hospital', priority: 'high' },
  { location: 'Blacktown Shopping Centre', priority: 'medium' }
]

// Mock the distance calculation function
vi.mock('@/lib/db', () => ({
  LogisticsDB: {
    getDistanceBetween: vi.fn((origin, destination) => {
      // Return mock distances based on location pairs
      if (origin === 'Parramatta Distribution Center' && destination === 'Westmead Hospital') {
        return 5.2
      } else if (origin === 'Westmead Hospital' && destination === 'Blacktown Shopping Centre') {
        return 12.8
      } else if (origin === 'Blacktown Shopping Centre' && destination === 'Penrith Retail Hub') {
        return 15.3
      } else if (origin === 'Parramatta Distribution Center' && destination === 'Blacktown Shopping Centre') {
        return 14.5
      } else if (origin === 'Westmead Hospital' && destination === 'Penrith Retail Hub') {
        return 20.1
      } else if (origin === 'Parramatta Distribution Center' && destination === 'Penrith Retail Hub') {
        return 24.5
      } else {
        return 10.0 // Default fallback
      }
    })
  }
}))

describe('Route Optimizer', () => {
  it('should calculate the optimal route with waypoints', async () => {
    const result = await calculateOptimalRoute(mockOrigin, mockDestination, mockWaypoints)
    
    // Check that the result has the expected properties
    expect(result).toHaveProperty('distance')
    expect(result).toHaveProperty('duration')
    expect(result).toHaveProperty('optimizedWaypoints')
    expect(result).toHaveProperty('optimizedRouteJson')
    
    // Check that the distance is calculated correctly
    // Expected route: Parramatta -> Westmead -> Blacktown -> Penrith
    // Expected distance: 5.2 + 12.8 + 15.3 = 33.3
    expect(result.distance).toBeCloseTo(33.3, 1)
    
    // Check that the waypoints are in the correct order
    expect(result.optimizedWaypoints).toHaveLength(2)
    expect(result.optimizedWaypoints[0].location).toBe('Westmead Hospital')
    expect(result.optimizedWaypoints[1].location).toBe('Blacktown Shopping Centre')
  })
  
  it('should prioritize high priority waypoints', async () => {
    // Modify waypoints to test priority handling
    const waypointsWithPriority = [
      { location: 'Westmead Hospital', priority: 'low' },
      { location: 'Blacktown Shopping Centre', priority: 'high' }
    ]
    
    const result = await calculateOptimalRoute(mockOrigin, mockDestination, waypointsWithPriority)
    
    // Check that high priority waypoint is visited first
    expect(result.optimizedWaypoints[0].location).toBe('Blacktown Shopping Centre')
    expect(result.optimizedWaypoints[1].location).toBe('Westmead Hospital')
  })
  
  it('should handle empty waypoints', async () => {
    const result = await calculateOptimalRoute(mockOrigin, mockDestination, [])
    
    // Check direct route calculation
    expect(result.distance).toBeCloseTo(24.5, 1)
    expect(result.optimizedWaypoints).toHaveLength(0)
  })
  
  it('should handle errors gracefully', async () => {
    // Mock a failure in the distance calculation
    vi.mocked(LogisticsDB.getDistanceBetween).mockRejectedValueOnce(new Error('Database error'))
    
    // The function should return a fallback result rather than throwing
    const result = await calculateOptimalRoute(mockOrigin, mockDestination, mockWaypoints)
    
    // Check that we got a fallback result
    expect(result).toHaveProperty('distance')
    expect(result).toHaveProperty('error')
    expect(result.error).toBe('Failed to calculate optimal route')
  })
})
