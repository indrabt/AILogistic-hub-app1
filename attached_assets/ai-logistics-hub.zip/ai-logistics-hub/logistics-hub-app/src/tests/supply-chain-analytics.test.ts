import { describe, it, expect, vi } from 'vitest'
import { predictDemand, optimizeInventory, identifyBottlenecks } from '@/lib/ai/supply-chain-analytics'

// Mock data
const mockCompanyId = 1
const mockProductId = 123
const mockStartDate = '2025-03-01'
const mockEndDate = '2025-03-31'

// Mock the database functions
vi.mock('@/lib/db', () => ({
  LogisticsDB: {
    getHistoricalDemand: vi.fn((companyId, productId, startDate, endDate) => {
      return [
        { date: '2025-01-01', quantity: 100 },
        { date: '2025-01-08', quantity: 120 },
        { date: '2025-01-15', quantity: 90 },
        { date: '2025-01-22', quantity: 110 },
        { date: '2025-01-29', quantity: 130 },
        { date: '2025-02-05', quantity: 115 },
        { date: '2025-02-12', quantity: 125 },
        { date: '2025-02-19', quantity: 140 },
        { date: '2025-02-26', quantity: 135 }
      ]
    }),
    getInventoryLevels: vi.fn((companyId) => {
      return [
        { product_id: 123, name: 'Product A', current_stock: 200, reorder_point: 50, lead_time: 5 },
        { product_id: 456, name: 'Product B', current_stock: 30, reorder_point: 40, lead_time: 7 },
        { product_id: 789, name: 'Product C', current_stock: 150, reorder_point: 100, lead_time: 3 }
      ]
    }),
    getSupplyChainData: vi.fn((companyId) => {
      return {
        nodes: [
          { id: 'supplier_1', type: 'supplier', name: 'Supplier A', capacity: 500 },
          { id: 'warehouse_1', type: 'warehouse', name: 'Warehouse Sydney', capacity: 1000 },
          { id: 'warehouse_2', type: 'warehouse', name: 'Warehouse Parramatta', capacity: 800 },
          { id: 'store_1', type: 'store', name: 'Retail Store Penrith', capacity: 200 },
          { id: 'store_2', type: 'store', name: 'Retail Store Blacktown', capacity: 150 }
        ],
        edges: [
          { source: 'supplier_1', target: 'warehouse_1', flow: 400, capacity: 500 },
          { source: 'warehouse_1', target: 'warehouse_2', flow: 300, capacity: 400 },
          { source: 'warehouse_1', target: 'store_1', flow: 100, capacity: 150 },
          { source: 'warehouse_2', target: 'store_1', flow: 50, capacity: 100 },
          { source: 'warehouse_2', target: 'store_2', flow: 150, capacity: 200 }
        ]
      }
    })
  }
}))

describe('Supply Chain Analytics AI', () => {
  describe('Demand Forecasting', () => {
    it('should predict demand for a product over a time period', async () => {
      const result = await predictDemand(mockCompanyId, mockProductId, mockStartDate, mockEndDate)
      
      // Check that the result has the expected properties
      expect(result).toHaveProperty('success')
      expect(result).toHaveProperty('productId')
      expect(result).toHaveProperty('predictions')
      
      // Check that the prediction was successful
      expect(result.success).toBe(true)
      expect(result.productId).toBe(mockProductId)
      
      // Check that predictions array has data for each day in the period
      const startDateObj = new Date(mockStartDate)
      const endDateObj = new Date(mockEndDate)
      const daysDiff = Math.ceil((endDateObj - startDateObj) / (1000 * 60 * 60 * 24)) + 1
      
      expect(result.predictions).toHaveLength(daysDiff)
      
      // Check that each prediction has the required fields
      result.predictions.forEach(prediction => {
        expect(prediction).toHaveProperty('date')
        expect(prediction).toHaveProperty('quantity')
        expect(prediction).toHaveProperty('confidence')
        
        // Quantity should be a positive number
        expect(prediction.quantity).toBeGreaterThan(0)
        
        // Confidence should be between 0 and 1
        expect(prediction.confidence).toBeGreaterThan(0)
        expect(prediction.confidence).toBeLessThanOrEqual(1)
      })
    })
    
    it('should handle errors gracefully', async () => {
      // Mock a failure in the historical demand retrieval
      vi.mocked(LogisticsDB.getHistoricalDemand).mockRejectedValueOnce(new Error('Database error'))
      
      const result = await predictDemand(mockCompanyId, mockProductId, mockStartDate, mockEndDate)
      
      // Check that we got an error result
      expect(result.success).toBe(false)
      expect(result).toHaveProperty('message')
      expect(result.message).toBe('Failed to predict demand')
    })
  })
  
  describe('Inventory Optimization', () => {
    it('should optimize inventory levels and provide recommendations', async () => {
      const result = await optimizeInventory(mockCompanyId)
      
      // Check that the result has the expected properties
      expect(result).toHaveProperty('success')
      expect(result).toHaveProperty('inventoryItems')
      expect(result).toHaveProperty('recommendations')
      
      // Check that the optimization was successful
      expect(result.success).toBe(true)
      
      // Check that inventory items array has data
      expect(result.inventoryItems.length).toBeGreaterThan(0)
      
      // Check that each inventory item has the required fields
      result.inventoryItems.forEach(item => {
        expect(item).toHaveProperty('productId')
        expect(item).toHaveProperty('name')
        expect(item).toHaveProperty('currentStock')
        expect(item).toHaveProperty('recommendedReorderPoint')
        expect(item).toHaveProperty('recommendedOrderQuantity')
        expect(item).toHaveProperty('status')
      })
      
      // Check that recommendations array has data
      expect(result.recommendations.length).toBeGreaterThan(0)
    })
  })
  
  describe('Bottleneck Identification', () => {
    it('should identify bottlenecks in the supply chain', async () => {
      const result = await identifyBottlenecks(mockCompanyId)
      
      // Check that the result has the expected properties
      expect(result).toHaveProperty('success')
      expect(result).toHaveProperty('bottlenecks')
      expect(result).toHaveProperty('recommendations')
      
      // Check that the identification was successful
      expect(result.success).toBe(true)
      
      // Check that bottlenecks array has data
      expect(result.bottlenecks.length).toBeGreaterThan(0)
      
      // Check that each bottleneck has the required fields
      result.bottlenecks.forEach(bottleneck => {
        expect(bottleneck).toHaveProperty('nodeId')
        expect(bottleneck).toHaveProperty('nodeName')
        expect(bottleneck).toHaveProperty('nodeType')
        expect(bottleneck).toHaveProperty('utilizationRate')
        expect(bottleneck).toHaveProperty('severity')
        
        // Utilization rate should be between 0 and 1
        expect(bottleneck.utilizationRate).toBeGreaterThan(0)
        expect(bottleneck.utilizationRate).toBeLessThanOrEqual(1)
      })
      
      // Check that recommendations array has data
      expect(result.recommendations.length).toBeGreaterThan(0)
    })
  })
})
