'use client'
import { useState, useEffect } from 'react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { 
  Users, 
  UserPlus, 
  UserCheck, 
  UserX, 
  Shield, 
  Search,
  RefreshCw,
  Truck,
  Lock,
  Key
} from 'lucide-react'

export default function UsersPage() {
  const [loading, setLoading] = useState(true)
  const [selectedUser, setSelectedUser] = useState(null)
  
  useEffect(() => {
    // Simulate data loading
    const timer = setTimeout(() => {
      setLoading(false)
    }, 1000)
    
    return () => clearTimeout(timer)
  }, [])
  
  // Sample user data
  const users = [
    {
      id: 1,
      name: 'John Smith',
      email: 'john.smith@example.com',
      role: 'Admin',
      department: 'Operations',
      status: 'active',
      lastLogin: '2025-03-16T10:30:00',
      createdAt: '2024-05-10T09:00:00',
      permissions: ['view_all', 'edit_all', 'manage_users', 'manage_routes', 'manage_inventory'],
      securityLevel: 'high'
    },
    {
      id: 2,
      name: 'Sarah Johnson',
      email: 'sarah.johnson@example.com',
      role: 'Driver',
      department: 'Logistics',
      status: 'active',
      lastLogin: '2025-03-16T08:15:00',
      createdAt: '2024-06-22T14:30:00',
      permissions: ['view_routes', 'update_delivery_status'],
      securityLevel: 'medium'
    },
    {
      id: 3,
      name: 'Michael Wong',
      email: 'michael.wong@example.com',
      role: 'Warehouse Manager',
      department: 'Inventory',
      status: 'active',
      lastLogin: '2025-03-15T16:45:00',
      createdAt: '2024-04-15T11:20:00',
      permissions: ['view_inventory', 'edit_inventory', 'view_routes'],
      securityLevel: 'medium'
    },
    {
      id: 4,
      name: 'Emily Davis',
      email: 'emily.davis@example.com',
      role: 'Analyst',
      department: 'Analytics',
      status: 'inactive',
      lastLogin: '2025-03-10T09:20:00',
      createdAt: '2024-08-05T10:15:00',
      permissions: ['view_analytics', 'export_reports'],
      securityLevel: 'medium'
    },
    {
      id: 5,
      name: 'Robert Chen',
      email: 'robert.chen@example.com',
      role: 'Customer Service',
      department: 'Support',
      status: 'active',
      lastLogin: '2025-03-16T11:05:00',
      createdAt: '2024-07-18T13:40:00',
      permissions: ['view_deliveries', 'update_customer_info'],
      securityLevel: 'low'
    }
  ]
  
  return (
    <main className="flex min-h-screen flex-col">
      <div className="flex flex-col">
        <header className="border-b">
          <div className="flex h-16 items-center px-4 md:px-6">
            <div className="flex items-center gap-2">
              <Truck className="h-6 w-6" />
              <h1 className="text-xl font-bold">AI-Powered Smart Logistics Hub</h1>
            </div>
            <nav className="ml-auto flex gap-4 sm:gap-6">
              <Button variant="ghost">Dashboard</Button>
              <Button variant="ghost">Routes</Button>
              <Button variant="ghost">Inventory</Button>
              <Button variant="ghost">Analytics</Button>
              <Button variant="ghost">Settings</Button>
            </nav>
            <div className="ml-auto flex items-center gap-4">
              <Button variant="outline" size="sm">
                Western Sydney Logistics
              </Button>
              <Button size="sm">Sign Out</Button>
            </div>
          </div>
        </header>
        <div className="flex-1 space-y-4 p-8 pt-6">
          <div className="flex items-center justify-between space-y-2">
            <h2 className="text-3xl font-bold tracking-tight">User Management</h2>
            <div className="flex items-center space-x-2">
              <div className="relative">
                <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
                <Input
                  type="search"
                  placeholder="Search users..."
                  className="w-[200px] pl-8 md:w-[300px]"
                />
              </div>
              <Button variant="outline">
                <RefreshCw className="mr-2 h-4 w-4" />
                Refresh
              </Button>
              <Button>
                <UserPlus className="mr-2 h-4 w-4" />
                Add User
              </Button>
            </div>
          </div>
          
          <div className="grid gap-4 md:grid-cols-7">
            <Card className="col-span-2">
              <CardHeader>
                <CardTitle>Users</CardTitle>
                <CardDescription>
                  Manage system users and permissions
                </CardDescription>
              </CardHeader>
              <CardContent>
                {loading ? (
                  <div className="flex h-[400px] items-center justify-center">
                    <div className="h-8 w-8 animate-spin rounded-full border-4 border-primary border-t-transparent"></div>
                  </div>
                ) : (
                  <div className="space-y-4">
                    {users.map(user => (
                      <div 
                        key={user.id}
                        className={`p-3 rounded-md cursor-pointer transition-colors ${
                          selectedUser?.id === user.id 
                            ? 'bg-primary/10 border border-primary/20' 
                            : 'hover:bg-muted'
                        }`}
                        onClick={() => setSelectedUser(user)}
                      >
                        <div className="flex items-center">
                          <div className={`h-8 w-8 rounded-full flex items-center justify-center mr-2 ${
                            user.status === 'active' ? 'bg-green-100 text-green-700' : 'bg-gray-100 text-gray-500'
                          }`}>
                            {user.name.charAt(0)}
                          </div>
                          <div className="ml-2 space-y-1">
                            <p className="text-sm font-medium leading-none">
                              {user.name}
                            </p>
                            <p className="text-xs text-muted-foreground">
                              {user.role} • {user.department}
                            </p>
                          </div>
                          <div className={`ml-auto text-xs font-medium ${
                            user.status === 'active' ? 'text-green-600' : 'text-gray-500'
                          }`}>
                            {user.status === 'active' ? 'Active' : 'Inactive'}
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>
            
            <Card className="col-span-5">
              <CardHeader>
                <CardTitle>User Details</CardTitle>
                <CardDescription>
                  {selectedUser 
                    ? `Viewing details for ${selectedUser.name}`
                    : 'Select a user from the list to view details'}
                </CardDescription>
              </CardHeader>
              <CardContent>
                {loading ? (
                  <div className="flex h-[400px] items-center justify-center">
                    <div className="h-8 w-8 animate-spin rounded-full border-4 border-primary border-t-transparent"></div>
                  </div>
                ) : !selectedUser ? (
                  <div className="flex h-[400px] items-center justify-center flex-col">
                    <Users className="h-16 w-16 text-muted-foreground mb-4" />
                    <p className="text-muted-foreground">Select a user to view details</p>
                  </div>
                ) : (
                  <div className="space-y-6">
                    <Tabs defaultValue="profile" className="w-full">
                      <TabsList className="grid w-full grid-cols-3">
                        <TabsTrigger value="profile">Profile</TabsTrigger>
                        <TabsTrigger value="permissions">Permissions</TabsTrigger>
                        <TabsTrigger value="security">Security</TabsTrigger>
                      </TabsList>
                      <TabsContent value="profile" className="space-y-4 pt-4">
                        <div className="grid grid-cols-2 gap-4">
                          <div>
                            <Label>Full Name</Label>
                            <Input value={selectedUser.name} className="mt-1" />
                          </div>
                          <div>
                            <Label>Email</Label>
                            <Input value={selectedUser.email} className="mt-1" />
                          </div>
                        </div>
                        
                        <div className="grid grid-cols-2 gap-4">
                          <div>
                            <Label>Role</Label>
                            <Input value={selectedUser.role} className="mt-1" />
                          </div>
                          <div>
                            <Label>Department</Label>
                            <Input value={selectedUser.department} className="mt-1" />
                          </div>
                        </div>
                        
                        <div className="grid grid-cols-2 gap-4">
                          <div>
                            <Label>Status</Label>
                            <div className={`mt-1 p-2 rounded-md font-medium ${
                              selectedUser.status === 'active' ? 'bg-green-100 text-green-800' : 'bg-gray-100 text-gray-800'
                            }`}>
                              {selectedUser.status === 'active' ? 'Active' : 'Inactive'}
                            </div>
                          </div>
                          <div>
                            <Label>Last Login</Label>
                            <Input 
                              value={new Date(selectedUser.lastLogin).toLocaleString()} 
                              readOnly 
                              className="mt-1" 
                            />
                          </div>
                        </div>
                        
                        <div className="grid grid-cols-1 gap-4">
                          <div>
                            <Label>Account Created</Label>
                            <Input 
                              value={new Date(selectedUser.createdAt).toLocaleString()} 
                              readOnly 
                              className="mt-1" 
                            />
                          </div>
                        </div>
                        
                        <div className="flex justify-end space-x-2 pt-4">
                          <Button variant="outline">Reset Password</Button>
                          <Button variant={selectedUser.status === 'active' ? 'destructive' : 'default'}>
                            {selectedUser.status === 'active' ? 'Deactivate User' : 'Activate User'}
                          </Button>
                          <Button>Save Changes</Button>
                        </div>
                      </TabsContent>
                      
                      <TabsContent value="permissions" className="space-y-4 pt-4">
                        <div className="space-y-4">
                          <div className="grid grid-cols-2 gap-4">
                            <Card className="col-span-1">
                              <CardHeader className="pb-2">
                                <CardTitle className="text-sm">View Permissions</CardTitle>
                              </CardHeader>
                              <CardContent>
                                <div className="space-y-2">
                                  <div className="flex items-center space-x-2">
                                    <input 
                                      type="checkbox" 
                                      id="view_dashboard" 
                                      checked={selectedUser.permissions.includes('view_all')} 
                                      className="h-4 w-4 rounded border-gray-300"
                                    />
                                    <label htmlFor="view_dashboard" className="text-sm">View Dashboard</label>
                                  </div>
                                  <div className="flex items-center space-x-2">
                                    <input 
                                      type="checkbox" 
                                      id="view_routes" 
                                      checked={selectedUser.permissions.includes('view_routes') || selectedUser.permissions.includes('view_all')} 
                                      className="h-4 w-4 rounded border-gray-300"
                                    />
                                    <label htmlFor="view_routes" className="text-sm">View Routes</label>
                                  </div>
                                  <div className="flex items-center space-x-2">
                                    <input 
                                      type="checkbox" 
                                      id="view_inventory" 
                                      checked={selectedUser.permissions.includes('view_inventory') || selectedUser.permissions.includes('view_all')} 
                                      className="h-4 w-4 rounded border-gray-300"
                                    />
                                    <label htmlFor="view_inventory" className="text-sm">View Inventory</label>
                                  </div>
                                  <div className="flex items-center space-x-2">
                                    <input 
                                      type="checkbox" 
                                      id="view_analytics" 
                                      checked={selectedUser.permissions.includes('view_analytics') || selectedUser.permissions.includes('view_all')} 
                                      className="h-4 w-4 rounded border-gray-300"
                                    />
                                    <label htmlFor="view_analytics" className="text-sm">View Analytics</label>
                                  </div>
                                  <div className="flex items-center space-x-2">
                                    <input 
                                      type="checkbox" 
                                      id="view_users" 
                                      checked={selectedUser.permissions.includes('manage_users') || selectedUser.permissions.includes('view_all')} 
                                      className="h-4 w-4 rounded border-gray-300"
                                    />
                                    <label htmlFor="view_users" className="text-sm">View Users</label>
                                  </div>
                                </div>
                              </CardContent>
                            </Card>
                            
                            <Card className="col-span-1">
                              <CardHeader className="pb-2">
                                <CardTitle className="text-sm">Edit Permissions</CardTitle>
                              </CardHeader>
                              <CardContent>
                                <div className="space-y-2">
                                  <div className="flex items-center space-x-2">
                                    <input 
                                      type="checkbox" 
                                      id="edit_routes" 
                                      checked={selectedUser.permissions.includes('edit_all')} 
                                      className="h-4 w-4 rounded border-gray-300"
                                    />
                                    <label htmlFor="edit_routes" className="text-sm">Edit Routes</label>
                                  </div>
                                  <div className="flex items-center space-x-2">
                                    <input 
                                      type="checkbox" 
                                      id="edit_inventory" 
                                      checked={selectedUser.permissions.includes('edit_inventory') || selectedUser.permissions.includes('edit_all')} 
                                      className="h-4 w-4 rounded border-gray-300"
                                    />
                                    <label htmlFor="edit_inventory" className="text-sm">Edit Inventory</label>
                                  </div>
                                  <div className="flex items-center space-x-2">
                                    <input 
                                      type="checkbox" 
                                      id="update_delivery" 
                                      checked={selectedUser.permissions.includes('update_delivery_status') || selectedUser.permissions.includes('edit_all')} 
                                      className="h-4 w-4 rounded border-gray-300"
                                    />
                                    <label htmlFor="update_delivery" className="text-sm">Update Delivery Status</label>
                                  </div>
                                  <div className="flex items-center space-x-2">
                                    <input 
                                      type="checkbox" 
                                      id="export_reports" 
                                      checked={selectedUser.permissions.includes('export_reports') || selectedUser.permissions.includes('edit_all')} 
                                      className="h-4 w-4 rounded border-gray-300"
                                    />
                                    <label htmlFor="export_reports" className="text-sm">Export Reports</label>
                                  </div>
                                  <div className="flex items-center space-x-2">
                                    <input 
                                      type="checkbox" 
                                      id="update_customer" 
                                      checked={selectedUser.permissions.includes('update_customer_info') || selectedUser.permissions.includes('edit_all')} 
                                      className="h-4 w-4 rounded border-gray-300"
                                    />
                                    <label htmlFor="update_customer" className="text-sm">Update Customer Info</label>
                                  </div>
                                </div>
                              </CardContent>
                            </Card>
                          </div>
                          
                          <Card>
                            <CardHeader className="pb-2">
                              <CardTitle className="text-sm">Administrative Permissions</CardTitle>
                            </CardHeader>
                            <CardContent>
                              <div className="grid grid-cols-2 gap-4">
                                <div className="space-y-2">
                                  <div className="flex items-center space-x-2">
                                    <input 
                                      type="checkbox" 
                                      id="manage_users" 
                                      checked={selectedUser.permissions.includes('manage_users')} 
                                      className="h-4 w-4 rounded border-gray-300"
                                    />
                                    <label htmlFor="manage_users" className="text-sm">Manage Users</label>
                                  </div>
                                  <div className="flex items-center space-x-2">
                                    <input 
                                      type="checkbox" 
                                      id="manage_routes" 
                                      checked={selectedUser.permissions.includes('manage_routes')} 
                                      className="h-4 w-4 rounded border-gray-300"
                                    />
                                    <label htmlFor="manage_routes" className="text-sm">Manage Routes</label>
                                  </div>
                                </div>
                                <div className="space-y-2">
                                  <div className="flex items-center space-x-2">
                                    <input 
                                      type="checkbox" 
                                      id="manage_inventory" 
                                      checked={selectedUser.permissions.includes('manage_inventory')} 
                                      className="h-4 w-4 rounded border-gray-300"
                                    />
                                    <label htmlFor="manage_inventory" className="text-sm">Manage Inventory</label>
                                  </div>
                                  <div className="flex items-center space-x-2">
                                    <input 
                                      type="checkbox" 
                                      id="system_settings" 
                                      checked={selectedUser.permissions.includes('system_settings')} 
                                      className="h-4 w-4 rounded border-gray-300"
                                    />
                                    <label htmlFor="system_settings" className="text-sm">System Settings</label>
                                  </div>
                                </div>
                              </div>
                            </CardContent>
                          </Card>
                        </div>
                        
                        <div className="flex justify-end space-x-2 pt-4">
                          <Button variant="outline">Reset to Default</Button>
                          <Button>Save Permissions</Button>
                        </div>
                      </TabsContent>
                      
                      <TabsContent value="security" className="space-y-4 pt-4">
                        <Card>
                          <CardHeader>
                            <CardTitle>Security Settings</CardTitle>
                            <CardDescription>
                              Manage user security settings and access controls
                            </CardDescription>
                          </CardHeader>
                          <CardContent className="space-y-4">
                            <div className="grid grid-cols-2 gap-4">
                              <div>
                                <Label>Security Level</Label>
                                <div className={`mt-1 p-2 rounded-md font-medium ${
                                  selectedUser.securityLevel === 'high' ? 'bg-red-100 text-red-800' :
                                  selectedUser.securityLevel === 'medium' ? 'bg-yellow-100 text-yellow-800' :
                                  'bg-green-100 text-green-800'
                                }`}>
                                  {selectedUser.securityLevel.charAt(0).toUpperCase() + selectedUser.securityLevel.slice(1)}
                                </div>
                              </div>
                              <div>
                                <Label>Two-Factor Authentication</Label>
                                <div className="mt-1 flex items-center space-x-2">
                                  <input 
                                    type="checkbox" 
                                    id="enable_2fa" 
                                    checked={selectedUser.securityLevel === 'high'} 
                                    className="h-4 w-4 rounded border-gray-300"
                                  />
                                  <label htmlFor="enable_2fa" className="text-sm">Enable 2FA</label>
                                </div>
                              </div>
                            </div>
                            
                            <div>
                              <Label>Password Requirements</Label>
                              <div className="mt-1 space-y-2">
                                <div className="flex items-center space-x-2">
                                  <input 
                                    type="checkbox" 
                                    id="complex_password" 
                                    checked={true} 
                                    className="h-4 w-4 rounded border-gray-300"
                                  />
                                  <label htmlFor="complex_password" className="text-sm">Require complex password</label>
                                </div>
                                <div className="flex items-center space-x-2">
                                  <input 
                                    type="checkbox" 
                                    id="password_expiry" 
                                    checked={selectedUser.securityLevel !== 'low'} 
                                    className="h-4 w-4 rounded border-gray-300"
                                  />
                                  <label htmlFor="password_expiry" className="text-sm">Password expires every 90 days</label>
                                </div>
                              </div>
                            </div>
                            
                            <div>
                              <Label>Login Restrictions</Label>
                              <div className="mt-1 space-y-2">
                                <div className="flex items-center space-x-2">
                                  <input 
                                    type="checkbox" 
                                    id="ip_restriction" 
                                    checked={selectedUser.securityLevel === 'high'} 
                                    className="h-4 w-4 rounded border-gray-300"
                                  />
                                  <label htmlFor="ip_restriction" className="text-sm">Restrict login to specific IP addresses</label>
                                </div>
                                <div className="flex items-center space-x-2">
                                  <input 
                                    type="checkbox" 
                                    id="time_restriction" 
                                    checked={selectedUser.securityLevel !== 'low'} 
                                    className="h-4 w-4 rounded border-gray-300"
                                  />
                                  <label htmlFor="time_restriction" className="text-sm">Restrict login to business hours</label>
                                </div>
                              </div>
                            </div>
                            
                            <div className="pt-4">
                              <Button variant="outline" className="mr-2">
                                <Lock className="mr-2 h-4 w-4" />
                                Lock Account
                              </Button>
                              <Button variant="outline">
                                <Key className="mr-2 h-4 w-4" />
                                Reset Security Settings
                              </Button>
                            </div>
                          </CardContent>
                        </Card>
                        
                        <Card>
                          <CardHeader>
                            <CardTitle>Recent Security Events</CardTitle>
                          </CardHeader>
                          <CardContent>
                            <div className="space-y-4">
                              <div className="flex items-start">
                                <Shield className="mr-2 h-5 w-5 text-green-500 mt-0.5" />
                                <div className="space-y-1">
                                  <p className="text-sm font-medium leading-none">
                                    Successful login
                                  </p>
                                  <p className="text-sm text-muted-foreground">
                                    {new Date(selectedUser.lastLogin).toLocaleString()} • IP: 192.168.1.105
                                  </p>
                                </div>
                              </div>
                              <div className="flex items-start">
                                <Shield className="mr-2 h-5 w-5 text-green-500 mt-0.5" />
                                <div className="space-y-1">
                                  <p className="text-sm font-medium leading-none">
                                    Password changed
                                  </p>
                                  <p className="text-sm text-muted-foreground">
                                    2025-03-10T14:25:00 • IP: 192.168.1.105
                                  </p>
                                </div>
                              </div>
                              {selectedUser.securityLevel === 'high' && (
                                <div className="flex items-start">
                                  <Shield className="mr-2 h-5 w-5 text-yellow-500 mt-0.5" />
                                  <div className="space-y-1">
                                    <p className="text-sm font-medium leading-none">
                                      Failed login attempt
                                    </p>
                                    <p className="text-sm text-muted-foreground">
                                      2025-03-09T22:15:00 • IP: 203.45.67.89
                                    </p>
                                  </div>
                                </div>
                              )}
                            </div>
                          </CardContent>
                        </Card>
                      </TabsContent>
                    </Tabs>
                  </div>
                )}
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </main>
  )
}
