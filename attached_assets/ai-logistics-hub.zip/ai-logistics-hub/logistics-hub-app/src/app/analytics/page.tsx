'use client'
import { useState, useEffect } from 'react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { 
  BarChart, 
  LineChart, 
  PieChart, 
  TrendingUp, 
  TrendingDown, 
  Calendar, 
  Download,
  Filter,
  RefreshCw,
  Truck,
  Package,
  Leaf
} from 'lucide-react'

export default function AnalyticsPage() {
  const [loading, setLoading] = useState(true)
  
  useEffect(() => {
    // Simulate data loading
    const timer = setTimeout(() => {
      setLoading(false)
    }, 1000)
    
    return () => clearTimeout(timer)
  }, [])
  
  return (
    <main className="flex min-h-screen flex-col">
      <div className="flex flex-col">
        <header className="border-b">
          <div className="flex h-16 items-center px-4 md:px-6">
            <div className="flex items-center gap-2">
              <Truck className="h-6 w-6" />
              <h1 className="text-xl font-bold">AI-Powered Smart Logistics Hub</h1>
            </div>
            <nav className="ml-auto flex gap-4 sm:gap-6">
              <Button variant="ghost">Dashboard</Button>
              <Button variant="ghost">Routes</Button>
              <Button variant="ghost">Inventory</Button>
              <Button variant="ghost">Analytics</Button>
              <Button variant="ghost">Settings</Button>
            </nav>
            <div className="ml-auto flex items-center gap-4">
              <Button variant="outline" size="sm">
                Western Sydney Logistics
              </Button>
              <Button size="sm">Sign Out</Button>
            </div>
          </div>
        </header>
        <div className="flex-1 space-y-4 p-8 pt-6">
          <div className="flex items-center justify-between space-y-2">
            <h2 className="text-3xl font-bold tracking-tight">Analytics Dashboard</h2>
            <div className="flex items-center space-x-2">
              <Button variant="outline">
                <Filter className="mr-2 h-4 w-4" />
                Filter
              </Button>
              <Button variant="outline">
                <Calendar className="mr-2 h-4 w-4" />
                Mar 2025
              </Button>
              <Button variant="outline">
                <Download className="mr-2 h-4 w-4" />
                Export
              </Button>
              <Button>
                <RefreshCw className="mr-2 h-4 w-4" />
                Refresh
              </Button>
            </div>
          </div>
          
          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">
                  Total Deliveries
                </CardTitle>
                <Truck className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">1,248</div>
                <div className="flex items-center pt-1 text-xs text-green-500">
                  <TrendingUp className="mr-1 h-3.5 w-3.5" />
                  <span>+12.5% from last month</span>
                </div>
              </CardContent>
            </Card>
            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">
                  On-Time Delivery Rate
                </CardTitle>
                <TrendingUp className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">92.5%</div>
                <div className="flex items-center pt-1 text-xs text-green-500">
                  <TrendingUp className="mr-1 h-3.5 w-3.5" />
                  <span>+1.2% from last month</span>
                </div>
              </CardContent>
            </Card>
            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">
                  Average Delivery Time
                </CardTitle>
                <Clock className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">42 min</div>
                <div className="flex items-center pt-1 text-xs text-green-500">
                  <TrendingDown className="mr-1 h-3.5 w-3.5" />
                  <span>-8.3% from last month</span>
                </div>
              </CardContent>
            </Card>
            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">
                  Carbon Footprint
                </CardTitle>
                <Leaf className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">24.8 tons</div>
                <div className="flex items-center pt-1 text-xs text-red-500">
                  <TrendingUp className="mr-1 h-3.5 w-3.5" />
                  <span>+3.2% from last month</span>
                </div>
              </CardContent>
            </Card>
          </div>
          
          <Tabs defaultValue="delivery" className="space-y-4">
            <TabsList className="grid w-full grid-cols-5">
              <TabsTrigger value="delivery">Delivery Performance</TabsTrigger>
              <TabsTrigger value="inventory">Inventory Analytics</TabsTrigger>
              <TabsTrigger value="sustainability">Sustainability</TabsTrigger>
              <TabsTrigger value="security">Security</TabsTrigger>
              <TabsTrigger value="predictions">AI Predictions</TabsTrigger>
            </TabsList>
            
            <TabsContent value="delivery" className="space-y-4">
              <div className="grid gap-4 md:grid-cols-2">
                <Card className="col-span-1">
                  <CardHeader>
                    <CardTitle>Delivery Performance Trend</CardTitle>
                    <CardDescription>
                      On-time delivery rate over the past 6 months
                    </CardDescription>
                  </CardHeader>
                  <CardContent className="pl-2">
                    {loading ? (
                      <div className="flex h-[300px] items-center justify-center">
                        <div className="h-8 w-8 animate-spin rounded-full border-4 border-primary border-t-transparent"></div>
                      </div>
                    ) : (
                      <div className="h-[300px] w-full bg-slate-100 rounded-md flex items-center justify-center">
                        <LineChart className="h-8 w-8 text-slate-400" />
                        <span className="ml-2 text-slate-500">Performance Trend Chart</span>
                      </div>
                    )}
                  </CardContent>
                </Card>
                
                <Card className="col-span-1">
                  <CardHeader>
                    <CardTitle>Delivery Status Breakdown</CardTitle>
                    <CardDescription>
                      Current month delivery status distribution
                    </CardDescription>
                  </CardHeader>
                  <CardContent className="pl-2">
                    {loading ? (
                      <div className="flex h-[300px] items-center justify-center">
                        <div className="h-8 w-8 animate-spin rounded-full border-4 border-primary border-t-transparent"></div>
                      </div>
                    ) : (
                      <div className="h-[300px] w-full bg-slate-100 rounded-md flex items-center justify-center">
                        <PieChart className="h-8 w-8 text-slate-400" />
                        <span className="ml-2 text-slate-500">Status Distribution Chart</span>
                      </div>
                    )}
                  </CardContent>
                </Card>
                
                <Card className="col-span-1">
                  <CardHeader>
                    <CardTitle>Delivery Time by Region</CardTitle>
                    <CardDescription>
                      Average delivery time across Western Sydney regions
                    </CardDescription>
                  </CardHeader>
                  <CardContent className="pl-2">
                    {loading ? (
                      <div className="flex h-[300px] items-center justify-center">
                        <div className="h-8 w-8 animate-spin rounded-full border-4 border-primary border-t-transparent"></div>
                      </div>
                    ) : (
                      <div className="h-[300px] w-full bg-slate-100 rounded-md flex items-center justify-center">
                        <BarChart className="h-8 w-8 text-slate-400" />
                        <span className="ml-2 text-slate-500">Regional Delivery Time Chart</span>
                      </div>
                    )}
                  </CardContent>
                </Card>
                
                <Card className="col-span-1">
                  <CardHeader>
                    <CardTitle>Delivery Volume by Time</CardTitle>
                    <CardDescription>
                      Number of deliveries by time of day
                    </CardDescription>
                  </CardHeader>
                  <CardContent className="pl-2">
                    {loading ? (
                      <div className="flex h-[300px] items-center justify-center">
                        <div className="h-8 w-8 animate-spin rounded-full border-4 border-primary border-t-transparent"></div>
                      </div>
                    ) : (
                      <div className="h-[300px] w-full bg-slate-100 rounded-md flex items-center justify-center">
                        <BarChart className="h-8 w-8 text-slate-400" />
                        <span className="ml-2 text-slate-500">Delivery Volume Chart</span>
                      </div>
                    )}
                  </CardContent>
                </Card>
              </div>
              
              <Card>
                <CardHeader>
                  <CardTitle>Delivery Performance Insights</CardTitle>
                  <CardDescription>
                    AI-generated insights based on delivery data
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="p-4 border rounded-md bg-blue-50">
                      <h3 className="font-medium text-blue-800">Bottleneck Identified</h3>
                      <p className="text-sm text-blue-700 mt-1">
                        The AI has identified a potential bottleneck in the Blacktown to Liverpool route during 4-6 PM. 
                        Consider rescheduling deliveries to avoid peak traffic hours or exploring alternative routes.
                      </p>
                    </div>
                    
                    <div className="p-4 border rounded-md bg-green-50">
                      <h3 className="font-medium text-green-800">Efficiency Opportunity</h3>
                      <p className="text-sm text-green-700 mt-1">
                        Combining deliveries to Parramatta and Westmead could reduce total travel distance by 15% and 
                        save approximately 45 minutes of delivery time per day.
                      </p>
                    </div>
                    
                    <div className="p-4 border rounded-md bg-yellow-50">
                      <h3 className="font-medium text-yellow-800">Weather Impact Alert</h3>
                      <p className="text-sm text-yellow-700 mt-1">
                        Forecasted heavy rain in the Hawkesbury-Nepean area next week may impact delivery times. 
                        Consider preparing alternative routes and notifying customers in advance.
                      </p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
            
            <TabsContent value="inventory" className="space-y-4">
              <div className="grid gap-4 md:grid-cols-2">
                <Card className="col-span-1">
                  <CardHeader>
                    <CardTitle>Inventory Levels</CardTitle>
                    <CardDescription>
                      Current stock levels by category
                    </CardDescription>
                  </CardHeader>
                  <CardContent className="pl-2">
                    {loading ? (
                      <div className="flex h-[300px] items-center justify-center">
                        <div className="h-8 w-8 animate-spin rounded-full border-4 border-primary border-t-transparent"></div>
                      </div>
                    ) : (
                      <div className="h-[300px] w-full bg-slate-100 rounded-md flex items-center justify-center">
                        <BarChart className="h-8 w-8 text-slate-400" />
                        <span className="ml-2 text-slate-500">Inventory Levels Chart</span>
                      </div>
                    )}
                  </CardContent>
                </Card>
                
                <Card className="col-span-1">
                  <CardHeader>
                    <CardTitle>Inventory Turnover</CardTitle>
                    <CardDescription>
                      Turnover rate by product category
                    </CardDescription>
                  </CardHeader>
                  <CardContent className="pl-2">
                    {loading ? (
                      <div className="flex h-[300px] items-center justify-center">
                        <div className="h-8 w-8 animate-spin rounded-full border-4 border-primary border-t-transparent"></div>
                      </div>
                    ) : (
                      <div className="h-[300px] w-full bg-slate-100 rounded-md flex items-center justify-center">
                        <BarChart className="h-8 w-8 text-slate-400" />
                        <span className="ml-2 text-slate-500">Turnover Rate Chart</span>
                      </div>
                    )}
                  </CardContent>
                </Card>
              </div>
              
              <Card>
                <CardHeader>
                  <CardTitle>Inventory Optimization Recommendations</CardTitle>
                  <CardDescription>
                    AI-generated inventory management insights
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="p-4 border rounded-md bg-blue-50">
                      <h3 className="font-medium text-blue-800">Reorder Recommendations</h3>
                      <p className="text-sm text-blue-700 mt-1">
                        Based on current demand patterns, the AI recommends increasing the reorder point for 
                        electronic components by 15% to avoid stockouts during the upcoming holiday season.
                      </p>
                    </div>
                    
                    <div className="p-4 border rounded-md bg-yellow-50">
                      <h3 className="font-medium text-yellow-800">Excess Inventory Alert</h3>
                      <p className="text-sm text-yellow-700 mt-1">
                        Office supplies inventory is 30% above optimal levels. Consider running a promotion 
                        or reducing order quantities for the next 3 months.
                      </p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
            
            <TabsContent value="sustainability" className="space-y-4">
              <div className="grid gap-4 md:grid-cols-2">
                <Card className="col-span-1">
                  <CardHeader>
                    <CardTitle>Carbon Emissions Trend</CardTitle>
                    <CardDescription>
                      Monthly carbon footprint over time
                    </CardDescription>
                  </CardHeader>
                  <CardContent className="pl-2">
                    {loading ? (
                      <div className="flex h-[300px] items-center justify-center">
                        <div className="h-8 w-8 animate-spin rounded-full border-4 border-primary border-t-transparent"></div>
                      </div>
                    ) : (
                      <div className="h-[300px] w-full bg-slate-100 rounded-md flex items-center justify-center">
                        <LineChart className="h-8 w-8 text-slate-400" />
                        <span className="ml-2 text-slate-500">Emissions Trend Chart</span>
                      </div>
                    )}
                  </CardContent>
                </Card>
                
                <Card className="col-span-1">
                  <CardHeader>
                    <CardTitle>Fuel Efficiency by Vehicle Type</CardTitle>
                    <CardDescription>
                      Average km/L by vehicle category
                    </CardDescription>
                  </CardHeader>
                  <CardContent className="pl-2">
                    {loading ? (
                      <div className="flex h-[300px] items-center justify-center">
                        <div className="h-8 w-8 animate-spin rounded-full border-4 border-primary border-t-transparent"></div>
                      </div>
                    ) : (
                      <div className="h-[300px] w-full bg-slate-100 rounded-md flex items-center justify-center">
                        <BarChart className="h-8 w-8 text-slate-400" />
                        <span className="ml-2 text-slate-500">Fuel Efficiency Chart</span>
                      </div>
                    )}
                  </CardContent>
                </Card>
              </div>
              
              <Card>
                <CardHeader>
                  <CardTitle>Sustainability Recommendations</CardTitle>
                  <CardDescription>
                    AI-generated sustainability insights
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="p-4 border rounded-md bg-green-50">
                      <h3 className="font-medium text-green-800">Fleet Optimization</h3>
                      <p className="text-sm text-green-700 mt-1">
                        Replacing 5 diesel trucks with electric vehicles could reduce your carbon footprint by 
                        approximately 18 tons per year and save $15,000 in fuel costs.
                      </p>
                    </div>
                    
                    <div className="p-4 border rounded-md bg-green-50">
                      <h3 className="font-medium text-green-800">Route Optimization</h3>
                      <p className="text-sm text-green-700 mt-1">
                        Optimizing delivery routes to avoid congested areas during peak hours could reduce 
                        fuel consumption by 12% and decrease carbon emissions by 8.5 tons per year.
                      </p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
            
            <TabsContent value="security" className="space-y-4">
              <div className="grid gap-4 md:grid-cols-2">
                <Card className="col-span-1">
                  <CardHeader>
                    <CardTitle>Security Events</CardTitle>
                    <CardDescription>
                      Security incidents by type
                    </CardDescription>
                  </CardHeader>
                  <CardContent className="pl-2">
                    {loading ? (
                      <div className="flex h-[300px] items-center justify-center">
                        <div className="h-8 w-8 animate-spin rounded-full border-4 border-primary border-t-transparent"></div>
                      </div>
                    ) : (
                      <div className="h-[300px] w-full bg-slate-100 rounded-md flex items-center justify-center">
                        <PieChart className="h-8 w-8 text-slate-400" />
                        <span className="ml-2 text-slate-500">Security Events Chart</span>
                      </div>
                    )}
                  </CardContent>
                </Card>
                
                <Card className="col-span-1">
                  <CardHeader>
                    <CardTitle>Security Alerts Trend</CardTitle>
                    <CardDescription>
                      Monthly security alerts over time
                    </CardDescription>
                  </CardHeader>
                  <CardContent className="pl-2">
                    {loading ? (
                      <div className="flex h-[300px] items-center justify-center">
                        <div className="h-8 w-8 animate-spin rounded-full border-4 border-primary border-t-transparent"></div>
                      </div>
                    ) : (
                      <div className="h-[300px] w-full bg-slate-100 rounded-md flex items-center justify-center">
                        <LineChart className="h-8 w-8 text-slate-400" />
                        <span className="ml-2 text-slate-500">Security Alerts Trend Chart</span>
                      </div>
                    )}
                  </CardContent>
                </Card>
              </div>
              
              <Card>
                <CardHeader>
                  <CardTitle>Security Insights</CardTitle>
                  <CardDescription>
                    AI-generated security recommendations
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="p-4 border rounded-md bg-red-50">
                      <h3 className="font-medium text-red-800">Suspicious Login Pattern</h3>
                      <p className="text-sm text-red-700 mt-1">
                        The AI has detected multiple failed login attempts from unusual locations. 
                        Consider implementing multi-factor authentication for all admin accounts.
                      </p>
                    </div>
                    
                    <div className="p-4 border rounded-md bg-yellow-50">
                      <h3 className="font-medium text-yellow-800">Data Access Anomaly</h3>
                      <p className="text-sm text-yellow-700 mt-1">
                        Unusual pattern of customer data access detected from user ID 1042. 
                        Review access logs and consider implementing more granular access controls.
                      </p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
            
            <TabsContent value="predictions" className="space-y-4">
              <div className="grid gap-4 md:grid-cols-2">
                <Card className="col-span-1">
                  <CardHeader>
                    <CardTitle>Demand Forecast</CardTitle>
                    <CardDescription>
                      Predicted delivery volume for next 30 days
                    </CardDescription>
                  </CardHeader>
                  <CardContent className="pl-2">
                    {loading ? (
                      <div className="flex h-[300px] items-center justify-center">
                        <div className="h-8 w-8 animate-spin rounded-full border-4 border-primary border-t-transparent"></div>
                      </div>
                    ) : (
                      <div className="h-[300px] w-full bg-slate-100 rounded-md flex items-center justify-center">
                        <LineChart className="h-8 w-8 text-slate-400" />
                        <span className="ml-2 text-slate-500">Demand Forecast Chart</span>
                      </div>
                    )}
                  </CardContent>
                </Card>
                
                <Card className="col-span-1">
                  <CardHeader>
                    <CardTitle>Flood Risk Prediction</CardTitle>
                    <CardDescription>
                      Predicted flood risk for Western Sydney regions
                    </CardDescription>
                  </CardHeader>
                  <CardContent className="pl-2">
                    {loading ? (
                      <div className="flex h-[300px] items-center justify-center">
                        <div className="h-8 w-8 animate-spin rounded-full border-4 border-primary border-t-transparent"></div>
                      </div>
                    ) : (
                      <div className="h-[300px] w-full bg-slate-100 rounded-md flex items-center justify-center">
                        <BarChart className="h-8 w-8 text-slate-400" />
                        <span className="ml-2 text-slate-500">Flood Risk Chart</span>
                      </div>
                    )}
                  </CardContent>
                </Card>
              </div>
              
              <Card>
                <CardHeader>
                  <CardTitle>AI Predictions and Insights</CardTitle>
                  <CardDescription>
                    Forward-looking insights from AI models
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="p-4 border rounded-md bg-purple-50">
                      <h3 className="font-medium text-purple-800">Demand Spike Predicted</h3>
                      <p className="text-sm text-purple-700 mt-1">
                        The AI predicts a 30% increase in delivery volume for the Parramatta area in the next 
                        2 weeks due to upcoming local events. Consider allocating additional resources.
                      </p>
                    </div>
                    
                    <div className="p-4 border rounded-md bg-orange-50">
                      <h3 className="font-medium text-orange-800">Weather Impact Warning</h3>
                      <p className="text-sm text-orange-700 mt-1">
                        The AI predicts a 65% chance of flooding in the Hawkesbury-Nepean Valley within the next 
                        10 days based on current rainfall patterns and river levels. Prepare contingency plans for 
                        affected routes.
                      </p>
                    </div>
                    
                    <div className="p-4 border rounded-md bg-blue-50">
                      <h3 className="font-medium text-blue-800">Resource Optimization</h3>
                      <p className="text-sm text-blue-700 mt-1">
                        Based on historical patterns, the AI predicts that reallocating 3 vehicles from the 
                        Liverpool area to Blacktown during weekday mornings could improve overall delivery 
                        efficiency by 18%.
                      </p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </div>
      </div>
    </main>
  )
}

// Clock component for the analytics page
function Clock({ className }) {
  return (
    <svg
      xmlns="http://www.w3.org/2000/svg"
      width="24"
      height="24"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
      className={className}
    >
      <circle cx="12" cy="12" r="10" />
      <polyline points="12 6 12 12 16 14" />
    </svg>
  )
}
