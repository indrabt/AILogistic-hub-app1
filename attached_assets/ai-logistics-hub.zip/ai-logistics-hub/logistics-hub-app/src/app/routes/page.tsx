'use client'

import { useState, useEffect } from 'react'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { 
  MapPin, 
  Truck, 
  Clock, 
  AlertTriangle, 
  CheckCircle,
  Calendar,
  ArrowRight,
  RotateCcw,
  Search
} from 'lucide-react'
import MobileNavigation from '@/components/mobile-navigation'

export default function RoutesPage() {
  const [loading, setLoading] = useState(true)
  const [isMobile, setIsMobile] = useState(false)
  
  useEffect(() => {
    // Simulate data loading
    const timer = setTimeout(() => {
      setLoading(false)
    }, 1000)
    
    // Check if we're on a mobile device
    const checkMobile = () => {
      setIsMobile(window.innerWidth < 768)
    }
    
    // Initial check
    checkMobile()
    
    // Add event listener for window resize
    window.addEventListener('resize', checkMobile)
    
    return () => {
      clearTimeout(timer)
      window.removeEventListener('resize', checkMobile)
    }
  }, [])
  
  return (
    <main className="flex min-h-screen flex-col">
      <div className="flex flex-col">
        <header className="border-b">
          <div className="flex h-16 items-center px-4 md:px-6">
            <div className="flex items-center gap-2">
              <Truck className="h-6 w-6" />
              <h1 className="text-xl font-bold">AI-Powered Smart Logistics Hub</h1>
            </div>
            
            {/* Use our mobile navigation component */}
            <MobileNavigation />
            
            <div className={`ml-auto flex items-center gap-4 ${isMobile ? 'hidden' : ''}`}>
              <Button variant="outline" size="sm">
                Western Sydney Logistics
              </Button>
              <Button size="sm">Sign Out</Button>
            </div>
          </div>
        </header>
        
        <div className="flex-1 space-y-4 p-4 md:p-8 pt-6">
          <div className="flex flex-col md:flex-row md:items-center justify-between space-y-2 md:space-y-0">
            <h2 className="text-2xl md:text-3xl font-bold tracking-tight">Route Management</h2>
            <div className="flex items-center space-x-2">
              <Button className={isMobile ? "w-full" : ""}>
                <Calendar className="mr-2 h-4 w-4" />
                Today
              </Button>
            </div>
          </div>
          
          <div className="grid gap-4 grid-cols-1 sm:grid-cols-2 lg:grid-cols-4">
            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">
                  Active Routes
                </CardTitle>
                <Truck className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">24</div>
                <p className="text-xs text-muted-foreground">
                  +2 from yesterday
                </p>
              </CardContent>
            </Card>
            
            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">
                  On-Time Rate
                </CardTitle>
                <Clock className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">92.5%</div>
                <p className="text-xs text-muted-foreground">
                  +1.2% from last week
                </p>
              </CardContent>
            </Card>
            
            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">
                  Delayed Routes
                </CardTitle>
                <AlertTriangle className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">3</div>
                <p className="text-xs text-muted-foreground">
                  -2 from yesterday
                </p>
              </CardContent>
            </Card>
            
            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">
                  Completed Today
                </CardTitle>
                <CheckCircle className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">18</div>
                <p className="text-xs text-muted-foreground">
                  65% of daily target
                </p>
              </CardContent>
            </Card>
          </div>
          
          <div className="flex flex-col md:flex-row gap-4">
            <div className="w-full md:w-2/3">
              <Card className="h-full">
                <CardHeader>
                  <CardTitle>Active Routes</CardTitle>
                  <CardDescription>
                    Current delivery routes in progress
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  {loading ? (
                    <div className="flex h-[400px] items-center justify-center">
                      <div className="h-8 w-8 animate-spin rounded-full border-4 border-primary border-t-transparent"></div>
                    </div>
                  ) : (
                    <div className="space-y-6">
                      <div className="flex flex-col md:flex-row md:items-center justify-between p-4 border rounded-lg bg-green-50 text-green-800">
                        <div className="flex items-start md:items-center mb-2 md:mb-0">
                          <MapPin className="mr-2 h-5 w-5 flex-shrink-0 text-green-500" />
                          <div>
                            <p className="font-medium">Parramatta to Penrith</p>
                            <p className="text-sm">In progress • 35 min remaining • Driver: John Smith</p>
                          </div>
                        </div>
                        <div className="flex flex-col sm:flex-row gap-2">
                          <Button variant="outline" size="sm" className={isMobile ? "w-full" : ""}>
                            <Search className="mr-2 h-4 w-4" />
                            Track
                          </Button>
                          <Button size="sm" className={isMobile ? "w-full" : ""}>
                            Details
                            <ArrowRight className="ml-2 h-4 w-4" />
                          </Button>
                        </div>
                      </div>
                      
                      <div className="flex flex-col md:flex-row md:items-center justify-between p-4 border rounded-lg bg-green-50 text-green-800">
                        <div className="flex items-start md:items-center mb-2 md:mb-0">
                          <MapPin className="mr-2 h-5 w-5 flex-shrink-0 text-green-500" />
                          <div>
                            <p className="font-medium">Blacktown to Liverpool</p>
                            <p className="text-sm">In progress • 15 min remaining • Driver: Sarah Johnson</p>
                          </div>
                        </div>
                        <div className="flex flex-col sm:flex-row gap-2">
                          <Button variant="outline" size="sm" className={isMobile ? "w-full" : ""}>
                            <Search className="mr-2 h-4 w-4" />
                            Track
                          </Button>
                          <Button size="sm" className={isMobile ? "w-full" : ""}>
                            Details
                            <ArrowRight className="ml-2 h-4 w-4" />
                          </Button>
                        </div>
                      </div>
                      
                      <div className="flex flex-col md:flex-row md:items-center justify-between p-4 border rounded-lg bg-yellow-50 text-yellow-800">
                        <div className="flex items-start md:items-center mb-2 md:mb-0">
                          <MapPin className="mr-2 h-5 w-5 flex-shrink-0 text-yellow-500" />
                          <div>
                            <p className="font-medium">Sydney CBD to Parramatta</p>
                            <p className="text-sm">Delayed • 50 min remaining • Driver: Michael Chen</p>
                          </div>
                        </div>
                        <div className="flex flex-col sm:flex-row gap-2">
                          <Button variant="outline" size="sm" className={isMobile ? "w-full" : ""}>
                            <Search className="mr-2 h-4 w-4" />
                            Track
                          </Button>
                          <Button size="sm" className={isMobile ? "w-full" : ""}>
                            Details
                            <ArrowRight className="ml-2 h-4 w-4" />
                          </Button>
                        </div>
                      </div>
                      
                      <div className="flex flex-col md:flex-row md:items-center justify-between p-4 border rounded-lg bg-red-50 text-red-800">
                        <div className="flex items-start md:items-center mb-2 md:mb-0">
                          <MapPin className="mr-2 h-5 w-5 flex-shrink-0 text-red-500" />
                          <div>
                            <p className="font-medium">Campbelltown to Bankstown</p>
                            <p className="text-sm">Delayed • 75 min remaining • Driver: Emma Wilson</p>
                          </div>
                        </div>
                        <div className="flex flex-col sm:flex-row gap-2">
                          <Button variant="outline" size="sm" className={isMobile ? "w-full" : ""}>
                            <Search className="mr-2 h-4 w-4" />
                            Track
                          </Button>
                          <Button size="sm" className={isMobile ? "w-full" : ""}>
                            Details
                            <ArrowRight className="ml-2 h-4 w-4" />
                          </Button>
                        </div>
                      </div>
                      
                      <div className="flex flex-col md:flex-row md:items-center justify-between p-4 border rounded-lg bg-green-50 text-green-800">
                        <div className="flex items-start md:items-center mb-2 md:mb-0">
                          <MapPin className="mr-2 h-5 w-5 flex-shrink-0 text-green-500" />
                          <div>
                            <p className="font-medium">Liverpool to Fairfield</p>
                            <p className="text-sm">In progress • 20 min remaining • Driver: David Thompson</p>
                          </div>
                        </div>
                        <div className="flex flex-col sm:flex-row gap-2">
                          <Button variant="outline" size="sm" className={isMobile ? "w-full" : ""}>
                            <Search className="mr-2 h-4 w-4" />
                            Track
                          </Button>
                          <Button size="sm" className={isMobile ? "w-full" : ""}>
                            Details
                            <ArrowRight className="ml-2 h-4 w-4" />
                          </Button>
                        </div>
                      </div>
                    </div>
                  )}
                </CardContent>
              </Card>
            </div>
            
            <div className="w-full md:w-1/3">
              <Card className="h-full">
                <CardHeader>
                  <CardTitle>Route Optimization</CardTitle>
                  <CardDescription>
                    AI-powered route suggestions
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  {loading ? (
                    <div className="flex h-[400px] items-center justify-center">
                      <div className="h-8 w-8 animate-spin rounded-full border-4 border-primary border-t-transparent"></div>
                    </div>
                  ) : (
                    <div className="space-y-4">
                      <div className="p-4 border rounded-lg bg-blue-50 text-blue-800">
                        <h3 className="font-medium mb-2">Optimization Insights</h3>
                        <ul className="space-y-2 text-sm">
                          <li className="flex items-start">
                            <CheckCircle className="mr-2 h-4 w-4 mt-0.5 text-blue-500" />
                            <span>3 routes can be optimized to save 15% fuel</span>
                          </li>
                          <li className="flex items-start">
                            <CheckCircle className="mr-2 h-4 w-4 mt-0.5 text-blue-500" />
                            <span>Batch 5 deliveries in Penrith area to save 45 minutes</span>
                          </li>
                          <li className="flex items-start">
                            <CheckCircle className="mr-2 h-4 w-4 mt-0.5 text-blue-500" />
                            <span>Reroute Sydney CBD deliveries due to event traffic</span>
                          </li>
                        </ul>
                        <Button className="w-full mt-4">
                          <RotateCcw className="mr-2 h-4 w-4" />
                          Apply Optimizations
                        </Button>
                      </div>
                      
                      <div className="p-4 border rounded-lg">
                        <h3 className="font-medium mb-2">Weather Alerts</h3>
                        <div className="space-y-2 text-sm">
                          <div className="flex items-start">
                            <AlertTriangle className="mr-2 h-4 w-4 mt-0.5 text-yellow-500" />
                            <div>
                              <p className="font-medium">Medium Flood Risk - Penrith Area</p>
                              <p className="text-xs text-muted-foreground">Heavy rainfall expected between 2-5pm</p>
                            </div>
                          </div>
                          <div className="flex items-start">
                            <AlertTriangle className="mr-2 h-4 w-4 mt-0.5 text-blue-500" />
                            <div>
                              <p className="font-medium">Traffic Congestion - M4 Motorway</p>
                              <p className="text-xs text-muted-foreground">Delays of 15-20 minutes expected</p>
                            </div>
                          </div>
                        </div>
                        <Button variant="outline" className="w-full mt-4">
                          View All Alerts
                        </Button>
                      </div>
                    </div>
                  )}
                </CardContent>
              </Card>
            </div>
          </div>
          
          {/* Mobile-specific quick actions */}
          {isMobile && (
            <div className="fixed bottom-0 left-0 right-0 bg-background border-t border-border p-4 flex justify-around">
              <Button variant="ghost" className="flex flex-col items-center text-xs">
                <Truck className="h-6 w-6 mb-1" />
                Routes
              </Button>
              <Button variant="ghost" className="flex flex-col items-center te<response clipped><NOTE>To save on context only part of this file has been shown to you. You should retry this tool after you have searched inside the file with `grep -n` in order to find the line numbers of what you are looking for.</NOTE>