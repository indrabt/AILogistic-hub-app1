'use client'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { 
  BarChart, 
  LineChart, 
  PieChart, 
  MapPin, 
  Truck, 
  Package, 
  AlertTriangle, 
  TrendingUp, 
  Calendar, 
  Users, 
  Shield, 
  Leaf 
} from 'lucide-react'
import { useEffect, useState } from 'react'

export default function Dashboard() {
  const [loading, setLoading] = useState(true)
  const [isMobile, setIsMobile] = useState(false)
  
  useEffect(() => {
    // Simulate data loading
    const timer = setTimeout(() => {
      setLoading(false)
    }, 1000)
    
    // Check if we're on a mobile device
    const checkMobile = () => {
      setIsMobile(window.innerWidth < 768)
    }
    
    // Initial check
    checkMobile()
    
    // Add event listener for window resize
    window.addEventListener('resize', checkMobile)
    
    return () => {
      clearTimeout(timer)
      window.removeEventListener('resize', checkMobile)
    }
  }, [])
  
  return (
    <main className="flex min-h-screen flex-col">
      <div className="flex flex-col">
        <header className="border-b">
          <div className="flex h-16 items-center px-4 md:px-6">
            <div className="flex items-center gap-2">
              <Truck className="h-6 w-6" />
              <h1 className="text-xl font-bold">AI-Powered Smart Logistics Hub</h1>
            </div>
            {/* Desktop navigation - hidden on mobile */}
            <nav className="ml-auto hidden md:flex gap-4 sm:gap-6">
              <Button variant="ghost" asChild>
                <a href="/">Dashboard</a>
              </Button>
              <Button variant="ghost" asChild>
                <a href="/routes">Routes</a>
              </Button>
              <Button variant="ghost" asChild>
                <a href="/inventory">Inventory</a>
              </Button>
              <Button variant="ghost" asChild>
                <a href="/analytics">Analytics</a>
              </Button>
              <Button variant="ghost" asChild>
                <a href="/settings">Settings</a>
              </Button>
            </nav>
            {/* Mobile navigation button */}
            {isMobile && (
              <div className="ml-auto">
                <Button variant="ghost" size="icon" className="md:hidden">
                  <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <path d="M3 12H21" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
                    <path d="M3 6H21" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
                    <path d="M3 18H21" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
                  </svg>
                </Button>
              </div>
            )}
            {/* User info - hidden on mobile */}
            <div className="ml-auto hidden md:flex items-center gap-4">
              <Button variant="outline" size="sm" asChild>
                <a href="/profile">Western Sydney Logistics</a>
              </Button>
              <Button size="sm" asChild>
                <a href="/logout">Sign Out</a>
              </Button>
            </div>
          </div>
        </header>
        <div className="flex-1 space-y-4 p-4 md:p-8 pt-6">
          <div className="flex flex-col md:flex-row md:items-center justify-between space-y-2 md:space-y-0">
            <h2 className="text-2xl md:text-3xl font-bold tracking-tight">Dashboard</h2>
            <div className="flex items-center space-x-2">
              <Button className={isMobile ? "w-full" : ""}>
                <Calendar className="mr-2 h-4 w-4" />
                Today
              </Button>
            </div>
          </div>
          <Tabs defaultValue="overview" className="space-y-4">
            <TabsList className="w-full overflow-x-auto">
              <TabsTrigger value="overview">Overview</TabsTrigger>
              <TabsTrigger value="analytics">Analytics</TabsTrigger>
              <TabsTrigger value="reports">Reports</TabsTrigger>
              <TabsTrigger value="notifications">Notifications</TabsTrigger>
            </TabsList>
            <TabsContent value="overview" className="space-y-4">
              <div className="grid gap-4 grid-cols-1 sm:grid-cols-2 lg:grid-cols-4">
                <Card>
                  <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                    <CardTitle className="text-sm font-medium">
                      Active Deliveries
                    </CardTitle>
                    <Truck className="h-4 w-4 text-muted-foreground" />
                  </CardHeader>
                  <CardContent>
                    <div className="text-2xl font-bold">24</div>
                    <p className="text-xs text-muted-foreground">
                      +2 from yesterday
                    </p>
                  </CardContent>
                </Card>
                <Card>
                  <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                    <CardTitle className="text-sm font-medium">
                      On-Time Delivery Rate
                    </CardTitle>
                    <TrendingUp className="h-4 w-4 text-muted-foreground" />
                  </CardHeader>
                  <CardContent>
                    <div className="text-2xl font-bold">92.5%</div>
                    <p className="text-xs text-muted-foreground">
                      +1.2% from last week
                    </p>
                  </CardContent>
                </Card>
                <Card>
                  <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                    <CardTitle className="text-sm font-medium">
                      Low Stock Items
                    </CardTitle>
                    <Package className="h-4 w-4 text-muted-foreground" />
                  </CardHeader>
                  <CardContent>
                    <div className="text-2xl font-bold">7</div>
                    <p className="text-xs text-muted-foreground">
                      Requires attention
                    </p>
                  </CardContent>
                </Card>
                <Card>
                  <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                    <CardTitle className="text-sm font-medium">
                      Risk Alerts
                    </CardTitle>
                    <AlertTriangle className="h-4 w-4 text-muted-foreground" />
                  </CardHeader>
                  <CardContent>
                    <div className="text-2xl font-bold">3</div>
                    <p className="text-xs text-muted-foreground">
                      2 high, 1 medium
                    </p>
                  </CardContent>
                </Card>
              </div>
              <div className="grid gap-4 grid-cols-1 md:grid-cols-2 lg:grid-cols-7">
                <Card className="col-span-1 md:col-span-4">
                  <CardHeader>
                    <CardTitle>Delivery Performance</CardTitle>
                  </CardHeader>
                  <CardContent className="pl-2">
                    {loading ? (
                      <div className="flex h-[200px] items-center justify-center">
                        <div className="h-8 w-8 animate-spin rounded-full border-4 border-primary border-t-transparent"></div>
                      </div>
                    ) : (
                      <div className="h-[200px] w-full bg-slate-100 rounded-md flex items-center justify-center">
                        <LineChart className="h-8 w-8 text-slate-400" />
                        <span className="ml-2 text-slate-500">Performance Chart</span>
                      </div>
                    )}
                  </CardContent>
                </Card>
                <Card className="col-span-1 md:col-span-3">
                  <CardHeader>
                    <CardTitle>Active Routes</CardTitle>
                    <CardDescription>
                      Current delivery routes in progress
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    {loading ? (
                      <div className="flex h-[200px] items-center justify-center">
                        <div className="h-8 w-8 animate-spin rounded-full border-4 border-primary border-t-transparent"></div>
                      </div>
                    ) : (
                      <div className="space-y-4">
                        <div className="flex items-center">
                          <MapPin className="mr-2 h-4 w-4 text-blue-500" />
                          <div className="ml-2 space-y-1">
                            <p className="text-sm font-medium leading-none">
                              Parramatta to Penrith
                            </p>
                            <p className="text-sm text-muted-foreground">
                              In progress • 35 min remaining
                            </p>
                          </div>
                          <div className="ml-auto font-medium">On time</div>
                        </div>
                        <div className="flex items-center">
                          <MapPin className="mr-2 h-4 w-4 text-green-500" />
                          <div className="ml-2 space-y-1">
                            <p className="text-sm font-medium leading-none">
                              Blacktown to Liverpool
                            </p>
                            <p className="text-sm text-muted-foreground">
                              In progress • 15 min remaining
                            </p>
                          </div>
                          <div className="ml-auto font-medium">On time</div>
                        </div>
                        <div className="flex items-center">
                          <MapPin className="mr-2 h-4 w-4 text-yellow-500" />
                          <div className="ml-2 space-y-1">
                            <p className="text-sm font-medium leading-none">
                              Sydney CBD to Parramatta
                            </p>
                            <p className="text-sm text-muted-foreground">
                              In progress • 50 min remaining
                            </p>
                          </div>
                          <div className="ml-auto font-medium text-yellow-500">Delayed</div>
                        </div>
                      </div>
                    )}
                  </CardContent>
                </Card>
              </div>
              <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
                <Card>
                  <CardHeader className="flex flex-row items-center justify-between space-y-0">
                    <CardTitle>Sustainability Metrics</CardTitle>
                    <Leaf className="h-4 w-4 text-green-500" />
                  </CardHeader>
                  <CardContent>
                    {loading ? (
                      <div className="flex h-[200px] items-center justify-center">
                        <div className="h-8 w-8 animate-spin rounded-full border-4 border-primary border-t-transparent"></div>
                      </div>
                    ) : (
                      <div className="space-y-4">
                        <div className="flex items-center justify-between">
                          <div className="space-y-1">
                            <p className="text-sm font-medium leading-none">
                              Carbon Emissions
                            </p>
                            <p className="text-sm text-muted-foreground">
                              This month
                            </p>
                          </div>
                          <div className="font-medium">2.4 tons</div>
                        </div>
                        <div className="flex items-center justify-between">
                          <div className="space-y-1">
                            <p className="text-sm font-medium leading-none">
                              Fuel Efficiency
                            </p>
                            <p className="text-sm text-muted-foreground">
                              Fleet average
                            </p>
                          </div>
                          <div className="font-medium">9.2 km/L</div>
                        </div>
                        <div className="flex items-center justify-between">
                          <div className="space-y-1">
                            <p className="text-sm font-medium leading-none">
                              Efficiency Score
                            </p>
                            <p className="text-sm text-muted-foreground">
                              Overall rating
                            </p>
                          </div>
                          <div className="font-medium text-green-500">78/100</div>
                        </div>
                      </div>
                    )}
                  </CardContent>
                </Card>
                <Card>
                  <CardHeader className="flex flex-row items-center justify-between space-y-0">
                    <CardTitle>Security Status</CardTitle>
                    <Shield className="h-4 w-4 text-blue-500" />
                  </CardHeader>
                  <CardContent>
                    {loading ? (
                      <div className="flex h-[200px] items-center justify-center">
                        <div className="h-8 w-8 animate-spin rounded-full border-4 border-primary border-t-transparent"></div>
                      </div>
                    ) : (
                      <div className="space-y-4">
                        <div className="flex items-center justify-between">
                          <div className="space-y-1">
                            <p className="text-sm font-medium leading-none">
                              Security Events
                            </p>
                            <p className="text-sm text-muted-foreground">
                              Last 24 hours
                            </p>
                          </div>
                          <div className="font-medium">12</div>
                        </div>
                        <div className="flex items-center justify-between">
                          <div className="space-y-1">
                            <p className="text-sm font-medium leading-none">
                              Suspicious Logins
                            </p>
                            <p className="text-sm text-muted-foreground">
                              Last 7 days
                            </p>
                          </div>
                          <div className="font-medium text-yellow-500">2</div>
                        </div>
                        <div className="flex items-center justify-between">
                          <div className="space-y-1">
                            <p className="text-sm font-medium leading-none">
                              System Status
                            </p>
                            <p className="text-sm text-muted-foreground">
                              Current state
                            </p>
                          </div>
                          <div className="font-medium text-green-500">Secure</div>
                        </div>
                      </div>
                    )}
                  </CardContent>
                </Card>
                <Card>
                  <CardHeader className="flex flex-row items-center justify-between space-y-0">
                    <CardTitle>Disaster Risk</CardTitle>
                    <AlertTriangle className="h-4 w-4 text-red-500" />
                  </CardHeader>
                  <CardContent>
                    {loading ? (
                      <div className="flex h-[200px] items-center justify-center">
                        <div className="h-8 w-8 animate-spin rounded-full border-4 border-primary border-t-transparent"></div>
                      </div>
                    ) : (
                      <div className="space-y-4">
                        <div className="flex items-center justify-between">
                          <div className="space-y-1">
                            <p className="text-sm font-medium leading-none">
                              Flood Risk
                            </p>
                            <p className="text-sm text-muted-foreground">
                              Hawkesbury-Nepean
                            </p>
                          </div>
                          <div className="font-medium text-yellow-500">Medium</div>
                        </div>
                        <div className="flex items-center justify-between">
                          <div className="space-y-1">
                            <p className="text-sm font-medium leading-none">
                              Weather Alerts
                            </p>
                            <p className="text-sm text-muted-foreground">
                              Western Sydney
                            </p>
                          </div>
                          <div className="font-medium">1 Active</div>
                        </div>
                        <div className="flex items-center justify-between">
                          <div className="space-y-1">
                            <p className="text-sm font-medium leading-none">
                              Affected Routes
                            </p>
                            <p className="text-sm text-muted-foreground">
                              Next 24 hours
                            </p>
                          </div>
                          <div className="font-medium text-red-500">3</div>
                        </div>
                      </div>
                    )}
                  </CardContent>
                </Card>
              </div>
            </TabsContent>
            <TabsContent value="analytics" className="space-y-4">
              <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-2">
                <Card className="col-span-1">
                  <CardHeader>
                    <CardTitle>Delivery Performance</CardTitle>
                    <CardDescription>
                      On-time delivery rate over time
                    </CardDescription>
                  </CardHeader>
                  <CardContent className="pl-2">
                    <div className="h-[300px] w-full bg-slate-100 rounded-md flex items-center justify-center">
                      <LineChart className="h-8 w-8 text-slate-400" />
                      <span className="ml-2 text-slate-500">Performance Chart</span>
                    </div>
                  </CardContent>
                </Card>
                <Card className="col-span-1">
                  <CardHeader>
                    <CardTitle>Delivery Status</CardTitle>
                    <CardDescription>
                      Current month delivery breakdown
                    </CardDescription>
                  </CardHeader>
                  <CardContent className="pl-2">
                    <div className="h-[300px] w-full bg-slate-100 rounded-md flex items-center justify-center">
                      <PieChart className="h-8 w-8 text-slate-400" />
                      <span className="ml-2 text-slate-500">Status Chart</span>
                    </div>
                  </CardContent>
                </Card>
                <Card className="col-span-1">
                  <CardHeader>
                    <CardTitle>Fuel Efficiency</CardTitle>
                    <CardDescription>
                      Average km/L by vehicle type
                    </CardDescription>
                  </CardHeader>
                  <CardContent className="pl-2">
                    <div className="h-[300px] w-full bg-slate-100 rounded-md flex items-center justify-center">
                      <BarChart className="h-8 w-8 text-slate-400" />
                      <span className="ml-2 text-slate-500">Efficiency Chart</span>
                    </div>
                  </CardContent>
                </Card>
                <Card className="col-span-1">
                  <CardHeader>
                    <CardTitle>Carbon Emissions</CardTitle>
                    <CardDescription>
                      Monthly carbon footprint
                    </CardDescription>
                  </CardHeader>
                  <CardContent className="pl-2">
                    <div className="h-[300px] w-full bg-slate-100 rounded-md flex items-center justify-center">
                      <LineChart className="h-8 w-8 text-slate-400" />
                      <span className="ml-2 text-slate-500">Emissions Chart</span>
                    </div>
                  </CardContent>
                </Card>
              </div>
            </TabsContent>
            <TabsContent value="reports" className="space-y-4">
              <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
                <Card>
                  <CardHeader>
                    <CardTitle>Performance Report</CardTitle>
                    <CardDescription>
                      Monthly delivery performance
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="flex justify-between items-center">
                      <div>Last generated: Today, 10:30 AM</div>
                      <Button size="sm">Download</Button>
                    </div>
                  </CardContent>
                </Card>
                <Card>
                  <CardHeader>
                    <CardTitle>Sustainability Report</CardTitle>
                    <CardDescription>
                      Environmental impact analysis
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="flex justify-between items-center">
                      <div>Last generated: Yesterday, 2:15 PM</div>
                      <Button size="sm">Download</Button>
                    </div>
                  </CardContent>
                </Card>
                <Card>
                  <CardHeader>
                    <CardTitle>Security Report</CardTitle>
                    <CardDescription>
                      System security analysis
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="flex justify-between items-center">
                      <div>Last generated: 3 days ago</div>
                      <Button size="sm">Download</Button>
                    </div>
                  </CardContent>
                </Card>
              </div>
            </TabsContent>
            <TabsContent value="notifications" className="space-y-4">
              <Card>
                <CardHeader>
                  <CardTitle>Recent Notifications</CardTitle>
                  <CardDescription>
                    System alerts and updates
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="flex items-start">
                      <AlertTriangle className="mr-2 h-5 w-5 text-red-500 mt-0.5" />
                      <div className="space-y-1">
                        <p className="text-sm font-medium leading-none">
                          High flood risk detected for Windsor route
                        </p>
                        <p className="text-sm text-muted-foreground">
                          Today, 9:42 AM
                        </p>
                      </div>
                    </div>
                    <div className="flex items-start">
                      <Package className="mr-2 h-5 w-5 text-yellow-500 mt-0.5" />
                      <div className="space-y-1">
                        <p className="text-sm font-medium leading-none">
                          Inventory low for item #A1245 - Reorder recommended
                        </p>
                        <p className="text-sm text-muted-foreground">
                          Today, 8:15 AM
                        </p>
                      </div>
                    </div>
                    <div className="flex items-start">
                      <Shield className="mr-2 h-5 w-5 text-yellow-500 mt-0.5" />
                      <div className="space-y-1">
                        <p className="text-sm font-medium leading-none">
                          Suspicious login attempt detected
                        </p>
                        <p className="text-sm text-muted-foreground">
                          Yesterday, 11:30 PM
                        </p>
                      </div>
                    </div>
                    <div className="flex items-start">
                      <Truck className="mr-2 h-5 w-5 text-green-500 mt-0.5" />
                      <div className="space-y-1">
                        <p className="text-sm font-medium leading-none">
                          All deliveries completed successfully
                        </p>
                        <p className="text-sm text-muted-foreground">
                          Yesterday, 5:30 PM
                        </p>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </div>
      </div>
    </main>
  )
}
