'use server'
import { getCloudflareContext } from '@opennextjs/cloudflare'
import { LogisticsDB } from '@/lib/db'
import { headers } from 'next/headers'

// Edge AI Processing for the AI-Powered Smart Logistics Hub
// This module simulates edge AI capabilities that would typically run on edge devices

// Process real-time vehicle telemetry data
export async function processVehicleTelemetry(
  vehicleId: number,
  telemetryData: {
    timestamp: string,
    location: { lat: number, lon: number },
    speed: number,
    fuelLevel: number,
    engineTemperature: number,
    batteryLevel?: number,
    cargoTemperature?: number,
    cargoHumidity?: number,
    accelerometerData?: { x: number, y: number, z: number }
  }
) {
  try {
    // In a real implementation, this would process data from IoT devices on vehicles
    // For this simulation, we'll analyze the provided telemetry data
    
    // Get vehicle details
    const cf = await getCloudflareContext()
    const { results } = await cf.env.DB.prepare(
      'SELECT * FROM vehicles WHERE id = ?'
    ).bind(vehicleId).all()
    
    const vehicle = results[0]
    
    if (!vehicle) {
      return { success: false, message: 'Vehicle not found' }
    }
    
    // Check for anomalies in telemetry data
    const anomalies = []
    
    // Engine temperature check
    if (telemetryData.engineTemperature > 110) { // Celsius
      anomalies.push({
        type: 'engine_temperature',
        value: telemetryData.engineTemperature,
        threshold: 110,
        severity: telemetryData.engineTemperature > 130 ? 'high' : 'medium',
        message: `Engine temperature above normal (${telemetryData.engineTemperature}°C)`
      })
    }
    
    // Fuel level check
    if (telemetryData.fuelLevel < 15) { // Percentage
      anomalies.push({
        type: 'fuel_level',
        value: telemetryData.fuelLevel,
        threshold: 15,
        severity: telemetryData.fuelLevel < 5 ? 'high' : 'medium',
        message: `Fuel level low (${telemetryData.fuelLevel}%)`
      })
    }
    
    // Speed check
    if (telemetryData.speed > 110) { // km/h
      anomalies.push({
        type: 'speed',
        value: telemetryData.speed,
        threshold: 110,
        severity: telemetryData.speed > 130 ? 'high' : 'medium',
        message: `Vehicle speed above limit (${telemetryData.speed} km/h)`
      })
    }
    
    // Battery level check (if available)
    if (telemetryData.batteryLevel !== undefined && telemetryData.batteryLevel < 20) {
      anomalies.push({
        type: 'battery_level',
        value: telemetryData.batteryLevel,
        threshold: 20,
        severity: telemetryData.batteryLevel < 10 ? 'high' : 'medium',
        message: `Battery level low (${telemetryData.batteryLevel}%)`
      })
    }
    
    // Cargo temperature check (if available)
    if (telemetryData.cargoTemperature !== undefined) {
      // Different thresholds for different cargo types would be implemented here
      if (telemetryData.cargoTemperature > 30 || telemetryData.cargoTemperature < 0) {
        anomalies.push({
          type: 'cargo_temperature',
          value: telemetryData.cargoTemperature,
          thresholdHigh: 30,
          thresholdLow: 0,
          severity: 'medium',
          message: `Cargo temperature outside normal range (${telemetryData.cargoTemperature}°C)`
        })
      }
    }
    
    // Accelerometer data check for harsh driving (if available)
    if (telemetryData.accelerometerData) {
      const { x, y, z } = telemetryData.accelerometerData
      const magnitude = Math.sqrt(x*x + y*y + z*z)
      
      if (magnitude > 2.5) { // g-force
        anomalies.push({
          type: 'harsh_driving',
          value: magnitude,
          threshold: 2.5,
          severity: magnitude > 3.5 ? 'high' : 'medium',
          message: `Harsh driving detected (${magnitude.toFixed(2)} g)`
        })
      }
    }
    
    // Store telemetry data (in a real implementation, this would be stored in a time-series database)
    // For this simulation, we'll log it as a security event
    if (anomalies.length > 0) {
      await LogisticsDB.logSecurityEvent({
        action: 'vehicle_telemetry_anomaly',
        details: `Vehicle ${vehicle.name} (ID: ${vehicleId}) telemetry anomalies: ${anomalies.map(a => a.message).join('; ')}`,
        severity: anomalies.some(a => a.severity === 'high') ? 'warning' : 'info'
      })
    }
    
    // Calculate estimated time of arrival (ETA) for current delivery
    // In a real implementation, this would use the vehicle's current location and route information
    // For this simulation, we'll use a simplified calculation
    
    // Get current delivery for this vehicle
    const { results: currentDelivery } = await cf.env.DB.prepare(`
      SELECT d.*, r.distance, r.estimated_duration
      FROM deliveries d
      JOIN routes r ON d.route_id = r.id
      WHERE d.vehicle_id = ? AND d.status = 'in_progress'
      ORDER BY d.scheduled_date ASC
      LIMIT 1
    `).bind(vehicleId).all()
    
    let eta = null
    
    if (currentDelivery.length > 0) {
      const delivery = currentDelivery[0]
      
      // Get route details
      const route = await LogisticsDB.getRouteById(delivery.route_id)
      
      if (route) {
        // Parse optimized route JSON
        const routeData = route.optimized_route_json ? JSON.parse(route.optimized_route_json) : null
        
        if (routeData) {
          // Calculate distance from current location to destination
          const currentLocation = telemetryData.location
          const destinationLocation = routeData.end.coordinates
          
          const remainingDistance = calculateDistance(
            currentLocation.lat, 
            currentLocation.lon, 
            destinationLocation.lat, 
            destinationLocation.lon
          )
          
          // Calculate ETA based on remaining distance and current speed
          const remainingTimeHours = telemetryData.speed > 0 
            ? remainingDistance / telemetryData.speed 
            : (route.estimated_duration / 60) // Fall back to route estimated time if vehicle is stopped
          
          const remainingTimeMinutes = remainingTimeHours * 60
          
          // Create ETA timestamp
          const etaDate = new Date()
          etaDate.setMinutes(etaDate.getMinutes() + remainingTimeMinutes)
          
          eta = {
            deliveryId: delivery.id,
            remainingDistance,
            remainingTimeMinutes,
            estimatedArrival: etaDate.toISOString()
          }
        }
      }
    }
    
    return {
      success: true,
      vehicleId,
      vehicleName: vehicle.name,
      timestamp: telemetryData.timestamp,
      location: telemetryData.location,
      anomalies,
      eta,
      status: anomalies.length > 0 ? 'warning' : 'normal'
    }
  } catch (error) {
    console.error('Process vehicle telemetry error:', error)
    return { success: false, message: 'Failed to process vehicle telemetry data' }
  }
}

// Helper function to calculate distance between two coordinates using Haversine formula
function calculateDistance(lat1: number, lon1: number, lat2: number, lon2: number): number {
  const R = 6371 // Radius of the earth in km
  const dLat = deg2rad(lat2 - lat1)
  const dLon = deg2rad(lon2 - lon1)
  const a =
    Math.sin(dLat / 2) * Math.sin(dLat / 2) +
    Math.cos(deg2rad(lat1)) * Math.cos(deg2rad(lat2)) *
    Math.sin(dLon / 2) * Math.sin(dLon / 2)
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a))
  const distance = R * c // Distance in km
  return distance
}

function deg2rad(deg: number): number {
  return deg * (Math.PI / 180)
}

// Process warehouse IoT sensor data
export async function processWarehouseSensorData(
  warehouseLocation: string,
  sensorData: {
    timestamp: string,
    temperature: number,
    humidity: number,
    motionDetected: boolean,
    doorStatus: 'open' | 'closed',
    lightLevel: number,
    batteryLevel: number,
    sensorId: string
  }
) {
  try {
    // In a real implementation, this would process data from IoT sensors in warehouses
    // For this simulation, we'll analyze the provided sensor data
    
    // Check for anomalies in sensor data
    const anomalies = []
    
    // Temperature check
    if (sensorData.temperature < 5 || sensorData.temperature > 30) {
      anomalies.push({
        type: 'temperature',
        value: sensorData.temperature,
        thresholdLow: 5,
        thresholdHigh: 30,
        severity: 'medium',
        message: `Warehouse temperature outside normal range (${sensorData.temperature}°C)`
      })
    }
    
    // Humidity check
    if (sensorData.humidity < 20 || sensorData.humidity > 80) {
      anomalies.push({
        type: 'humidity',
        value: sensorData.humidity,
        thresholdLow: 20,
        thresholdHigh: 80,
        severity: 'medium',
        message: `Warehouse humidity outside normal range (${sensorData.humidity}%)`
      })
    }
    
    // Door status check during non-business hours
    const timestamp = new Date(sensorData.timestamp)
    const hour = timestamp.getHours()
    const isBusinessHours = hour >= 8 && hour <= 18
    
    if (sensorData.doorStatus === 'open' && !isBusinessHours) {
      anomalies.push({
        type: 'door_status',
        value: sensorData.doorStatus,
        severity: 'high',
        message: `Warehouse door open during non-business hours (${timestamp.toLocaleTimeString()})`
      })
    }
    
    // Motion detection during non-business hours
    if (sensorData.motionDetected && !isBusinessHours) {
      anomalies.push({
        type: 'motion',
        value: sensorData.motionDetected,
        severity: 'high',
        message: `Motion detected during non-business hours (${timestamp.toLocaleTimeString()})`
      })
    }
    
    // Battery level check
    if (sensorData.batteryLevel < 20) {
      anomalies.push({
        type: 'battery_level',
        value: sensorData.batteryLevel,
        threshold: 20,
        severity: sensorData.batteryLevel < 10 ? 'high' : 'medium',
        message: `Sensor battery level low (${sensorData.batteryLevel}%)`
      })
    }
    
    // Store sensor data (in a real implementation, this would be stored in a time-series database)
    // For this simulation, we'll log it as a security event if there are anomalies
    if (anomalies.length > 0) {
      await LogisticsDB.logSecurityEvent({
        action: 'warehouse_sensor_anomaly',
        details: `Warehouse ${warehouseLocation} sensor anomalies: ${anomalies.map(a => a.message).join('; ')}`,
        severity: anomalies.some(a => a.severity === 'high') ? 'warning' : 'info'
      })
    }
    
    return {
      success: true,
      warehouseLocation,
      sensorId: sensorData.sensorId,
      timestamp: sensorData.timestamp,
      anomalies,
      status: anomalies.length > 0 ? 'warning' : 'normal'
    }
  } catch (error) {
    console.error('Process warehouse sensor data error:', error)
    return { success: false, message: 'Failed to process warehouse sensor data' }
  }
}

// Process delivery confirmation via mobile device
export async function processDeliveryConfirmation(
  deliveryId: number,
  confirmationData: {
    timestamp: string,
    location: { lat: number, lon: number },
    signature?: string,
    photoEvidence?: string,
    notes?: string,
    deliveryStatus: 'delivered' | 'failed' | 'partial'
  }
) {
  try {
    // Get delivery details
    const cf = await getCloudflareContext()
    const { results } = await cf.env.DB.prepare(
      'SELECT * FROM deliveries WHERE id = ?'
    ).bind(deliveryId).all()
    
    const delivery = results[0]
    
    if (!delivery) {
      return { success: false, message: 'Delivery not found' }
    }
    
    // Verify delivery location against route end location
    const route = await LogisticsDB.getRouteById(delivery.route_id)
    
    if (!route) {
      return { success: false, message: 'Route not found' }
    }
    
    // Parse optimized route JSON
    const routeData = route.optimized_route_json ? JSON.parse(route.optimized_route_json) : null
    
    let locationVerified = false
    
    if (routeData && routeData.end && routeData.end.coordinates) {
      const destinationLocation = routeData.end.coordinates
      const confirmationLocation = confirmationData.location
      
      // Calculate distance between confirmation location and destination
      const distance = calculateDistance(
        confirmationLocation.lat,
        confirmationLocation.lon,
        destinationLocation.lat,
        destinationLocation.lon
      )
      
      // Verify if confirmation location is within 500 meters of destination
      locationVerified = distance <= 0.5
    }
    
    // Update delivery status
    let newStatus = 'completed'
    
    if (confirmationData.deliveryStatus === 'failed') {
      newStatus = 'failed'
    } else if (confirmationData.deliveryStatus === 'partial') {
      newStatus = 'partial'
    }
    
    await cf.env.DB.prepare(`
      UPDATE deliveries 
      SET status = ?, actual_end_time = ?, notes = ?, updated_at = CURRENT_TIMESTAMP
      WHERE id = ?
    `).bind(
      newStatus,
      confirmationData.timestamp,
      confirmationData.notes || null,
      deliveryId
    ).run()
    
    // Log the delivery confirmation
    await LogisticsDB.logSecurityEvent({
      action: 'delivery_confirmation',
      details: `Delivery ID ${deliveryId} confirmed as ${newStatus}. Location verified: ${locationVerified}`,
      severity: 'info'
    })
    
    return {
      success: true,
      deliveryId,
      status: newStatus,
      timestamp: confirmationData.timestamp,
      locationVerified,
      message: `Delivery ${newStatus} successfully recorded`
    }
  } catch (error) {
    console.error('Process delivery confirmation error:', error)
    return { success: false, message: 'Failed to process delivery confirmation' }
  }
}

// Process real-time traffic data for route optimization
export async function processTrafficData(
  routeId: number,
  trafficData: {
    timestamp: string,
    segments: Array<{
      startLocation: { lat: number, lon: number },
      endLocation: { lat: number, lon: number },
      distance: number,
      currentSpeed: number,
      normalSpeed: number,
      congestionLevel: 'low' | 'medium' | 'high' | 'severe'
    }>
  }
) {
  try {
    // Get route details
    const route = await LogisticsDB.getRouteById(routeId)
    
    if (!route) {
      return { success: false, message: 'Route not found' }
    }
    
    // Calculate impact on route
    let totalDistance = 0
    let totalTimeNormal = 0
    let totalTimeCurrent = 0
    let hasSevereCongestion = false
    
    for (const segment of trafficData.segments) {
      totalDistance += segment.distance
      
      const timeNormal = segment.distance / segment.normalSpeed * 60 // minutes
      const timeCurrent = segment.distance / segment.currentSpeed * 60 // minutes
      
      totalTimeNormal += timeNormal
      totalTimeCurrent += timeCurrent
      
      if (segment.congestionLevel === 'severe') {
        hasSevereCongestion = true
      }
    }
    
    // Calculate delay
    const delay = totalTimeCurrent - totalTimeNormal
    const delayPercentage = (delay / totalTimeNormal) * 100
    
    // Determine if rerouting is recommended
    const rerouteRecommended = delayPercentage > 25 || hasSevereCongestion
    
    // Find alternative routes if rerouting is recommended
    let alternativeRoutes = []
    
    if (rerouteRecommended) {
      const cf = await getCloudflareContext()
      const { results } = await cf.env.DB.prepare(`
        SELECT * FROM routes 
        WHERE company_id = ? AND id != ? AND 
              start_location = ? AND end_location = ?
        ORDER BY distance ASC
      `).bind(
        route.company_id,
        routeId,
        route.start_location,
        route.end_location
      ).all()
      
      alternativeRoutes = results.map(r => ({
        id: r.id,
        name: r.name,
        distance: r.distance,
        estimatedDuration: r.estimated_duration
      }))
    }
    
    // Update estimated duration for the route based on current traffic
    if (delay > 0) {
      const cf = await getCloudflareContext()
      await cf.env.DB.prepare(`
        UPDATE routes 
        SET estimated_duration = ?, updated_at = CURRENT_TIMESTAMP
        WHERE id = ?
      `).bind(
        route.estimated_duration + delay,
        routeId
      ).run()
    }
    
    return {
      success: true,
      routeId,
      routeName: route.name,
      timestamp: trafficData.timestamp,
      trafficImpact: {
        normalDuration: totalTimeNormal,
        currentDuration: totalTimeCurrent,
        delay,
        delayPercentage,
        hasSevereCongestion
      },
      rerouteRecommended,
      alternativeRoutes
    }
  } catch (error) {
    console.error('Process traffic data error:', error)
    return { success: false, message: 'Failed to process traffic data' }
  }
}
