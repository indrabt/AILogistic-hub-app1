'use server'
import { getCloudflareContext } from '@opennextjs/cloudflare'
import { LogisticsDB } from '@/lib/db'
import * as tf from '@tensorflow/tfjs'

// Supply Chain Analytics AI for the AI-Powered Smart Logistics Hub

// Demand forecasting model
export async function forecastDemand(companyId: number, productId: number, daysAhead: number = 30) {
  try {
    const cf = await getCloudflareContext()
    
    // Get historical inventory data
    const { results: inventoryHistory } = await cf.env.DB.prepare(`
      SELECT updated_at, quantity 
      FROM inventory 
      WHERE id = ? 
      ORDER BY updated_at ASC
    `).bind(productId).all()
    
    if (inventoryHistory.length < 10) {
      return { 
        success: false, 
        message: 'Insufficient historical data for forecasting. Need at least 10 data points.' 
      }
    }
    
    // Extract quantities for time series analysis
    const quantities = inventoryHistory.map(record => record.quantity)
    
    // Simple moving average forecast
    const windowSize = 7 // 7-day moving average
    const movingAverages = []
    
    for (let i = windowSize; i <= quantities.length; i++) {
      const window = quantities.slice(i - windowSize, i)
      const average = window.reduce((sum, val) => sum + val, 0) / windowSize
      movingAverages.push(average)
    }
    
    // Calculate trend
    const trend = calculateTrend(movingAverages)
    
    // Project forward
    const lastAverage = movingAverages[movingAverages.length - 1]
    const forecast = []
    
    for (let i = 1; i <= daysAhead; i++) {
      forecast.push(Math.max(0, Math.round(lastAverage + trend * i)))
    }
    
    // Calculate confidence intervals (simple approach)
    const stdDev = calculateStandardDeviation(movingAverages)
    const upperBound = forecast.map(val => Math.round(val + 1.96 * stdDev))
    const lowerBound = forecast.map(val => Math.max(0, Math.round(val - 1.96 * stdDev)))
    
    return {
      success: true,
      forecast: {
        productId,
        daysAhead,
        predictedDemand: forecast,
        upperBound,
        lowerBound,
        confidence: 0.95, // 95% confidence interval
        trend: trend < 0 ? 'decreasing' : 'increasing',
        trendValue: trend
      }
    }
  } catch (error) {
    console.error('Demand forecasting error:', error)
    return { success: false, message: 'Failed to forecast demand' }
  }
}

// Helper function to calculate trend
function calculateTrend(data: number[]): number {
  if (data.length < 2) return 0
  
  const n = data.length
  let sumX = 0
  let sumY = 0
  let sumXY = 0
  let sumXX = 0
  
  for (let i = 0; i < n; i++) {
    sumX += i
    sumY += data[i]
    sumXY += i * data[i]
    sumXX += i * i
  }
  
  const slope = (n * sumXY - sumX * sumY) / (n * sumXX - sumX * sumX)
  return slope
}

// Helper function to calculate standard deviation
function calculateStandardDeviation(data: number[]): number {
  const n = data.length
  const mean = data.reduce((sum, val) => sum + val, 0) / n
  const variance = data.reduce((sum, val) => sum + Math.pow(val - mean, 2), 0) / n
  return Math.sqrt(variance)
}

// Optimize inventory levels
export async function optimizeInventoryLevels(companyId: number) {
  try {
    // Get all inventory items for the company
    const inventory = await LogisticsDB.getInventoryByCompanyId(companyId)
    
    // Get historical delivery data
    const cf = await getCloudflareContext()
    const { results: deliveryHistory } = await cf.env.DB.prepare(`
      SELECT scheduled_date, status
      FROM deliveries
      WHERE company_id = ?
      ORDER BY scheduled_date ASC
    `).bind(companyId).all()
    
    // Calculate lead time based on historical deliveries
    const leadTimes = []
    for (let i = 1; i < deliveryHistory.length; i++) {
      if (deliveryHistory[i].status === 'completed' && deliveryHistory[i-1].status === 'completed') {
        const date1 = new Date(deliveryHistory[i-1].scheduled_date)
        const date2 = new Date(deliveryHistory[i].scheduled_date)
        const diffTime = Math.abs(date2.getTime() - date1.getTime())
        const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24))
        leadTimes.push(diffDays)
      }
    }
    
    // Calculate average lead time
    const avgLeadTime = leadTimes.length > 0 
      ? leadTimes.reduce((sum, val) => sum + val, 0) / leadTimes.length 
      : 7 // Default to 7 days if no data
    
    // Optimize each inventory item
    const optimizedItems = []
    
    for (const item of inventory) {
      // Forecast demand for this item
      const forecastResult = await forecastDemand(companyId, item.id, 30)
      
      if (!forecastResult.success) {
        continue
      }
      
      // Calculate average daily demand
      const avgDailyDemand = forecastResult.forecast.predictedDemand.reduce((sum, val) => sum + val, 0) / 
                            forecastResult.forecast.predictedDemand.length
      
      // Calculate safety stock (based on service level and lead time variability)
      // Using simplified formula: Safety Stock = Z * σ * √L
      // where Z is the service level factor, σ is demand standard deviation, L is lead time
      
      const serviceLevel = 0.95 // 95% service level
      const zScore = 1.645 // Z-score for 95% service level
      const demandStdDev = calculateStandardDeviation(forecastResult.forecast.predictedDemand)
      const leadTimeStdDev = calculateStandardDeviation(leadTimes) || 1 // Default to 1 if no data
      
      const safetyStock = Math.ceil(zScore * demandStdDev * Math.sqrt(avgLeadTime))
      
      // Calculate Economic Order Quantity (EOQ)
      // Using simplified formula: EOQ = √(2DS/H)
      // where D is annual demand, S is order cost, H is holding cost
      
      const annualDemand = avgDailyDemand * 365
      const orderCost = 100 // Placeholder - cost to place an order
      const holdingCost = 0.2 // Placeholder - 20% of item value per year
      
      const eoq = Math.ceil(Math.sqrt((2 * annualDemand * orderCost) / holdingCost))
      
      // Calculate Reorder Point (ROP)
      // ROP = (Average Daily Demand × Lead Time) + Safety Stock
      
      const reorderPoint = Math.ceil((avgDailyDemand * avgLeadTime) + safetyStock)
      
      // Update reorder level in database
      const cf = await getCloudflareContext()
      await cf.env.DB.prepare(
        'UPDATE inventory SET reorder_level = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?'
      ).bind(reorderPoint, item.id).run()
      
      optimizedItems.push({
        id: item.id,
        name: item.item_name,
        currentQuantity: item.quantity,
        reorderPoint,
        safetyStock,
        economicOrderQuantity: eoq,
        avgDailyDemand,
        avgLeadTime
      })
    }
    
    return {
      success: true,
      optimizedItems,
      totalItems: inventory.length
    }
  } catch (error) {
    console.error('Optimize inventory levels error:', error)
    return { success: false, message: 'Failed to optimize inventory levels' }
  }
}

// Identify supply chain bottlenecks
export async function identifyBottlenecks(companyId: number) {
  try {
    const cf = await getCloudflareContext()
    
    // Analyze delivery delays
    const { results: deliveryDelays } = await cf.env.DB.prepare(`
      SELECT 
        route_id,
        COUNT(*) as total_deliveries,
        SUM(CASE WHEN actual_end_time > scheduled_date THEN 1 ELSE 0 END) as delayed_deliveries,
        AVG(CASE WHEN actual_end_time > scheduled_date 
            THEN (julianday(actual_end_time) - julianday(scheduled_date)) * 24 * 60
            ELSE 0 END) as avg_delay_minutes
      FROM deliveries
      WHERE company_id = ? AND status = 'completed' AND actual_end_time IS NOT NULL
      GROUP BY route_id
      HAVING delayed_deliveries > 0
      ORDER BY avg_delay_minutes DESC
    `).bind(companyId).all()
    
    // Analyze inventory stockouts
    const { results: inventoryStockouts } = await cf.env.DB.prepare(`
      SELECT 
        id,
        item_name,
        quantity,
        reorder_level,
        (julianday('now') - julianday(updated_at)) as days_since_update
      FROM inventory
      WHERE company_id = ? AND quantity = 0
      ORDER BY days_since_update DESC
    `).bind(companyId).all()
    
    // Analyze vehicle utilization
    const { results: vehicleUtilization } = await cf.env.DB.prepare(`
      SELECT 
        v.id,
        v.name,
        COUNT(d.id) as delivery_count,
        SUM(CASE WHEN d.status = 'completed' THEN 1 ELSE 0 END) as completed_deliveries,
        SUM(CASE WHEN d.status = 'cancelled' THEN 1 ELSE 0 END) as cancelled_deliveries
      FROM vehicles v
      LEFT JOIN deliveries d ON v.id = d.vehicle_id
      WHERE v.company_id = ?
      GROUP BY v.id
      ORDER BY delivery_count DESC
    `).bind(companyId).all()
    
    // Identify bottlenecks
    const bottlenecks = []
    
    // Route bottlenecks (routes with high delay rates)
    for (const route of deliveryDelays) {
      if (route.total_deliveries >= 5 && (route.delayed_deliveries / route.total_deliveries) > 0.3) {
        // Get route details
        const { results: routeDetails } = await cf.env.DB.prepare(
          'SELECT * FROM routes WHERE id = ?'
        ).bind(route.route_id).all()
        
        if (routeDetails.length > 0) {
          bottlenecks.push({
            type: 'route',
            id: route.route_id,
            name: routeDetails[0].name,
            start_location: routeDetails[0].start_location,
            end_location: routeDetails[0].end_location,
            delay_rate: (route.delayed_deliveries / route.total_deliveries) * 100,
            avg_delay_minutes: route.avg_delay_minutes,
            recommendation: 'Review route for optimization opportunities or traffic pattern changes'
          })
        }
      }
    }
    
    // Inventory bottlenecks (items with stockouts)
    for (const item of inventoryStockouts) {
      bottlenecks.push({
        type: 'inventory',
        id: item.id,
        name: item.item_name,
        days_out_of_stock: item.days_since_update,
        recommendation: 'Increase reorder level and review supplier lead times'
      })
    }
    
    // Vehicle bottlenecks (vehicles with high cancellation rates)
    for (const vehicle of vehicleUtilization) {
      if (vehicle.delivery_count >= 5 && (vehicle.cancelled_deliveries / vehicle.delivery_count) > 0.2) {
        bottlenecks.push({
          type: 'vehicle',
          id: vehicle.id,
          name: vehicle.name,
          cancellation_rate: (vehicle.cancelled_deliveries / vehicle.delivery_count) * 100,
          recommendation: 'Schedule maintenance check or consider vehicle replacement'
        })
      }
    }
    
    return {
      success: true,
      bottlenecks,
      routeDelays: deliveryDelays,
      inventoryStockouts,
      vehicleUtilization
    }
  } catch (error) {
    console.error('Identify bottlenecks error:', error)
    return { success: false, message: 'Failed to identify supply chain bottlenecks' }
  }
}

// Simulate supply chain scenarios
export async function simulateSupplyChainScenario(
  companyId: number, 
  scenario: 'demand_spike' | 'supplier_delay' | 'route_disruption',
  parameters: any
) {
  try {
    // Different simulation logic based on scenario type
    switch (scenario) {
      case 'demand_spike':
        return simulateDemandSpike(companyId, parameters)
      case 'supplier_delay':
        return simulateSupplierDelay(companyId, parameters)
      case 'route_disruption':
        return simulateRouteDisruption(companyId, parameters)
      default:
        return { success: false, message: 'Invalid scenario type' }
    }
  } catch (error) {
    console.error('Simulate supply chain scenario error:', error)
    return { success: false, message: 'Failed to simulate supply chain scenario' }
  }
}

// Simulate demand spike
async function simulateDemandSpike(companyId: number, parameters: { demandIncrease: number, duration: number }) {
  try {
    const { demandIncrease, duration } = parameters
    
    // Get current inventory levels
    const inventory = await LogisticsDB.getInventoryByCompanyId(companyId)
    
    // Simulate impact on each inventory item
    const impactedItems = []
    
    for (const item of inventory) {
      // Calculate days until stockout under increased demand
      const dailyDemand = 5 // Placeholder - would be calculated from historical data
      const increasedDemand = dailyDemand * (1 + demandIncrease / 100)
      const daysUntilStockout = item.quantity / increasedDemand
      
      // Check if stockout would occur during the spike duration
      const stockoutRisk = daysUntilStockout < duration
      
      // Calculate additional inventory needed to prevent stockout
      const additionalNeeded = stockoutRisk 
        ? Math.ceil((increasedDemand * duration) - item.quantity) 
        : 0
      
      impactedItems.push({
        id: item.id,
        name: item.item_name,
        currentQuantity: item.quantity,
        daysUntilStockout,
        stockoutRisk,
        additionalNeeded
      })
    }
    
    // Sort by stockout risk (most at risk first)
    impactedItems.sort((a, b) => a.daysUntilStockout - b.daysUntilStockout)
    
    return {
      success: true,
      scenario: 'demand_spike',
      parameters,
      impactedItems,
      recommendation: impactedItems.some(item => item.stockoutRisk)
        ? 'Increase inventory levels for at-risk items immediately'
        : 'Current inventory levels sufficient to handle the projected demand spike'
    }
  } catch (error) {
    console.error('Simulate demand spike error:', error)
    return { success: false, message: 'Failed to simulate demand spike' }
  }
}

// Simulate supplier delay
async function simulateSupplierDelay(companyId: number, parameters: { delayDays: number, affectedItems: number[] }) {
  try {
    const { delayDays, affectedItems } = parameters
    
    // Get affected inventory items
    const inventory = await LogisticsDB.getInventoryByCompanyId(companyId)
    const filteredInventory = affectedItems.length > 0
      ? inventory.filter(item => affectedItems.includes(item.id))
      : inventory
    
    // Simulate impact on each inventory item
    const impactedItems = []
    
    for (const item of filteredInventory) {
      // Calculate days of supply remaining
      const dailyDemand = 5 // Placeholder - would be calculated from historical data
      const daysOfSupply = item.quantity / dailyDemand
      
      // Check if stockout would occur during the delay
      const stockoutRisk = daysOfSupply < delayDays
      
      // Calculate safety stock needed to prevent stockout
      const additionalNeeded = stockoutRisk 
        ? Math.ceil((dailyDemand * delayDays) - item.quantity) 
        : 0
      
      impactedItems.push({
        id: item.id,
        name: item.item_name,
        currentQuantity: item.quantity,
        daysOfSupply,
        stockoutRisk,
        additionalNeeded
      })
    }
    
    // Sort by stockout risk (most at risk first)
    impactedItems.sort((a, b) => a.daysOfSupply - b.daysOfSupply)
    
    return {
      success: true,
      scenario: 'supplier_delay',
      parameters,
      impactedItems,
      recommendation: impactedItems.some(item => item.stockoutRisk)
        ? 'Identify alternative suppliers for at-risk items and increase safety stock'
        : 'Current inventory levels sufficient to handle the projected supplier delay'
    }
  } catch (error) {
    console.error('Simulate supplier delay error:', error)
    return { success: false, message: 'Failed to simulate supplier delay' }
  }
}

// Simulate route disruption
async function simulateRouteDisruption(companyId: number, parameters: { routeId: number, disruptionDays: number }) {
  try {
    const { routeId, disruptionDays } = parameters
    
    // Get affected route
    const route = await LogisticsDB.getRouteById(routeId)
    
    if (!route) {
      return { success: false, message: 'Route not found' }
    }
    
    // Get scheduled deliveries on this route
    const cf = await getCloudflareContext()
    const { results: affectedDeliveries } = await cf.env.DB.prepare(`
      SELECT * FROM deliveries 
      WHERE route_id = ? AND status = 'scheduled'
      ORDER BY scheduled_date ASC
    `).bind(routeId).all()
    
    // Calculate impact on deliveries
    const impactedDeliveries = []
    const currentDate = new Date()
    
    for (const delivery of affectedDeliveries) {
      const deliveryDate = new Date(delivery.scheduled_date)
      const daysDifference = Math.ceil((deliveryDate.getTime() - currentDate.getTime()) / (1000 * 60 * 60 * 24))
      
      // Check if delivery would be affected by disruption
      const isAffected = daysDifference <= disruptionDays
      
      if (isAffected) {
        impactedDeliveries.push({
          id: delivery.id,
          scheduledDate: delivery.scheduled_date,
          daysTillDelivery: daysDifference
        })
      }
    }
    
    // Find alternative routes
    const { results: alternativeRoutes } = await cf.env.DB.prepare(`
      SELECT * FROM routes 
      WHERE company_id = ? AND id != ? AND 
            (start_location = ? OR start_location LIKE ? OR
             end_location = ? OR end_location LIKE ?)
      ORDER BY distance ASC
    `).bind(
      companyId, 
      routeId,
      route.start_location,
      `%${route.start_location}%`,
      route.end_location,
      `%${route.end_location}%`
    ).all()
    
    return {
      success: true,
      scenario: 'route_disruption',
      parameters,
      route: {
        id: route.id,
        name: route.name,
        startLocation: route.start_location,
        endLocation: route.end_location
      },
      impactedDeliveries,
      alternativeRoutes: alternativeRoutes.map(r => ({
        id: r.id,
        name: r.name,
        startLocation: r.start_location,
        endLocation: r.end_location,
        distance: r.distance,
        estimatedDuration: r.estimated_duration
      })),
      recommendation: alternativeRoutes.length > 0
        ? `Reroute affected deliveries to alternative route: ${alternativeRoutes[0].name}`
        : 'Create new alternative routes or reschedule deliveries after disruption period'
    }
  } catch (error) {
    console.error('Simulate route disruption error:', error)
    return { success: false, message: 'Failed to simulate route disruption' }
  }
}
