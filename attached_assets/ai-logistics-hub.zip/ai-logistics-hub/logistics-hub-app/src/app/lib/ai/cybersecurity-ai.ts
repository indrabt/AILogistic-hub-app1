'use server'
import { getCloudflareContext } from '@opennextjs/cloudflare'
import { LogisticsDB } from '@/lib/db'
import { headers } from 'next/headers'

// Cybersecurity AI for the AI-Powered Smart Logistics Hub

// Detect and log suspicious login attempts
export async function detectSuspiciousLogin(
  userId: number,
  loginData: {
    timestamp: string,
    ipAddress: string,
    userAgent: string,
    success: boolean,
    failureReason?: string
  }
) {
  try {
    // Get user details
    const user = await LogisticsDB.getUserById(userId)
    
    if (!user) {
      return { success: false, message: 'User not found' }
    }
    
    // Check for suspicious patterns
    const cf = await getCloudflareContext()
    
    // Get recent login attempts for this user
    const { results: recentLogins } = await cf.env.DB.prepare(`
      SELECT * FROM security_logs
      WHERE user_id = ? AND action = 'login' AND created_at >= datetime('now', '-1 day')
      ORDER BY created_at DESC
    `).bind(userId).all()
    
    // Check for multiple failed login attempts
    const recentFailedLogins = recentLogins.filter(log => 
      log.details && log.details.includes('Failed login attempt')
    )
    
    // Check for logins from unusual locations
    // In a real implementation, this would use IP geolocation
    // For this simulation, we'll use a simplified approach
    const { results: usualIPs } = await cf.env.DB.prepare(`
      SELECT DISTINCT ip_address FROM security_logs
      WHERE user_id = ? AND action = 'login' AND details LIKE '%successful%'
      AND created_at >= datetime('now', '-30 days')
    `).bind(userId).all()
    
    const usualIPAddresses = usualIPs.map(record => record.ip_address)
    const isUnusualLocation = !usualIPAddresses.includes(loginData.ipAddress)
    
    // Determine risk level
    let riskLevel = 'low'
    const riskFactors = []
    
    if (recentFailedLogins.length >= 3) {
      riskLevel = 'high'
      riskFactors.push('Multiple failed login attempts')
    }
    
    if (isUnusualLocation) {
      riskLevel = riskLevel === 'high' ? 'high' : 'medium'
      riskFactors.push('Login from unusual location')
    }
    
    // Check for unusual login time
    const loginTime = new Date(loginData.timestamp)
    const hour = loginTime.getHours()
    const isBusinessHours = hour >= 8 && hour <= 18
    
    if (!isBusinessHours) {
      riskLevel = riskLevel === 'high' ? 'high' : 'medium'
      riskFactors.push('Login outside business hours')
    }
    
    // Log the login attempt
    const logDetails = loginData.success
      ? `Successful login for user ${user.email}`
      : `Failed login attempt for user ${user.email}. Reason: ${loginData.failureReason || 'Unknown'}`
    
    await LogisticsDB.logSecurityEvent({
      user_id: userId,
      action: 'login',
      ip_address: loginData.ipAddress,
      details: logDetails,
      severity: loginData.success ? 'info' : 'warning'
    })
    
    // If suspicious, log additional security event
    if (riskFactors.length > 0) {
      await LogisticsDB.logSecurityEvent({
        user_id: userId,
        action: 'suspicious_login',
        ip_address: loginData.ipAddress,
        details: `Suspicious login detected: ${riskFactors.join(', ')}`,
        severity: riskLevel === 'high' ? 'warning' : 'info'
      })
    }
    
    return {
      success: true,
      userId,
      email: user.email,
      timestamp: loginData.timestamp,
      riskLevel,
      riskFactors,
      isUnusualLocation,
      isOutsideBusinessHours: !isBusinessHours
    }
  } catch (error) {
    console.error('Detect suspicious login error:', error)
    return { success: false, message: 'Failed to detect suspicious login' }
  }
}

// Detect data access anomalies
export async function detectDataAccessAnomalies(
  userId: number,
  accessData: {
    timestamp: string,
    resource: string,
    action: 'read' | 'write' | 'delete',
    recordCount: number
  }
) {
  try {
    // Get user details
    const user = await LogisticsDB.getUserById(userId)
    
    if (!user) {
      return { success: false, message: 'User not found' }
    }
    
    // Get user's typical access patterns
    const cf = await getCloudflareContext()
    const { results: accessHistory } = await cf.env.DB.prepare(`
      SELECT * FROM access_logs
      WHERE user_id = ? AND path LIKE ?
      AND accessed_at >= datetime('now', '-30 days')
      ORDER BY accessed_at DESC
    `).bind(userId, `%${accessData.resource}%`).all()
    
    // Calculate average record count for this resource
    let avgRecordCount = 0
    if (accessHistory.length > 0) {
      // In a real implementation, this would parse the record count from the access logs
      // For this simulation, we'll use a placeholder
      avgRecordCount = 50
    }
    
    // Determine if current access is anomalous
    const isAnomalous = accessData.recordCount > avgRecordCount * 3
    
    // Check for unusual access time
    const accessTime = new Date(accessData.timestamp)
    const hour = accessTime.getHours()
    const isBusinessHours = hour >= 8 && hour <= 18
    
    // Determine risk level
    let riskLevel = 'low'
    const riskFactors = []
    
    if (isAnomalous) {
      riskLevel = 'medium'
      riskFactors.push(`Unusual number of records accessed (${accessData.recordCount} vs avg ${avgRecordCount})`)
    }
    
    if (!isBusinessHours) {
      riskLevel = riskLevel === 'medium' ? 'high' : 'medium'
      riskFactors.push('Access outside business hours')
    }
    
    if (accessData.action === 'delete' && accessData.recordCount > 10) {
      riskLevel = 'high'
      riskFactors.push(`Mass deletion of records (${accessData.recordCount} records)`)
    }
    
    // Log the access
    await LogisticsDB.logAccess({
      user_id: userId,
      ip_address: headers().get('x-forwarded-for') || 'unknown',
      path: accessData.resource,
      method: accessData.action.toUpperCase(),
      status_code: 200
    })
    
    // If anomalous, log security event
    if (riskFactors.length > 0) {
      await LogisticsDB.logSecurityEvent({
        user_id: userId,
        action: 'anomalous_data_access',
        ip_address: headers().get('x-forwarded-for') || 'unknown',
        details: `Anomalous data access detected: ${riskFactors.join(', ')}`,
        severity: riskLevel === 'high' ? 'warning' : 'info'
      })
    }
    
    return {
      success: true,
      userId,
      email: user.email,
      resource: accessData.resource,
      action: accessData.action,
      timestamp: accessData.timestamp,
      isAnomalous,
      riskLevel,
      riskFactors
    }
  } catch (error) {
    console.error('Detect data access anomalies error:', error)
    return { success: false, message: 'Failed to detect data access anomalies' }
  }
}

// Detect API abuse patterns
export async function detectAPIAbuse(
  apiData: {
    endpoint: string,
    method: string,
    ipAddress: string,
    timestamp: string,
    requestCount: number,
    timeWindow: number // in minutes
  }
) {
  try {
    // Define rate limits for different endpoints
    const rateLimits = {
      '/api/auth': 10, // 10 requests per minute
      '/api/routes': 30, // 30 requests per minute
      '/api/inventory': 30, // 30 requests per minute
      '/api/deliveries': 30, // 30 requests per minute
      '/api/analytics': 20, // 20 requests per minute
      'default': 50 // 50 requests per minute for other endpoints
    }
    
    // Determine applicable rate limit
    let rateLimit = rateLimits.default
    for (const [endpoint, limit] of Object.entries(rateLimits)) {
      if (apiData.endpoint.startsWith(endpoint)) {
        rateLimit = limit
        break
      }
    }
    
    // Adjust rate limit based on time window
    const adjustedRateLimit = rateLimit * (apiData.timeWindow / 1)
    
    // Check if request count exceeds rate limit
    const isAbusive = apiData.requestCount > adjustedRateLimit
    
    // Determine risk level
    let riskLevel = 'low'
    const riskFactors = []
    
    if (isAbusive) {
      const excessPercentage = (apiData.requestCount / adjustedRateLimit) * 100 - 100
      
      if (excessPercentage > 200) {
        riskLevel = 'high'
        riskFactors.push(`Excessive API requests (${apiData.requestCount} vs limit ${adjustedRateLimit})`)
      } else {
        riskLevel = 'medium'
        riskFactors.push(`Above-limit API requests (${apiData.requestCount} vs limit ${adjustedRateLimit})`)
      }
    }
    
    // Check for suspicious patterns in auth endpoints
    if (apiData.endpoint.startsWith('/api/auth') && apiData.requestCount > 5) {
      riskLevel = riskLevel === 'high' ? 'high' : 'medium'
      riskFactors.push('Multiple authentication attempts')
    }
    
    // Log security event if abusive
    if (isAbusive) {
      await LogisticsDB.logSecurityEvent({
        action: 'api_abuse',
        ip_address: apiData.ipAddress,
        details: `API abuse detected: ${riskFactors.join(', ')}`,
        severity: riskLevel === 'high' ? 'warning' : 'info'
      })
    }
    
    return {
      success: true,
      endpoint: apiData.endpoint,
      method: apiData.method,
      ipAddress: apiData.ipAddress,
      timestamp: apiData.timestamp,
      requestCount: apiData.requestCount,
      rateLimit: adjustedRateLimit,
      isAbusive,
      riskLevel,
      riskFactors,
      recommendedAction: isAbusive 
        ? riskLevel === 'high' 
          ? 'Block IP address temporarily' 
          : 'Implement progressive rate limiting'
        : 'No action needed'
    }
  } catch (error) {
    console.error('Detect API abuse error:', error)
    return { success: false, message: 'Failed to detect API abuse' }
  }
}

// Generate security report
export async function generateSecurityReport(companyId: number, period: 'day' | 'week' | 'month' = 'week') {
  try {
    const cf = await getCloudflareContext()
    
    // Define time period filter
    let timeFilter = ''
    if (period === 'day') {
      timeFilter = "AND created_at >= datetime('now', '-1 day')"
    } else if (period === 'week') {
      timeFilter = "AND created_at >= datetime('now', '-7 days')"
    } else {
      timeFilter = "AND created_at >= datetime('now', '-30 days')"
    }
    
    // Get security events for the period
    const { results: securityEvents } = await cf.env.DB.prepare(`
      SELECT * FROM security_logs
      WHERE (user_id IN (SELECT id FROM users WHERE company_id = ?) OR user_id IS NULL)
      ${timeFilter}
      ORDER BY created_at DESC
    `).bind(companyId).all()
    
    // Get company details
    const company = await LogisticsDB.getCompanyById(companyId)
    
    if (!company) {
      return { success: false, message: 'Company not found' }
    }
    
    // Categorize security events
    const loginEvents = securityEvents.filter(event => 
      event.action === 'login' || event.action === 'suspicious_login'
    )
    
    const dataAccessEvents = securityEvents.filter(event => 
      event.action === 'anomalous_data_access'
    )
    
    const apiAbuseEvents = securityEvents.filter(event => 
      event.action === 'api_abuse'
    )
    
    const otherEvents = securityEvents.filter(event => 
      !['login', 'suspicious_login', 'anomalous_data_access', 'api_abuse'].includes(event.action)
    )
    
    // Count events by severity
    const infoEvents = securityEvents.filter(event => event.severity === 'info').length
    const warningEvents = securityEvents.filter(event => event.severity === 'warning').length
    const errorEvents = securityEvents.filter(event => event.severity === 'error').length
    
    // Identify top security concerns
    const topConcerns = []
    
    if (loginEvents.filter(event => event.action === 'suspicious_login').length > 0) {
      topConcerns.push('Suspicious login attempts detected')
    }
    
    if (dataAccessEvents.length > 0) {
      topConcerns.push('Anomalous data access patterns detected')
    }
    
    if (apiAbuseEvents.length > 0) {
      topConcerns.push('API abuse detected')
    }
    
    if (warningEvents + errorEvents > 10) {
      topConcerns.push('High number of security warnings and errors')
    }
    
    // Generate recommendations
    const recommendations = []
    
    if (loginEvents.filter(event => event.action === 'suspicious_login').length > 0) {
      recommendations.push('Implement multi-factor authentication for all users')
      recommendations.push('Review and update password policies')
    }
    
    if (dataAccessEvents.length > 0) {
      recommendations.push('Implement more granular access controls')
      recommendations.push('Review user permissions and apply principle of least privilege')
    }
    
    if (apiAbuseEvents.length > 0) {
      recommendations.push('Implement more aggressive rate limiting')
      recommendations.push('Consider implementing API key authentication')
    }
    
    return {
      success: true,
      companyName: company.name,
      period,
      reportDate: new Date().toISOString(),
      summary: {
        totalEvents: securityEvents.length,
        loginEvents: loginEvents.length,
        dataAccessEvents: dataAccessEvents.length,
        apiAbuseEvents: apiAbuseEvents.length,
        otherEvents: otherEvents.length,
        severityCounts: {
          info: infoEvents,
          warning: warningEvents,
          error: errorEvents
        }
      },
      topConcerns,
      recommendations,
      recentEvents: securityEvents.slice(0, 10).map(event => ({
        id: event.id,
        timestamp: event.created_at,
        action: event.action,
        severity: event.severity,
        details: event.details
      }))
    }
  } catch (error) {
    console.error('Generate security report error:', error)
    return { success: false, message: 'Failed to generate security report' }
  }
}
