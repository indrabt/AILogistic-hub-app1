'use server'
import { getCloudflareContext } from '@opennextjs/cloudflare'
import { LogisticsDB } from '@/lib/db'
import { headers } from 'next/headers'

// Sustainable AI for the AI-Powered Smart Logistics Hub

// Calculate carbon footprint for a delivery
export async function calculateCarbonFootprint(deliveryId: number) {
  try {
    const cf = await getCloudflareContext()
    
    // Get delivery details with route and vehicle information
    const { results } = await cf.env.DB.prepare(`
      SELECT d.*, r.distance, v.fuel_type, v.fuel_efficiency
      FROM deliveries d
      JOIN routes r ON d.route_id = r.id
      JOIN vehicles v ON d.vehicle_id = v.id
      WHERE d.id = ?
    `).bind(deliveryId).all()
    
    if (results.length === 0) {
      return { success: false, message: 'Delivery not found or missing route/vehicle data' }
    }
    
    const delivery = results[0]
    
    // Calculate fuel consumption based on distance and vehicle efficiency
    // Default to 10 km/L if fuel efficiency is not available
    const fuelEfficiency = delivery.fuel_efficiency || 10 // km/L
    const fuelConsumed = delivery.distance / fuelEfficiency // liters
    
    // Calculate carbon emissions based on fuel type
    // CO2 emissions in kg per liter of fuel
    const emissionFactors = {
      'petrol': 2.31,
      'diesel': 2.68,
      'lpg': 1.51,
      'cng': 1.63,
      'electric': 0,
      'hybrid': 1.15
    }
    
    const fuelType = (delivery.fuel_type || 'diesel').toLowerCase()
    const emissionFactor = emissionFactors[fuelType] || emissionFactors.diesel
    
    const carbonEmissions = fuelConsumed * emissionFactor
    
    // Update delivery with carbon footprint
    await cf.env.DB.prepare(`
      UPDATE deliveries 
      SET carbon_footprint = ?, fuel_used = ?, updated_at = CURRENT_TIMESTAMP
      WHERE id = ?
    `).bind(
      carbonEmissions,
      fuelConsumed,
      deliveryId
    ).run()
    
    // Add to sustainability metrics
    const today = new Date().toISOString().split('T')[0]
    
    // Check if there's an existing record for today
    const { results: existingMetrics } = await cf.env.DB.prepare(`
      SELECT * FROM sustainability_metrics
      WHERE company_id = ? AND date = ?
    `).bind(delivery.company_id, today).all()
    
    if (existingMetrics.length > 0) {
      // Update existing record
      await cf.env.DB.prepare(`
        UPDATE sustainability_metrics
        SET total_distance = total_distance + ?,
            total_fuel_used = total_fuel_used + ?,
            carbon_emissions = carbon_emissions + ?,
            updated_at = CURRENT_TIMESTAMP
        WHERE id = ?
      `).bind(
        delivery.distance,
        fuelConsumed,
        carbonEmissions,
        existingMetrics[0].id
      ).run()
    } else {
      // Create new record
      await LogisticsDB.createSustainabilityMetric({
        company_id: delivery.company_id,
        date: today,
        total_distance: delivery.distance,
        total_fuel_used: fuelConsumed,
        carbon_emissions: carbonEmissions
      })
    }
    
    return {
      success: true,
      deliveryId,
      distance: delivery.distance,
      fuelType,
      fuelEfficiency,
      fuelConsumed,
      carbonEmissions,
      carbonIntensity: carbonEmissions / delivery.distance // kg CO2 per km
    }
  } catch (error) {
    console.error('Calculate carbon footprint error:', error)
    return { success: false, message: 'Failed to calculate carbon footprint' }
  }
}

// Optimize routes for minimal environmental impact
export async function optimizeForEnvironmentalImpact(companyId: number, routeIds: number[]) {
  try {
    const optimizedRoutes = []
    
    for (const routeId of routeIds) {
      // Get route details
      const route = await LogisticsDB.getRouteById(routeId)
      
      if (!route) {
        continue
      }
      
      // Parse optimized route JSON
      const routeData = route.optimized_route_json ? JSON.parse(route.optimized_route_json) : null
      
      if (!routeData) {
        continue
      }
      
      // Get available vehicles
      const cf = await getCloudflareContext()
      const { results: vehicles } = await cf.env.DB.prepare(`
        SELECT * FROM vehicles
        WHERE company_id = ? AND status = 'available'
        ORDER BY 
          CASE 
            WHEN fuel_type = 'electric' THEN 1
            WHEN fuel_type = 'hybrid' THEN 2
            WHEN fuel_type = 'cng' THEN 3
            WHEN fuel_type = 'lpg' THEN 4
            WHEN fuel_type = 'petrol' THEN 5
            WHEN fuel_type = 'diesel' THEN 6
            ELSE 7
          END,
          fuel_efficiency DESC
      `).bind(companyId).all()
      
      if (vehicles.length === 0) {
        continue
      }
      
      // Select the most eco-friendly vehicle
      const ecoFriendlyVehicle = vehicles[0]
      
      // Calculate carbon footprint for this route with the selected vehicle
      const fuelEfficiency = ecoFriendlyVehicle.fuel_efficiency || 10 // km/L
      const fuelConsumed = route.distance / fuelEfficiency // liters
      
      // Calculate carbon emissions based on fuel type
      const emissionFactors = {
        'petrol': 2.31,
        'diesel': 2.68,
        'lpg': 1.51,
        'cng': 1.63,
        'electric': 0,
        'hybrid': 1.15
      }
      
      const fuelType = (ecoFriendlyVehicle.fuel_type || 'diesel').toLowerCase()
      const emissionFactor = emissionFactors[fuelType] || emissionFactors.diesel
      
      const carbonEmissions = fuelConsumed * emissionFactor
      
      // Check if there are any time-of-day optimizations possible
      // For example, avoiding peak traffic times can reduce emissions
      const timeOptimizations = [
        {
          timeWindow: '10:00-14:00',
          emissionReduction: 0.15, // 15% reduction
          reason: 'Off-peak traffic hours'
        },
        {
          timeWindow: '19:00-22:00',
          emissionReduction: 0.1, // 10% reduction
          reason: 'Evening hours with less traffic'
        }
      ]
      
      // Calculate potential savings with time optimizations
      const timeOptimizationSavings = timeOptimizations.map(opt => ({
        timeWindow: opt.timeWindow,
        potentialSaving: carbonEmissions * opt.emissionReduction,
        reason: opt.reason
      }))
      
      optimizedRoutes.push({
        routeId,
        routeName: route.name,
        distance: route.distance,
        recommendedVehicle: {
          id: ecoFriendlyVehicle.id,
          name: ecoFriendlyVehicle.name,
          fuelType: ecoFriendlyVehicle.fuel_type,
          fuelEfficiency
        },
        environmentalImpact: {
          fuelConsumed,
          carbonEmissions,
          carbonIntensity: carbonEmissions / route.distance
        },
        timeOptimizations: timeOptimizationSavings
      })
    }
    
    return {
      success: true,
      optimizedRoutes,
      totalPotentialSavings: optimizedRoutes.reduce(
        (total, route) => total + route.timeOptimizations.reduce(
          (sum, opt) => sum + opt.potentialSaving, 0
        ), 0
      )
    }
  } catch (error) {
    console.error('Optimize for environmental impact error:', error)
    return { success: false, message: 'Failed to optimize routes for environmental impact' }
  }
}

// Calculate energy efficiency score
export async function calculateEnergyEfficiencyScore(companyId: number) {
  try {
    const cf = await getCloudflareContext()
    
    // Get sustainability metrics for the last 30 days
    const { results: metrics } = await cf.env.DB.prepare(`
      SELECT * FROM sustainability_metrics
      WHERE company_id = ? AND date >= date('now', '-30 days')
      ORDER BY date DESC
    `).bind(companyId).all()
    
    if (metrics.length === 0) {
      return { success: false, message: 'No sustainability metrics available for the last 30 days' }
    }
    
    // Calculate total distance, fuel used, and carbon emissions
    const totalDistance = metrics.reduce((sum, m) => sum + m.total_distance, 0)
    const totalFuelUsed = metrics.reduce((sum, m) => sum + m.total_fuel_used, 0)
    const totalCarbonEmissions = metrics.reduce((sum, m) => sum + m.carbon_emissions, 0)
    
    // Calculate average fuel efficiency (km/L)
    const avgFuelEfficiency = totalDistance / totalFuelUsed
    
    // Calculate carbon intensity (g CO2/km)
    const carbonIntensity = (totalCarbonEmissions * 1000) / totalDistance // convert kg to g
    
    // Get industry benchmarks (these would be stored in a database in a real implementation)
    const industryBenchmarks = {
      fuelEfficiency: 8.5, // km/L
      carbonIntensity: 220 // g CO2/km
    }
    
    // Calculate scores (0-100 scale)
    const fuelEfficiencyScore = Math.min(100, Math.round((avgFuelEfficiency / industryBenchmarks.fuelEfficiency) * 100))
    const carbonIntensityScore = Math.min(100, Math.round((1 - (carbonIntensity / industryBenchmarks.carbonIntensity)) * 100))
    
    // Calculate overall energy efficiency score (weighted average)
    const overallScore = Math.round((fuelEfficiencyScore * 0.5) + (carbonIntensityScore * 0.5))
    
    // Update the most recent sustainability metric with the energy efficiency score
    if (metrics.length > 0) {
      await cf.env.DB.prepare(`
        UPDATE sustainability_metrics
        SET energy_efficiency_score = ?
        WHERE id = ?
      `).bind(overallScore, metrics[0].id).run()
    }
    
    // Generate recommendations based on score
    const recommendations = []
    
    if (fuelEfficiencyScore < 70) {
      recommendations.push('Consider upgrading to more fuel-efficient vehicles')
      recommendations.push('Implement driver training for eco-driving techniques')
      recommendations.push('Ensure regular vehicle maintenance to optimize fuel efficiency')
    }
    
    if (carbonIntensityScore < 70) {
      recommendations.push('Transition fleet to lower-emission vehicles (electric, hybrid, or CNG)')
      recommendations.push('Optimize routes to minimize distance and avoid congestion')
      recommendations.push('Consider carbon offset programs for unavoidable emissions')
    }
    
    return {
      success: true,
      metrics: {
        totalDistance,
        totalFuelUsed,
        totalCarbonEmissions,
        avgFuelEfficiency,
        carbonIntensity
      },
      scores: {
        fuelEfficiencyScore,
        carbonIntensityScore,
        overallScore
      },
      industryBenchmarks,
      recommendations
    }
  } catch (error) {
    console.error('Calculate energy efficiency score error:', error)
    return { success: false, message: 'Failed to calculate energy efficiency score' }
  }
}

// Generate sustainability report
export async function generateSustainabilityReport(companyId: number, period: 'month' | 'quarter' | 'year' = 'month') {
  try {
    const cf = await getCloudflareContext()
    
    // Define time period filter
    let timeFilter = ''
    if (period === 'month') {
      timeFilter = "AND date >= date('now', '-30 days')"
    } else if (period === 'quarter') {
      timeFilter = "AND date >= date('now', '-90 days')"
    } else {
      timeFilter = "AND date >= date('now', '-365 days')"
    }
    
    // Get sustainability metrics for the period
    const { results: metrics } = await cf.env.DB.prepare(`
      SELECT * FROM sustainability_metrics
      WHERE company_id = ? ${timeFilter}
      ORDER BY date ASC
    `).bind(companyId).all()
    
    if (metrics.length === 0) {
      return { success: false, message: `No sustainability metrics available for the selected period (${period})` }
    }
    
    // Get company details
    const company = await LogisticsDB.getCompanyById(companyId)
    
    if (!company) {
      return { success: false, message: 'Company not found' }
    }
    
    // Calculate totals and averages
    const totalDistance = metrics.reduce((sum, m) => sum + m.total_distance, 0)
    const totalFuelUsed = metrics.reduce((sum, m) => sum + m.total_fuel_used, 0)
    const totalCarbonEmissions = metrics.reduce((sum, m) => sum + m.carbon_emissions, 0)
    const avgFuelEfficiency = totalDistance / totalFuelUsed
    const carbonIntensity = (totalCarbonEmissions * 1000) / totalDistance // g CO2/km
    
    // Calculate average energy efficiency score
    const avgEfficiencyScore = metrics
      .filter(m => m.energy_efficiency_score !== null)
      .reduce((sum, m) => sum + m.energy_efficiency_score, 0) / 
      metrics.filter(m => m.energy_efficiency_score !== null).length
    
    // Get vehicle fleet composition
    const { results: vehicles } = await cf.env.DB.prepare(`
      SELECT fuel_type, COUNT(*) as count
      FROM vehicles
      WHERE company_id = ?
      GROUP BY fuel_type
    `).bind(companyId).all()
    
    // Calculate fleet composition percentages
    const totalVehicles = vehicles.reduce((sum, v) => sum + v.count, 0)
    const fleetComposition = vehicles.map(v => ({
      fuelType: v.fuel_type || 'unknown',
      count: v.count,
      percentage: Math.round((v.count / totalVehicles) * 100)
    }))
    
    // Calculate trend (comparing first half vs second half of period)
    const midpoint = Math.floor(metrics.length / 2)
    const firstHalf = metrics.slice(0, midpoint)
    const secondHalf = metrics.slice(midpoint)
    
    const firstHalfEmissions = firstHalf.reduce((sum, m) => sum + m.carbon_emissions, 0)
    const secondHalfEmissions = secondHalf.reduce((sum, m) => sum + m.carbon_emissions, 0)
    
    const emissionsTrend = firstHalfEmissions > 0 
      ? ((secondHalfEmissions - firstHalfEmissions) / firstHalfEmissions) * 100 
      : 0
    
    // Generate recommendations
    const recommendations = []
    
    // Fleet composition recommendations
    const electricPercentage = fleetComposition.find(v => v.fuelType === 'electric')?.percentage || 0
    const hybridPercentage = fleetComposition.find(v => v.fuelType === 'hybrid')?.percentage || 0
    
    if (electricPercentage + hybridPercentage < 30) {
      recommendations.push('Increase the proportion of electric and hybrid vehicles in your fleet')
    }
    
    // Fuel efficiency recommendations
    if (avgFuelEfficiency < 10) {
      recommendations.push('Implement driver training programs to improve fuel efficiency')
      recommendations.push('Consider upgrading older vehicles to more fuel-efficient models')
    }
    
    // Carbon emissions recommendations
    if (carbonIntensity > 200) {
      recommendations.push('Optimize delivery routes to reduce total distance traveled')
      recommendations.push('Consider carbon offset programs for unavoidable emissions')
    }
    
    // Trend-based recommendations
    if (emissionsTrend > 5) {
      recommendations.push('Investigate the increase in carbon emissions and implement mitigation measures')
    } else if (emissionsTrend < -5) {
      recommendations.push('Continue with current sustainability initiatives as they are showing positive results')
    }
    
    return {
      success: true,
      companyName: company.name,
      period,
      reportDate: new Date().toISOString(),
      summary: {
        totalDistance,
        totalFuelUsed,
        totalCarbonEmissions,
        avgFuelEfficiency,
        carbonIntensity,
        avgEfficiencyScore: avgEfficiencyScore || 0
      },
      fleetComposition,
      trends: {
        emissionsTrend: Math.round(emissionsTrend * 100) / 100, // Round to 2 decimal places
        trend: emissionsTrend > 5 ? 'increasing' : emissionsTrend < -5 ? 'decreasing' : 'stable'
      },
      recommendations
    }
  } catch (error) {
    console.error('Generate sustainability report error:', error)
    return { success: false, message: 'Failed to generate sustainability report' }
  }
}
