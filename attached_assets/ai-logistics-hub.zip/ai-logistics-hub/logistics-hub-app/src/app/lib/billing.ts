'use server'
import { getCloudflareContext } from '@opennextjs/cloudflare'
import { LogisticsDB } from '@/lib/db'
import { headers } from 'next/headers'

// Billing service for the AI-Powered Smart Logistics Hub

// Subscription tier pricing (monthly)
const SUBSCRIPTION_PRICING = {
  basic: 5000, // $5,000
  standard: 10000, // $10,000
  premium: 20000 // $20,000
};

// Setup fee pricing
const SETUP_FEE_PRICING = {
  basic: 10000, // $10,000
  standard: 25000, // $25,000
  premium: 50000 // $50,000
};

// Calculate subscription cost
export async function calculateSubscriptionCost(companyId: number) {
  try {
    // Get company details
    const company = await LogisticsDB.getCompanyById(companyId);
    
    if (!company) {
      return { success: false, message: 'Company not found' };
    }
    
    // Get subscription tier
    const tier = company.subscription_tier || 'basic';
    
    // Calculate monthly cost
    const monthlyCost = SUBSCRIPTION_PRICING[tier] || SUBSCRIPTION_PRICING.basic;
    
    // Calculate annual cost
    const annualCost = monthlyCost * 12;
    
    // Calculate setup fee (one-time)
    const setupFee = SETUP_FEE_PRICING[tier] || SETUP_FEE_PRICING.basic;
    
    return {
      success: true,
      billing: {
        companyId,
        companyName: company.name,
        subscriptionTier: tier,
        monthlyCost,
        annualCost,
        setupFee,
        currency: 'USD'
      }
    };
  } catch (error) {
    console.error('Calculate subscription cost error:', error);
    return { success: false, message: 'Failed to calculate subscription cost' };
  }
}

// Generate invoice for a company
export async function generateInvoice(companyId: number, period: 'monthly' | 'annual' = 'monthly') {
  try {
    // Get company details
    const company = await LogisticsDB.getCompanyById(companyId);
    
    if (!company) {
      return { success: false, message: 'Company not found' };
    }
    
    // Get subscription tier
    const tier = company.subscription_tier || 'basic';
    
    // Calculate base subscription cost
    const monthlyCost = SUBSCRIPTION_PRICING[tier] || SUBSCRIPTION_PRICING.basic;
    const cost = period === 'monthly' ? monthlyCost : monthlyCost * 12;
    
    // Generate invoice number
    const invoiceNumber = `INV-${companyId}-${Date.now()}`;
    
    // Generate invoice date
    const invoiceDate = new Date().toISOString().split('T')[0];
    
    // Calculate due date (30 days from now)
    const dueDate = new Date();
    dueDate.setDate(dueDate.getDate() + 30);
    const dueDateStr = dueDate.toISOString().split('T')[0];
    
    // Create invoice items
    const items = [
      {
        description: `${tier.charAt(0).toUpperCase() + tier.slice(1)} Subscription (${period})`,
        quantity: 1,
        unitPrice: cost,
        total: cost
      }
    ];
    
    // Calculate total
    const subtotal = cost;
    const taxRate = 0.1; // 10% tax
    const taxAmount = subtotal * taxRate;
    const total = subtotal + taxAmount;
    
    // Create invoice object
    const invoice = {
      invoiceNumber,
      invoiceDate,
      dueDate: dueDateStr,
      companyId,
      companyName: company.name,
      companyAddress: company.address,
      companyCity: company.city,
      companyPostalCode: company.postal_code,
      subscriptionTier: tier,
      period,
      items,
      subtotal,
      taxRate,
      taxAmount,
      total,
      currency: 'USD',
      status: 'pending'
    };
    
    // In a real app, you would save this invoice to the database
    // For this example, we'll just return it
    
    return {
      success: true,
      invoice
    };
  } catch (error) {
    console.error('Generate invoice error:', error);
    return { success: false, message: 'Failed to generate invoice' };
  }
}

// Calculate usage-based costs
export async function calculateUsageCosts(companyId: number, period: 'month' | 'quarter' | 'year' = 'month') {
  try {
    const cf = await getCloudflareContext();
    
    // Define time period filter
    let timeFilter = '';
    if (period === 'month') {
      timeFilter = "AND scheduled_date >= date('now', '-30 days')";
    } else if (period === 'quarter') {
      timeFilter = "AND scheduled_date >= date('now', '-90 days')";
    } else {
      timeFilter = "AND scheduled_date >= date('now', '-365 days')";
    }
    
    // Get delivery count
    const { results: deliveryResults } = await cf.env.DB.prepare(`
      SELECT COUNT(*) as delivery_count
      FROM deliveries
      WHERE company_id = ? ${timeFilter}
    `).bind(companyId).all();
    
    // Get total distance
    const { results: distanceResults } = await cf.env.DB.prepare(`
      SELECT SUM(r.distance) as total_distance
      FROM routes r
      JOIN deliveries d ON r.id = d.route_id
      WHERE r.company_id = ? ${timeFilter}
    `).bind(companyId).all();
    
    // Calculate costs
    // These are simplified calculations - in a real app, you would have more complex pricing models
    const deliveryCount = deliveryResults[0].delivery_count || 0;
    const totalDistance = distanceResults[0].total_distance || 0;
    
    // Cost per delivery (varies by subscription tier)
    const company = await LogisticsDB.getCompanyById(companyId);
    const tier = company?.subscription_tier || 'basic';
    
    let costPerDelivery = 0;
    if (tier === 'basic') {
      costPerDelivery = 10; // $10 per delivery
    } else if (tier === 'standard') {
      costPerDelivery = 8; // $8 per delivery
    } else {
      costPerDelivery = 5; // $5 per delivery
    }
    
    // Cost per kilometer
    const costPerKm = 0.5; // $0.50 per km
    
    // Calculate total usage costs
    const deliveryCost = deliveryCount * costPerDelivery;
    const distanceCost = totalDistance * costPerKm;
    const totalUsageCost = deliveryCost + distanceCost;
    
    return {
      success: true,
      usageCosts: {
        period,
        deliveryCount,
        totalDistance,
        costPerDelivery,
        costPerKm,
        deliveryCost,
        distanceCost,
        totalUsageCost,
        currency: 'USD'
      }
    };
  } catch (error) {
    console.error('Calculate usage costs error:', error);
    return { success: false, message: 'Failed to calculate usage costs' };
  }
}

// Get subscription details
export async function getSubscriptionDetails(companyId: number) {
  try {
    // Get company details
    const company = await LogisticsDB.getCompanyById(companyId);
    
    if (!company) {
      return { success: false, message: 'Company not found' };
    }
    
    // Get subscription tier
    const tier = company.subscription_tier || 'basic';
    
    // Get subscription features
    const features = getSubscriptionFeatures(tier);
    
    // Get subscription start and end dates
    const startDate = company.subscription_start_date || new Date().toISOString();
    
    // Calculate end date if not set (1 year from start date)
    let endDate = company.subscription_end_date;
    if (!endDate) {
      const endDateObj = new Date(startDate);
      endDateObj.setFullYear(endDateObj.getFullYear() + 1);
      endDate = endDateObj.toISOString();
    }
    
    return {
      success: true,
      subscription: {
        companyId,
        companyName: company.name,
        tier,
        startDate,
        endDate,
        monthlyCost: SUBSCRIPTION_PRICING[tier],
        features,
        status: 'active' // In a real app, you would check the actual status
      }
    };
  } catch (error) {
    console.error('Get subscription details error:', error);
    return { success: false, message: 'Failed to get subscription details' };
  }
}

// Helper function to get subscription features
function getSubscriptionFeatures(tier: string) {
  const basicFeatures = [
    'Route optimization',
    'Inventory management',
    'Basic analytics',
    'Email support',
    'Up to 5 users'
  ];
  
  const standardFeatures = [
    ...basicFeatures,
    'Advanced analytics',
    'Risk assessment',
    'Sustainability tracking',
    'Phone support',
    'Up to 20 users'
  ];
  
  const premiumFeatures = [
    ...standardFeatures,
    'AI-powered predictions',
    'Custom integrations',
    'Dedicated account manager',
    'Priority support',
    'Unlimited users'
  ];
  
  switch (tier) {
    case 'premium':
      return premiumFeatures;
    case 'standard':
      return standardFeatures;
    default:
      return basicFeatures;
  }
}
