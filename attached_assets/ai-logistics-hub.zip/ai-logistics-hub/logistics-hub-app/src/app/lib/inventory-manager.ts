'use server'
import { getCloudflareContext } from '@opennextjs/cloudflare'
import { LogisticsDB } from '@/lib/db'
import { headers } from 'next/headers'

// Inventory management service for the AI-Powered Smart Logistics Hub

// Calculate reorder level based on historical data
function calculateReorderLevel(
  averageDailyUsage: number,
  leadTime: number,
  safetyStock: number
): number {
  // Reorder Level = (Average Daily Usage × Lead Time) + Safety Stock
  return (averageDailyUsage * leadTime) + safetyStock;
}

// Check if item needs reordering
export async function checkReorderStatus(itemId: number) {
  try {
    const cf = await getCloudflareContext()
    const { results } = await cf.env.DB.prepare(
      'SELECT * FROM inventory WHERE id = ?'
    ).bind(itemId).all()
    
    const item = results[0]
    
    if (!item) {
      return { success: false, message: 'Item not found' }
    }
    
    const needsReorder = item.reorder_level && item.quantity <= item.reorder_level
    
    return {
      success: true,
      itemId: item.id,
      itemName: item.item_name,
      currentQuantity: item.quantity,
      reorderLevel: item.reorder_level,
      needsReorder
    }
  } catch (error) {
    console.error('Check reorder status error:', error)
    return { success: false, message: 'Failed to check reorder status' }
  }
}

// Update inventory quantity
export async function updateInventory(
  itemId: number,
  newQuantity: number,
  reason: string
) {
  try {
    // Get current inventory
    const cf = await getCloudflareContext()
    const { results } = await cf.env.DB.prepare(
      'SELECT * FROM inventory WHERE id = ?'
    ).bind(itemId).all()
    
    const item = results[0]
    
    if (!item) {
      return { success: false, message: 'Item not found' }
    }
    
    // Update quantity
    await LogisticsDB.updateInventoryQuantity(itemId, newQuantity)
    
    // Log the update
    await cf.env.DB.prepare(
      'INSERT INTO security_logs (action, details, severity) VALUES (?, ?, ?)'
    ).bind(
      'inventory_update',
      `Item ${item.item_name} (ID: ${itemId}) quantity updated from ${item.quantity} to ${newQuantity}. Reason: ${reason}`,
      'info'
    ).run()
    
    // Check if reorder is needed
    const needsReorder = item.reorder_level && newQuantity <= item.reorder_level
    
    return {
      success: true,
      itemId,
      previousQuantity: item.quantity,
      newQuantity,
      needsReorder
    }
  } catch (error) {
    console.error('Update inventory error:', error)
    return { success: false, message: 'Failed to update inventory' }
  }
}

// Get low stock items for a company
export async function getLowStockItems(companyId: number) {
  try {
    const cf = await getCloudflareContext()
    const { results } = await cf.env.DB.prepare(`
      SELECT * FROM inventory 
      WHERE company_id = ? AND reorder_level IS NOT NULL AND quantity <= reorder_level
      ORDER BY (quantity / reorder_level) ASC
    `).bind(companyId).all()
    
    return {
      success: true,
      lowStockItems: results
    }
  } catch (error) {
    console.error('Get low stock items error:', error)
    return { success: false, message: 'Failed to get low stock items' }
  }
}

// Calculate optimal reorder levels for all inventory items
export async function optimizeReorderLevels(companyId: number) {
  try {
    // Get all inventory items for the company
    const inventory = await LogisticsDB.getInventoryByCompanyId(companyId)
    
    // For each item, calculate optimal reorder level
    // This is a simplified implementation
    // In a real app, you would use historical data and more sophisticated algorithms
    
    const updatedItems = []
    
    for (const item of inventory) {
      // Simplified calculation - in a real app, these would be based on historical data
      const averageDailyUsage = 5 // Placeholder
      const leadTime = 7 // Placeholder - days to receive new stock
      const safetyStock = 10 // Placeholder - buffer stock
      
      const optimalReorderLevel = calculateReorderLevel(
        averageDailyUsage,
        leadTime,
        safetyStock
      )
      
      // Only update if significantly different from current reorder level
      if (!item.reorder_level || 
          Math.abs(item.reorder_level - optimalReorderLevel) > 5) {
        
        // Update reorder level in database
        const cf = await getCloudflareContext()
        await cf.env.DB.prepare(
          'UPDATE inventory SET reorder_level = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?'
        ).bind(optimalReorderLevel, item.id).run()
        
        updatedItems.push({
          id: item.id,
          name: item.item_name,
          previousReorderLevel: item.reorder_level,
          newReorderLevel: optimalReorderLevel
        })
      }
    }
    
    return {
      success: true,
      updatedItems,
      totalItems: inventory.length
    }
  } catch (error) {
    console.error('Optimize reorder levels error:', error)
    return { success: false, message: 'Failed to optimize reorder levels' }
  }
}

// Get inventory statistics
export async function getInventoryStats(companyId: number) {
  try {
    const cf = await getCloudflareContext()
    
    // Get total inventory count
    const { results: countResults } = await cf.env.DB.prepare(
      'SELECT COUNT(*) as total FROM inventory WHERE company_id = ?'
    ).bind(companyId).all()
    
    // Get low stock count
    const { results: lowStockResults } = await cf.env.DB.prepare(`
      SELECT COUNT(*) as count FROM inventory 
      WHERE company_id = ? AND reorder_level IS NOT NULL AND quantity <= reorder_level
    `).bind(companyId).all()
    
    // Get total inventory value (assuming each item has a value field - would need to be added to schema)
    // This is a placeholder calculation
    const { results: inventoryItems } = await cf.env.DB.prepare(
      'SELECT SUM(quantity) as total_quantity FROM inventory WHERE company_id = ?'
    ).bind(companyId).all()
    
    return {
      success: true,
      stats: {
        totalItems: countResults[0].total,
        lowStockItems: lowStockResults[0].count,
        totalQuantity: inventoryItems[0].total_quantity || 0
      }
    }
  } catch (error) {
    console.error('Get inventory stats error:', error)
    return { success: false, message: 'Failed to get inventory statistics' }
  }
}
