'use server'
import { getCloudflareContext } from '@opennextjs/cloudflare'
import { LogisticsDB } from '@/lib/db'
import { headers } from 'next/headers'

// Route optimization service for the AI-Powered Smart Logistics Hub

// Simple distance calculation using Haversine formula
function calculateDistance(lat1: number, lon1: number, lat2: number, lon2: number): number {
  const R = 6371; // Radius of the earth in km
  const dLat = deg2rad(lat2 - lat1);
  const dLon = deg2rad(lon2 - lon1);
  const a =
    Math.sin(dLat / 2) * Math.sin(dLat / 2) +
    Math.cos(deg2rad(lat1)) * Math.cos(deg2rad(lat2)) *
    Math.sin(dLon / 2) * Math.sin(dLon / 2);
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
  const distance = R * c; // Distance in km
  return distance;
}

function deg2rad(deg: number): number {
  return deg * (Math.PI / 180);
}

// Calculate estimated duration based on distance and average speed
function calculateDuration(distance: number, avgSpeed: number = 50): number {
  // avgSpeed in km/h, returns duration in minutes
  return (distance / avgSpeed) * 60;
}

// Parse location string to coordinates
function parseLocation(location: string): { lat: number; lon: number } {
  // This is a simplified implementation
  // In a real app, you would use geocoding services
  
  // For demo purposes, we'll use a map of predefined locations
  const locationMap: Record<string, { lat: number; lon: number }> = {
    'Sydney': { lat: -33.8688, lon: 151.2093 },
    'Parramatta': { lat: -33.8150, lon: 151.0011 },
    'Penrith': { lat: -33.7511, lon: 150.6942 },
    'Liverpool': { lat: -33.9200, lon: 150.9210 },
    'Blacktown': { lat: -33.7711, lon: 150.9063 },
    'Campbelltown': { lat: -34.0733, lon: 150.8261 },
    'Badgerys Creek': { lat: -33.8789, lon: 150.7430 },
    'Richmond': { lat: -33.5983, lon: 150.7511 },
    'Windsor': { lat: -33.6161, lon: 150.8223 },
    'Katoomba': { lat: -33.7150, lon: 150.3120 }
  };
  
  // Try to match the location string to our predefined locations
  for (const [key, value] of Object.entries(locationMap)) {
    if (location.toLowerCase().includes(key.toLowerCase())) {
      return value;
    }
  }
  
  // Default to Sydney if no match found
  return locationMap['Sydney'];
}

// Optimize route between two points
export async function optimizeRoute(
  startLocation: string,
  endLocation: string,
  waypoints: string[] = []
) {
  try {
    // Parse locations to coordinates
    const start = parseLocation(startLocation);
    const end = parseLocation(endLocation);
    
    // Parse waypoints
    const waypointCoords = waypoints.map(wp => parseLocation(wp));
    
    // Calculate direct distance
    const directDistance = calculateDistance(start.lat, start.lon, end.lat, end.lon);
    
    // Calculate direct duration
    const directDuration = calculateDuration(directDistance);
    
    // If there are waypoints, calculate optimized route
    let totalDistance = directDistance;
    let totalDuration = directDuration;
    let optimizedWaypoints = [];
    
    if (waypointCoords.length > 0) {
      // This is a simplified optimization algorithm
      // In a real app, you would use more sophisticated algorithms
      
      // For demo purposes, we'll just sort waypoints by distance from start
      optimizedWaypoints = waypointCoords.map((wp, index) => ({
        index,
        location: waypoints[index],
        distance: calculateDistance(start.lat, start.lon, wp.lat, wp.lon)
      })).sort((a, b) => a.distance - b.distance);
      
      // Calculate total distance with waypoints
      let currentLat = start.lat;
      let currentLon = start.lon;
      
      totalDistance = 0;
      
      for (const wp of optimizedWaypoints) {
        const wpCoords = parseLocation(wp.location);
        const segmentDistance = calculateDistance(currentLat, currentLon, wpCoords.lat, wpCoords.lon);
        totalDistance += segmentDistance;
        currentLat = wpCoords.lat;
        currentLon = wpCoords.lon;
      }
      
      // Add final segment to destination
      totalDistance += calculateDistance(currentLat, currentLon, end.lat, end.lon);
      
      // Calculate total duration
      totalDuration = calculateDuration(totalDistance);
    }
    
    // Prepare optimized route JSON
    const optimizedRoute = {
      start: {
        location: startLocation,
        coordinates: start
      },
      end: {
        location: endLocation,
        coordinates: end
      },
      waypoints: optimizedWaypoints.map(wp => ({
        location: wp.location,
        coordinates: parseLocation(wp.location)
      })),
      metrics: {
        totalDistance: totalDistance,
        totalDuration: totalDuration,
        directDistance: directDistance,
        directDuration: directDuration,
        savings: directDistance - totalDistance
      }
    };
    
    return {
      success: true,
      route: optimizedRoute,
      distance: totalDistance,
      duration: totalDuration
    };
  } catch (error) {
    console.error('Route optimization error:', error);
    return { success: false, message: 'Failed to optimize route' };
  }
}

// Create a new route with optimization
export async function createOptimizedRoute(
  companyId: number,
  routeName: string,
  startLocation: string,
  endLocation: string,
  waypoints: string[] = []
) {
  try {
    // Optimize the route
    const optimizationResult = await optimizeRoute(startLocation, endLocation, waypoints);
    
    if (!optimizationResult.success) {
      return { success: false, message: optimizationResult.message };
    }
    
    // Create route in database
    const routeData = {
      company_id: companyId,
      name: routeName,
      start_location: startLocation,
      end_location: endLocation,
      distance: optimizationResult.distance,
      estimated_duration: optimizationResult.duration,
      optimized_route_json: JSON.stringify(optimizationResult.route),
      status: 'planned'
    };
    
    const result = await LogisticsDB.createRoute(routeData);
    
    if (!result) {
      return { success: false, message: 'Failed to create route' };
    }
    
    // Log the action
    await LogisticsDB.logAccess({
      user_id: null, // In a real app, you would get this from the session
      ip_address: headers().get('x-forwarded-for') || 'unknown',
      path: '/api/routes',
      method: 'POST',
      status_code: 200
    });
    
    return {
      success: true,
      routeId: result.id,
      optimization: optimizationResult.route
    };
  } catch (error) {
    console.error('Create optimized route error:', error);
    return { success: false, message: 'Failed to create optimized route' };
  }
}

// Assess route risk based on weather and other factors
export async function assessRouteRisk(routeId: number) {
  try {
    // Get route details
    const route = await LogisticsDB.getRouteById(routeId);
    
    if (!route) {
      return { success: false, message: 'Route not found' };
    }
    
    // Get weather data for the route locations
    const startLocationWeather = await LogisticsDB.getWeatherData(route.start_location, 1);
    const endLocationWeather = await LogisticsDB.getWeatherData(route.end_location, 1);
    
    // Determine risk factors
    const riskFactors = [];
    let riskLevel = 'low';
    
    // Check weather conditions
    if (startLocationWeather.length > 0) {
      const weather = startLocationWeather[0];
      
      if (weather.weather_condition?.toLowerCase().includes('rain') || 
          weather.weather_condition?.toLowerCase().includes('storm')) {
        riskFactors.push('Adverse weather conditions at starting location');
        riskLevel = 'medium';
      }
      
      if (weather.precipitation && weather.precipitation > 10) {
        riskFactors.push('Heavy precipitation at starting location');
        riskLevel = 'high';
      }
      
      if (weather.wind_speed && weather.wind_speed > 30) {
        riskFactors.push('High winds at starting location');
        riskLevel = 'high';
      }
    }
    
    if (endLocationWeather.length > 0) {
      const weather = endLocationWeather[0];
      
      if (weather.weather_condition?.toLowerCase().includes('rain') || 
          weather.weather_condition?.toLowerCase().includes('storm')) {
        riskFactors.push('Adverse weather conditions at destination');
        if (riskLevel === 'low') riskLevel = 'medium';
      }
      
      if (weather.precipitation && weather.precipitation > 10) {
        riskFactors.push('Heavy precipitation at destination');
        riskLevel = 'high';
      }
      
      if (weather.wind_speed && weather.wind_speed > 30) {
        riskFactors.push('High winds at destination');
        riskLevel = 'high';
      }
    }
    
    // Check route distance
    if (route.distance > 100) {
      riskFactors.push('Long distance route');
      if (riskLevel === 'low') riskLevel = 'medium';
    }
    
    // Generate recommendations
    const recommendations = [];
    
    if (riskLevel === 'medium' || riskLevel === 'high') {
      recommendations.push('Consider rescheduling if conditions worsen');
      recommendations.push('Ensure vehicles are properly maintained');
      recommendations.push('Brief drivers on adverse conditions');
    }
    
    if (riskLevel === 'high') {
      recommendations.push('Consider alternative routes');
      recommendations.push('Reduce vehicle speed');
      recommendations.push('Increase following distance');
      recommendations.push('Prepare emergency response plan');
    }
    
    // Save risk assessment
    const riskData = {
      route_id: routeId,
      risk_level: riskLevel,
      risk_factors: riskFactors.join('; '),
      recommendations: recommendations.join('; ')
    };
    
    const result = await LogisticsDB.createRiskAssessment(riskData);
    
    return {
      success: true,
      riskAssessment: {
        id: result.id,
        routeId: routeId,
        riskLevel: riskLevel,
        riskFactors: riskFactors,
        recommendations: recommendations
      }
    };
  } catch (error) {
    console.error('Route risk assessment error:', error);
    return { success: false, message: 'Failed to assess route risk' };
  }
}
