'use server'
import { getCloudflareContext } from '@opennextjs/cloudflare'
import { cookies } from 'next/headers'
import { LogisticsDB } from './db'
import crypto from 'crypto'
import { headers } from 'next/headers'

// Authentication utilities for the AI-Powered Smart Logistics Hub

// Hash password using SHA-256
export function hashPassword(password: string): string {
  return crypto.createHash('sha256').update(password).digest('hex')
}

// Verify password
export function verifyPassword(password: string, hashedPassword: string): boolean {
  const hashed = hashPassword(password)
  return hashed === hashedPassword
}

// Generate a secure token
export function generateToken(): string {
  return crypto.randomBytes(32).toString('hex')
}

// Set session cookie
export async function setSessionCookie(userId: number, token: string) {
  const cookieStore = cookies()
  
  // Store session in database
  const cf = await getCloudflareContext()
  await cf.env.DB.prepare(
    'INSERT INTO security_logs (user_id, action, ip_address, details, severity) VALUES (?, ?, ?, ?, ?)'
  ).bind(
    userId,
    'login',
    headers().get('x-forwarded-for') || 'unknown',
    'User logged in successfully',
    'info'
  ).run()
  
  // Set cookie with HTTP-only flag for security
  cookieStore.set('session', token, {
    httpOnly: true,
    secure: process.env.NODE_ENV === 'production',
    maxAge: 60 * 60 * 24 * 7, // 1 week
    path: '/',
  })
}

// Clear session cookie
export async function clearSessionCookie(userId: number) {
  const cookieStore = cookies()
  
  // Log logout
  const cf = await getCloudflareContext()
  await cf.env.DB.prepare(
    'INSERT INTO security_logs (user_id, action, ip_address, details, severity) VALUES (?, ?, ?, ?, ?)'
  ).bind(
    userId,
    'logout',
    headers().get('x-forwarded-for') || 'unknown',
    'User logged out',
    'info'
  ).run()
  
  // Clear cookie
  cookieStore.delete('session')
}

// Login user
export async function loginUser(email: string, password: string) {
  try {
    // Get user by email
    const user = await LogisticsDB.getUserByEmail(email)
    
    // If user not found or password doesn't match
    if (!user || !verifyPassword(password, user.password_hash)) {
      // Log failed login attempt
      const cf = await getCloudflareContext()
      await cf.env.DB.prepare(
        'INSERT INTO security_logs (action, ip_address, details, severity) VALUES (?, ?, ?, ?)'
      ).bind(
        'login_failed',
        headers().get('x-forwarded-for') || 'unknown',
        `Failed login attempt for email: ${email}`,
        'warning'
      ).run()
      
      return { success: false, message: 'Invalid email or password' }
    }
    
    // Generate session token
    const token = generateToken()
    
    // Update last login timestamp
    await LogisticsDB.updateUserLastLogin(user.id)
    
    // Set session cookie
    await setSessionCookie(user.id, token)
    
    // Log access
    await LogisticsDB.logAccess({
      user_id: user.id,
      ip_address: headers().get('x-forwarded-for') || 'unknown',
      path: '/api/auth/login',
      method: 'POST',
      status_code: 200
    })
    
    return { 
      success: true, 
      user: {
        id: user.id,
        email: user.email,
        firstName: user.first_name,
        lastName: user.last_name,
        role: user.role,
        companyId: user.company_id
      }
    }
  } catch (error) {
    console.error('Login error:', error)
    return { success: false, message: 'An error occurred during login' }
  }
}

// Logout user
export async function logoutUser(userId: number) {
  try {
    await clearSessionCookie(userId)
    return { success: true }
  } catch (error) {
    console.error('Logout error:', error)
    return { success: false, message: 'An error occurred during logout' }
  }
}

// Register new user
export async function registerUser(userData: {
  companyId: number,
  email: string,
  password: string,
  firstName: string,
  lastName: string,
  role: string
}) {
  try {
    // Check if user already exists
    const existingUser = await LogisticsDB.getUserByEmail(userData.email)
    if (existingUser) {
      return { success: false, message: 'Email already in use' }
    }
    
    // Hash password
    const passwordHash = hashPassword(userData.password)
    
    // Create user
    const result = await LogisticsDB.createUser({
      company_id: userData.companyId,
      email: userData.email,
      password_hash: passwordHash,
      first_name: userData.firstName,
      last_name: userData.lastName,
      role: userData.role
    })
    
    if (!result) {
      return { success: false, message: 'Failed to create user' }
    }
    
    // Log security event
    await LogisticsDB.logSecurityEvent({
      user_id: result.id,
      action: 'user_created',
      ip_address: headers().get('x-forwarded-for') || 'unknown',
      details: `New user created: ${userData.email}`,
      severity: 'info'
    })
    
    return { success: true, userId: result.id }
  } catch (error) {
    console.error('Registration error:', error)
    return { success: false, message: 'An error occurred during registration' }
  }
}

// Get current user from session
export async function getCurrentUser() {
  try {
    const cookieStore = cookies()
    const sessionToken = cookieStore.get('session')?.value
    
    if (!sessionToken) {
      return null
    }
    
    // In a real implementation, you would validate the token against a sessions table
    // For this example, we're using a simplified approach
    // You would typically have a sessions table that maps tokens to user IDs
    
    // This is a placeholder for demonstration
    // In a real app, you would query the sessions table to get the userId
    const userId = 1 // Placeholder
    
    const user = await LogisticsDB.getUserById(userId)
    if (!user) {
      return null
    }
    
    return {
      id: user.id,
      email: user.email,
      firstName: user.first_name,
      lastName: user.last_name,
      role: user.role,
      companyId: user.company_id
    }
  } catch (error) {
    console.error('Get current user error:', error)
    return null
  }
}

// Check if user has required role
export async function checkUserRole(requiredRole: string) {
  const user = await getCurrentUser()
  
  if (!user) {
    return false
  }
  
  // Simple role check - in a real app, you might have more complex permission logic
  if (requiredRole === 'admin' && user.role !== 'admin') {
    return false
  }
  
  if (requiredRole === 'manager' && !['admin', 'manager'].includes(user.role)) {
    return false
  }
  
  return true
}
