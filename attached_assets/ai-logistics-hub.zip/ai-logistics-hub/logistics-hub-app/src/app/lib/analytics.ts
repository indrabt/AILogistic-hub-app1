'use server'
import { getCloudflareContext } from '@opennextjs/cloudflare'
import { LogisticsDB } from '@/lib/db'
import { headers } from 'next/headers'

// Analytics service for the AI-Powered Smart Logistics Hub

// Get delivery performance metrics
export async function getDeliveryPerformance(companyId: number, period: 'day' | 'week' | 'month' = 'month') {
  try {
    const cf = await getCloudflareContext()
    
    // Define time period filter
    let timeFilter = ''
    if (period === 'day') {
      timeFilter = "AND scheduled_date >= date('now', '-1 day')"
    } else if (period === 'week') {
      timeFilter = "AND scheduled_date >= date('now', '-7 days')"
    } else {
      timeFilter = "AND scheduled_date >= date('now', '-30 days')"
    }
    
    // Get delivery statistics
    const { results } = await cf.env.DB.prepare(`
      SELECT 
        COUNT(*) as total_deliveries,
        SUM(CASE WHEN status = 'completed' THEN 1 ELSE 0 END) as completed_deliveries,
        SUM(CASE WHEN status = 'in_progress' THEN 1 ELSE 0 END) as in_progress_deliveries,
        SUM(CASE WHEN status = 'scheduled' THEN 1 ELSE 0 END) as scheduled_deliveries,
        SUM(CASE WHEN status = 'cancelled' THEN 1 ELSE 0 END) as cancelled_deliveries,
        AVG(CASE WHEN status = 'completed' AND actual_end_time IS NOT NULL AND actual_start_time IS NOT NULL
            THEN (julianday(actual_end_time) - julianday(actual_start_time)) * 24 * 60
            ELSE NULL END) as avg_delivery_time_minutes
      FROM deliveries
      WHERE company_id = ? ${timeFilter}
    `).bind(companyId).all()
    
    // Calculate on-time delivery rate
    const { results: onTimeResults } = await cf.env.DB.prepare(`
      SELECT 
        COUNT(*) as total_completed,
        SUM(CASE WHEN actual_end_time <= scheduled_date THEN 1 ELSE 0 END) as on_time_deliveries
      FROM deliveries
      WHERE company_id = ? AND status = 'completed' ${timeFilter}
    `).bind(companyId).all()
    
    const onTimeRate = onTimeResults[0].total_completed > 0 
      ? (onTimeResults[0].on_time_deliveries / onTimeResults[0].total_completed) * 100 
      : 0
    
    return {
      success: true,
      period,
      metrics: {
        ...results[0],
        on_time_rate: onTimeRate,
        on_time_deliveries: onTimeResults[0].on_time_deliveries,
        total_completed: onTimeResults[0].total_completed
      }
    }
  } catch (error) {
    console.error('Get delivery performance error:', error)
    return { success: false, message: 'Failed to get delivery performance metrics' }
  }
}

// Get route efficiency metrics
export async function getRouteEfficiency(companyId: number, period: 'day' | 'week' | 'month' = 'month') {
  try {
    const cf = await getCloudflareContext()
    
    // Define time period filter
    let timeFilter = ''
    if (period === 'day') {
      timeFilter = "AND d.scheduled_date >= date('now', '-1 day')"
    } else if (period === 'week') {
      timeFilter = "AND d.scheduled_date >= date('now', '-7 days')"
    } else {
      timeFilter = "AND d.scheduled_date >= date('now', '-30 days')"
    }
    
    // Get route efficiency metrics
    const { results } = await cf.env.DB.prepare(`
      SELECT 
        AVG(r.distance) as avg_route_distance,
        AVG(r.estimated_duration) as avg_estimated_duration,
        AVG(CASE WHEN d.status = 'completed' AND d.actual_end_time IS NOT NULL AND d.actual_start_time IS NOT NULL
            THEN (julianday(d.actual_end_time) - julianday(d.actual_start_time)) * 24 * 60
            ELSE NULL END) as avg_actual_duration,
        SUM(r.distance) as total_distance,
        COUNT(DISTINCT r.id) as total_routes
      FROM routes r
      JOIN deliveries d ON r.id = d.route_id
      WHERE r.company_id = ? ${timeFilter}
    `).bind(companyId).all()
    
    // Calculate efficiency ratio (estimated vs actual duration)
    const efficiencyRatio = results[0].avg_actual_duration && results[0].avg_estimated_duration
      ? results[0].avg_estimated_duration / results[0].avg_actual_duration
      : 0
    
    return {
      success: true,
      period,
      metrics: {
        ...results[0],
        efficiency_ratio: efficiencyRatio
      }
    }
  } catch (error) {
    console.error('Get route efficiency error:', error)
    return { success: false, message: 'Failed to get route efficiency metrics' }
  }
}

// Get sustainability metrics
export async function getSustainabilityMetrics(companyId: number, period: 'day' | 'week' | 'month' = 'month') {
  try {
    const cf = await getCloudflareContext()
    
    // Define time period filter
    let timeFilter = ''
    if (period === 'day') {
      timeFilter = "AND date >= date('now', '-1 day')"
    } else if (period === 'week') {
      timeFilter = "AND date >= date('now', '-7 days')"
    } else {
      timeFilter = "AND date >= date('now', '-30 days')"
    }
    
    // Get sustainability metrics
    const { results } = await cf.env.DB.prepare(`
      SELECT 
        SUM(total_distance) as total_distance,
        SUM(total_fuel_used) as total_fuel_used,
        SUM(carbon_emissions) as total_carbon_emissions,
        AVG(energy_efficiency_score) as avg_efficiency_score
      FROM sustainability_metrics
      WHERE company_id = ? ${timeFilter}
    `).bind(companyId).all()
    
    // Calculate fuel efficiency (km/L)
    const fuelEfficiency = results[0].total_fuel_used > 0
      ? results[0].total_distance / results[0].total_fuel_used
      : 0
    
    // Calculate carbon intensity (g CO2 / km)
    const carbonIntensity = results[0].total_distance > 0
      ? results[0].total_carbon_emissions / results[0].total_distance
      : 0
    
    return {
      success: true,
      period,
      metrics: {
        ...results[0],
        fuel_efficiency: fuelEfficiency,
        carbon_intensity: carbonIntensity
      }
    }
  } catch (error) {
    console.error('Get sustainability metrics error:', error)
    return { success: false, message: 'Failed to get sustainability metrics' }
  }
}

// Get company dashboard summary
export async function getDashboardSummary(companyId: number) {
  try {
    // Get delivery stats
    const deliveryStats = await LogisticsDB.getDeliveryStats(companyId)
    
    // Get route stats
    const routeStats = await LogisticsDB.getRouteStats(companyId)
    
    // Get sustainability stats
    const sustainabilityStats = await LogisticsDB.getSustainabilityStats(companyId)
    
    // Get inventory stats
    const cf = await getCloudflareContext()
    const { results: inventoryStats } = await cf.env.DB.prepare(`
      SELECT 
        COUNT(*) as total_items,
        SUM(CASE WHEN reorder_level IS NOT NULL AND quantity <= reorder_level THEN 1 ELSE 0 END) as low_stock_items
      FROM inventory
      WHERE company_id = ?
    `).bind(companyId).all()
    
    // Get vehicle stats
    const { results: vehicleStats } = await cf.env.DB.prepare(`
      SELECT 
        COUNT(*) as total_vehicles,
        SUM(CASE WHEN status = 'available' THEN 1 ELSE 0 END) as available_vehicles,
        SUM(CASE WHEN status = 'in_use' THEN 1 ELSE 0 END) as in_use_vehicles,
        SUM(CASE WHEN status = 'maintenance' THEN 1 ELSE 0 END) as maintenance_vehicles
      FROM vehicles
      WHERE company_id = ?
    `).bind(companyId).all()
    
    // Get recent deliveries
    const { results: recentDeliveries } = await cf.env.DB.prepare(`
      SELECT d.*, r.name as route_name, v.name as vehicle_name
      FROM deliveries d
      LEFT JOIN routes r ON d.route_id = r.id
      LEFT JOIN vehicles v ON d.vehicle_id = v.id
      WHERE d.company_id = ?
      ORDER BY d.scheduled_date DESC
      LIMIT 5
    `).bind(companyId).all()
    
    return {
      success: true,
      summary: {
        deliveryStats,
        routeStats,
        sustainabilityStats,
        inventoryStats: inventoryStats[0],
        vehicleStats: vehicleStats[0],
        recentDeliveries
      }
    }
  } catch (error) {
    console.error('Get dashboard summary error:', error)
    return { success: false, message: 'Failed to get dashboard summary' }
  }
}

// Generate performance report
export async function generatePerformanceReport(companyId: number, period: 'week' | 'month' | 'quarter' | 'year' = 'month') {
  try {
    // Define time period filter
    let timeFilter = ''
    if (period === 'week') {
      timeFilter = "AND scheduled_date >= date('now', '-7 days')"
    } else if (period === 'month') {
      timeFilter = "AND scheduled_date >= date('now', '-30 days')"
    } else if (period === 'quarter') {
      timeFilter = "AND scheduled_date >= date('now', '-90 days')"
    } else {
      timeFilter = "AND scheduled_date >= date('now', '-365 days')"
    }
    
    const cf = await getCloudflareContext()
    
    // Get delivery performance
    const { results: deliveryPerformance } = await cf.env.DB.prepare(`
      SELECT 
        COUNT(*) as total_deliveries,
        SUM(CASE WHEN status = 'completed' THEN 1 ELSE 0 END) as completed_deliveries,
        SUM(CASE WHEN status = 'cancelled' THEN 1 ELSE 0 END) as cancelled_deliveries,
        AVG(CASE WHEN status = 'completed' AND actual_end_time IS NOT NULL AND actual_start_time IS NOT NULL
            THEN (julianday(actual_end_time) - julianday(actual_start_time)) * 24 * 60
            ELSE NULL END) as avg_delivery_time_minutes
      FROM deliveries
      WHERE company_id = ? ${timeFilter}
    `).bind(companyId).all()
    
    // Get route efficiency
    const { results: routeEfficiency } = await cf.env.DB.prepare(`
      SELECT 
        AVG(r.distance) as avg_route_distance,
        SUM(r.distance) as total_distance,
        COUNT(DISTINCT r.id) as total_routes
      FROM routes r
      JOIN deliveries d ON r.id = d.route_id
      WHERE r.company_id = ? ${timeFilter}
    `).bind(companyId).all()
    
    // Get sustainability metrics
    const { results: sustainabilityMetrics } = await cf.env.DB.prepare(`
      SELECT 
        SUM(total_fuel_used) as total_fuel_used,
        SUM(carbon_emissions) as total_carbon_emissions
      FROM sustainability_metrics
      WHERE company_id = ? AND date >= date('now', '-${period === 'week' ? '7' : period === 'month' ? '30' : period === 'quarter' ? '90' : '365'} days')
    `).bind(companyId).all()
    
    // Calculate key performance indicators
    const completionRate = deliveryPerformance[0].total_deliveries > 0
      ? (deliveryPerformance[0].completed_deliveries / deliveryPerformance[0].total_deliveries) * 100
      : 0
    
    const cancellationRate = deliveryPerformance[0].total_deliveries > 0
      ? (deliveryPerformance[0].cancelled_deliveries / deliveryPerformance[0].total_deliveries) * 100
      : 0
    
    const fuelEfficiency = sustainabilityMetrics[0].total_fuel_used > 0 && routeEfficiency[0].total_distance
      ? routeEfficiency[0].total_distance / sustainabilityMetrics[0].total_fuel_used
      : 0
    
    const carbonIntensity = routeEfficiency[0].total_distance > 0 && sustainabilityMetrics[0].total_carbon_emissions
      ? sustainabilityMetrics[0].total_carbon_emissions / routeEfficiency[0].total_distance
      : 0
    
    return {
      success: true,
      period,
      report: {
        deliveryPerformance: {
          ...deliveryPerformance[0],
          completion_rate: completionRate,
          cancellation_rate: cancellationRate
        },
        routeEfficiency: routeEfficiency[0],
        sustainabilityMetrics: {
          ...sustainabilityMetrics[0],
          fuel_efficiency: fuelEfficiency,
          carbon_intensity: carbonIntensity
        },
        kpis: {
          completion_rate: completionRate,
          avg_delivery_time: deliveryPerformance[0].avg_delivery_time_minutes,
          fuel_efficiency: fuelEfficiency,
          carbon_intensity: carbonIntensity
        }
      }
    }
  } catch (error) {
    console.error('Generate performance report error:', error)
    return { success: false, message: 'Failed to generate performance report' }
  }
}
