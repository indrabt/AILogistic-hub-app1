'use server'
import { getCloudflareContext } from '@opennextjs/cloudflare';

// Database interface for the AI-Powered Smart Logistics Hub
export class LogisticsDB {
  // User Management
  static async getUserByEmail(email: string) {
    const cf = await getCloudflareContext()
    const { results } = await cf.env.DB.prepare(
      'SELECT * FROM users WHERE email = ?'
    ).bind(email).all()
    return results[0] || null
  }

  static async getUserById(id: number) {
    const cf = await getCloudflareContext()
    const { results } = await cf.env.DB.prepare(
      'SELECT * FROM users WHERE id = ?'
    ).bind(id).all()
    return results[0] || null
  }

  static async createUser(userData: {
    company_id: number,
    email: string,
    password_hash: string,
    first_name: string,
    last_name: string,
    role: string
  }) {
    const cf = await getCloudflareContext()
    const { results } = await cf.env.DB.prepare(
      'INSERT INTO users (company_id, email, password_hash, first_name, last_name, role) VALUES (?, ?, ?, ?, ?, ?) RETURNING id'
    ).bind(
      userData.company_id,
      userData.email,
      userData.password_hash,
      userData.first_name,
      userData.last_name,
      userData.role
    ).all()
    return results[0] || null
  }

  static async updateUserLastLogin(id: number) {
    const cf = await getCloudflareContext()
    await cf.env.DB.prepare(
      'UPDATE users SET last_login = CURRENT_TIMESTAMP, updated_at = CURRENT_TIMESTAMP WHERE id = ?'
    ).bind(id).run()
  }

  // Company Management
  static async getCompanyById(id: number) {
    const cf = await getCloudflareContext()
    const { results } = await cf.env.DB.prepare(
      'SELECT * FROM companies WHERE id = ?'
    ).bind(id).all()
    return results[0] || null
  }

  static async getAllCompanies() {
    const cf = await getCloudflareContext()
    const { results } = await cf.env.DB.prepare(
      'SELECT * FROM companies ORDER BY name'
    ).all()
    return results
  }

  static async createCompany(companyData: {
    name: string,
    address?: string,
    city?: string,
    postal_code?: string,
    contact_person?: string,
    contact_email?: string,
    contact_phone?: string,
    subscription_tier: string
  }) {
    const cf = await getCloudflareContext()
    const { results } = await cf.env.DB.prepare(
      'INSERT INTO companies (name, address, city, postal_code, contact_person, contact_email, contact_phone, subscription_tier) VALUES (?, ?, ?, ?, ?, ?, ?, ?) RETURNING id'
    ).bind(
      companyData.name,
      companyData.address || null,
      companyData.city || null,
      companyData.postal_code || null,
      companyData.contact_person || null,
      companyData.contact_email || null,
      companyData.contact_phone || null,
      companyData.subscription_tier
    ).all()
    return results[0] || null
  }

  // Route Management
  static async getRoutesByCompanyId(companyId: number) {
    const cf = await getCloudflareContext()
    const { results } = await cf.env.DB.prepare(
      'SELECT * FROM routes WHERE company_id = ? ORDER BY created_at DESC'
    ).bind(companyId).all()
    return results
  }

  static async getRouteById(id: number) {
    const cf = await getCloudflareContext()
    const { results } = await cf.env.DB.prepare(
      'SELECT * FROM routes WHERE id = ?'
    ).bind(id).all()
    return results[0] || null
  }

  static async createRoute(routeData: {
    company_id: number,
    name: string,
    start_location: string,
    end_location: string,
    distance?: number,
    estimated_duration?: number,
    optimized_route_json?: string,
    status?: string
  }) {
    const cf = await getCloudflareContext()
    const { results } = await cf.env.DB.prepare(
      'INSERT INTO routes (company_id, name, start_location, end_location, distance, estimated_duration, optimized_route_json, status) VALUES (?, ?, ?, ?, ?, ?, ?, ?) RETURNING id'
    ).bind(
      routeData.company_id,
      routeData.name,
      routeData.start_location,
      routeData.end_location,
      routeData.distance || null,
      routeData.estimated_duration || null,
      routeData.optimized_route_json || null,
      routeData.status || 'planned'
    ).all()
    return results[0] || null
  }

  static async updateRouteStatus(id: number, status: string) {
    const cf = await getCloudflareContext()
    await cf.env.DB.prepare(
      'UPDATE routes SET status = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?'
    ).bind(status, id).run()
  }

  // Vehicle Management
  static async getVehiclesByCompanyId(companyId: number) {
    const cf = await getCloudflareContext()
    const { results } = await cf.env.DB.prepare(
      'SELECT * FROM vehicles WHERE company_id = ? ORDER BY name'
    ).bind(companyId).all()
    return results
  }

  static async createVehicle(vehicleData: {
    company_id: number,
    name: string,
    type: string,
    capacity?: number,
    fuel_type?: string,
    fuel_efficiency?: number,
    status?: string
  }) {
    const cf = await getCloudflareContext()
    const { results } = await cf.env.DB.prepare(
      'INSERT INTO vehicles (company_id, name, type, capacity, fuel_type, fuel_efficiency, status) VALUES (?, ?, ?, ?, ?, ?, ?) RETURNING id'
    ).bind(
      vehicleData.company_id,
      vehicleData.name,
      vehicleData.type,
      vehicleData.capacity || null,
      vehicleData.fuel_type || null,
      vehicleData.fuel_efficiency || null,
      vehicleData.status || 'available'
    ).all()
    return results[0] || null
  }

  // Inventory Management
  static async getInventoryByCompanyId(companyId: number) {
    const cf = await getCloudflareContext()
    const { results } = await cf.env.DB.prepare(
      'SELECT * FROM inventory WHERE company_id = ? ORDER BY item_name'
    ).bind(companyId).all()
    return results
  }

  static async createInventoryItem(itemData: {
    company_id: number,
    item_name: string,
    item_sku?: string,
    quantity: number,
    unit?: string,
    warehouse_location?: string,
    reorder_level?: number
  }) {
    const cf = await getCloudflareContext()
    const { results } = await cf.env.DB.prepare(
      'INSERT INTO inventory (company_id, item_name, item_sku, quantity, unit, warehouse_location, reorder_level) VALUES (?, ?, ?, ?, ?, ?, ?) RETURNING id'
    ).bind(
      itemData.company_id,
      itemData.item_name,
      itemData.item_sku || null,
      itemData.quantity,
      itemData.unit || null,
      itemData.warehouse_location || null,
      itemData.reorder_level || null
    ).all()
    return results[0] || null
  }

  static async updateInventoryQuantity(id: number, quantity: number) {
    const cf = await getCloudflareContext()
    await cf.env.DB.prepare(
      'UPDATE inventory SET quantity = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?'
    ).bind(quantity, id).run()
  }

  // Delivery Management
  static async getDeliveriesByCompanyId(companyId: number) {
    const cf = await getCloudflareContext()
    const { results } = await cf.env.DB.prepare(`
      SELECT d.*, r.name as route_name, v.name as vehicle_name, 
             u.first_name || ' ' || u.last_name as driver_name
      FROM deliveries d
      LEFT JOIN routes r ON d.route_id = r.id
      LEFT JOIN vehicles v ON d.vehicle_id = v.id
      LEFT JOIN users u ON d.driver_id = u.id
      WHERE d.company_id = ?
      ORDER BY d.scheduled_date DESC
    `).bind(companyId).all()
    return results
  }

  static async createDelivery(deliveryData: {
    company_id: number,
    route_id?: number,
    vehicle_id?: number,
    driver_id?: number,
    scheduled_date: string,
    status?: string
  }) {
    const cf = await getCloudflareContext()
    const { results } = await cf.env.DB.prepare(
      'INSERT INTO deliveries (company_id, route_id, vehicle_id, driver_id, scheduled_date, status) VALUES (?, ?, ?, ?, ?, ?) RETURNING id'
    ).bind(
      deliveryData.company_id,
      deliveryData.route_id || null,
      deliveryData.vehicle_id || null,
      deliveryData.driver_id || null,
      deliveryData.scheduled_date,
      deliveryData.status || 'scheduled'
    ).all()
    return results[0] || null
  }

  static async updateDeliveryStatus(id: number, status: string) {
    const cf = await getCloudflareContext()
    await cf.env.DB.prepare(
      'UPDATE deliveries SET status = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?'
    ).bind(status, id).run()
  }

  // Weather Data
  static async getWeatherData(location: string, limit: number = 10) {
    const cf = await getCloudflareContext()
    const { results } = await cf.env.DB.prepare(
      'SELECT * FROM weather_data WHERE location = ? ORDER BY timestamp DESC LIMIT ?'
    ).bind(location, limit).all()
    return results
  }

  static async saveWeatherData(weatherData: {
    location: string,
    timestamp: string,
    temperature?: number,
    precipitation?: number,
    wind_speed?: number,
    weather_condition?: string
  }) {
    const cf = await getCloudflareContext()
    const { results } = await cf.env.DB.prepare(
      'INSERT INTO weather_data (location, timestamp, temperature, precipitation, wind_speed, weather_condition) VALUES (?, ?, ?, ?, ?, ?) RETURNING id'
    ).bind(
      weatherData.location,
      weatherData.timestamp,
      weatherData.temperature || null,
      weatherData.precipitation || null,
      weatherData.wind_speed || null,
      weatherData.weather_condition || null
    ).all()
    return results[0] || null
  }

  // Risk Assessment
  static async getRiskAssessmentsByRouteId(routeId: number) {
    const cf = await getCloudflareContext()
    const { results } = await cf.env.DB.prepare(
      'SELECT * FROM risk_assessments WHERE route_id = ? ORDER BY assessed_at DESC'
    ).bind(routeId).all()
    return results
  }

  static async createRiskAssessment(riskData: {
    route_id: number,
    risk_level: string,
    risk_factors?: string,
    recommendations?: string
  }) {
    const cf = await getCloudflareContext()
    const { results } = await cf.env.DB.prepare(
      'INSERT INTO risk_assessments (route_id, risk_level, risk_factors, recommendations) VALUES (?, ?, ?, ?) RETURNING id'
    ).bind(
      riskData.route_id,
      riskData.risk_level,
      riskData.risk_factors || null,
      riskData.recommendations || null
    ).all()
    return results[0] || null
  }

  // Sustainability Metrics
  static async getSustainabilityMetricsByCompanyId(companyId: number) {
    const cf = await getCloudflareContext()
    const { results } = await cf.env.DB.prepare(
      'SELECT * FROM sustainability_metrics WHERE company_id = ? ORDER BY date DESC'
    ).bind(companyId).all()
    return results
  }

  static async createSustainabilityMetric(metricData: {
    company_id: number,
    date: string,
    total_distance?: number,
    total_fuel_used?: number,
    carbon_emissions?: number,
    energy_efficiency_score?: number
  }) {
    const cf = await getCloudflareContext()
    const { results } = await cf.env.DB.prepare(
      'INSERT INTO sustainability_metrics (company_id, date, total_distance, total_fuel_used, carbon_emissions, energy_efficiency_score) VALUES (?, ?, ?, ?, ?, ?) RETURNING id'
    ).bind(
      metricData.company_id,
      metricData.date,
      metricData.total_distance || 0,
      metricData.total_fuel_used || 0,
      metricData.carbon_emissions || 0,
      metricData.energy_efficiency_score || null
    ).all()
    return results[0] || null
  }

  // Security Logs
  static async logSecurityEvent(logData: {
    user_id?: number,
    action: string,
    ip_address?: string,
    details?: string,
    severity?: string
  }) {
    const cf = await getCloudflareContext()
    await cf.env.DB.prepare(
      'INSERT INTO security_logs (user_id, action, ip_address, details, severity) VALUES (?, ?, ?, ?, ?)'
    ).bind(
      logData.user_id || null,
      logData.action,
      logData.ip_address || null,
      logData.details || null,
      logData.severity || 'info'
    ).run()
  }

  // Access Logs
  static async logAccess(logData: {
    user_id?: number,
    ip_address?: string,
    path: string,
    method: string,
    status_code: number
  }) {
    const cf = await getCloudflareContext()
    await cf.env.DB.prepare(
      'INSERT INTO access_logs (user_id, ip_address, path, method, status_code) VALUES (?, ?, ?, ?, ?)'
    ).bind(
      logData.user_id || null,
      logData.ip_address || null,
      logData.path,
      logData.method,
      logData.status_code
    ).run()
  }

  // Analytics
  static async getDeliveryStats(companyId: number) {
    const cf = await getCloudflareContext()
    const { results } = await cf.env.DB.prepare(`
      SELECT 
        COUNT(*) as total_deliveries,
        SUM(CASE WHEN status = 'completed' THEN 1 ELSE 0 END) as completed_deliveries,
        SUM(CASE WHEN status = 'in_progress' THEN 1 ELSE 0 END) as in_progress_deliveries,
        SUM(CASE WHEN status = 'scheduled' THEN 1 ELSE 0 END) as scheduled_deliveries,
        SUM(CASE WHEN status = 'cancelled' THEN 1 ELSE 0 END) as cancelled_deliveries
      FROM deliveries
      WHERE company_id = ?
    `).bind(companyId).all()
    return results[0]
  }

  static async getRouteStats(companyId: number) {
    const cf = await getCloudflareContext()
    const { results } = await cf.env.DB.prepare(`
      SELECT 
        COUNT(*) as total_routes,
        SUM(distance) as total_distance,
        AVG(distance) as avg_distance,
        AVG(estimated_duration) as avg_duration
      FROM routes
      WHERE company_id = ?
    `).bind(companyId).all()
    return results[0]
  }

  static async getSustainabilityStats(companyId: number) {
    const cf = await getCloudflareContext()
    const { results } = await cf.env.DB.prepare(`
      SELECT 
        SUM(total_distance) as total_distance,
        SUM(total_fuel_used) as total_fuel_used,
        SUM(carbon_emissions) as total_carbon_emissions,
        AVG(energy_efficiency_score) as avg_efficiency_score
      FROM sustainability_metrics
      WHERE company_id = ?
    `).bind(companyId).all()
    return results[0]
  }
}

