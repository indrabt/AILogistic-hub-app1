'use client'
import { useState, useEffect } from 'react'

export default function MobileNavigation() {
  const [isOpen, setIsOpen] = useState(false)
  const [isMobile, setIsMobile] = useState(false)

  useEffect(() => {
    // Check if we're on a mobile device
    const checkMobile = () => {
      setIsMobile(window.innerWidth < 768)
    }
    
    // Initial check
    checkMobile()
    
    // Add event listener for window resize
    window.addEventListener('resize', checkMobile)
    
    // Cleanup
    return () => window.removeEventListener('resize', checkMobile)
  }, [])

  return (
    <>
      {/* Mobile menu button - only visible on mobile */}
      <button 
        className="mobile-menu-button md:hidden flex items-center p-2 rounded-md"
        onClick={() => setIsOpen(!isOpen)}
        aria-label="Toggle menu"
      >
        <svg 
          className="h-6 w-6" 
          xmlns="http://www.w3.org/2000/svg" 
          fill="none" 
          viewBox="0 0 24 24" 
          stroke="currentColor"
        >
          {isOpen ? (
            <path 
              strokeLinecap="round" 
              strokeLinejoin="round" 
              strokeWidth={2} 
              d="M6 18L18 6M6 6l12 12" 
            />
          ) : (
            <path 
              strokeLinecap="round" 
              strokeLinejoin="round" 
              strokeWidth={2} 
              d="M4 6h16M4 12h16M4 18h16" 
            />
          )}
        </svg>
      </button>
      
      {/* Navigation links - desktop view */}
      <nav className="hidden md:flex gap-4 sm:gap-6">
        <a href="/" className="hover:text-primary transition-colors">Dashboard</a>
        <a href="/routes" className="hover:text-primary transition-colors">Routes</a>
        <a href="/inventory" className="hover:text-primary transition-colors">Inventory</a>
        <a href="/analytics" className="hover:text-primary transition-colors">Analytics</a>
        <a href="/users" className="hover:text-primary transition-colors">Users</a>
        <a href="/settings" className="hover:text-primary transition-colors">Settings</a>
      </nav>
      
      {/* Mobile navigation menu - only visible when menu is open on mobile */}
      {isMobile && isOpen && (
        <div className="md:hidden absolute top-16 left-0 right-0 bg-background border-b border-border z-50">
          <div className="flex flex-col p-4 space-y-3">
            <a href="/" className="py-2 hover:text-primary transition-colors">Dashboard</a>
            <a href="/routes" className="py-2 hover:text-primary transition-colors">Routes</a>
            <a href="/inventory" className="py-2 hover:text-primary transition-colors">Inventory</a>
            <a href="/analytics" className="py-2 hover:text-primary transition-colors">Analytics</a>
            <a href="/users" className="py-2 hover:text-primary transition-colors">Users</a>
            <a href="/settings" className="py-2 hover:text-primary transition-colors">Settings</a>
          </div>
        </div>
      )}
    </>
  )
}
